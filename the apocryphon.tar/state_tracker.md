# Real-Time State Tracker (The Apocryphon)

> **Last Updated**: Book Two, Chapter 1 Settled (*The Gates of Castellon*)  
> **Status**: Verified against Book Two Master Detailed Outline. 100% Canonical Alignment. Zero Deviation.

---

## 1. Timeline & Setting Anchor
- **Current Book**: Book Two: *The Capital's Deceiver*
- **Latest Settled Chapter**: Book Two, Chapter 1: *The Gates of Castellon*
- **Upcoming Chapter**: Book Two, Chapter 2: *The Silver Tower*
- **Time**: Mid-November (Late Autumn / Early Winter), noon bells ringing across the capital.
- **Primary Location**: Castellon (The Imperial Capital) — Transitioning from the Great King’s Highway into the Great Quadrangle of the **Silver Tower**.
- **Environmental Context**: Cold northern river breeze sweeping through white marble colonnades; burning canal-coal; dense aristocratic carriages; murmuring court observers and foreign legates.

---

## 2. Character Registry & Current States

### Lied Evans
- **Station**: Scholar-Fellow of the Silver Tower (entering the Faculty of Imperial Statecraft and High Arbitration). Age 19.
- **Social Stance**: Arrived in the capital with an explosive, fabricated aura of high patronage: publicly escorted by the true blood of Griffin. The court observers now view him not as a poor marcher second son, but as a dangerous young faction-leader.
- **Financial Balance**: 
  - 55 gold sovereigns from Book One - 1 sovereign 4 crowns travel - 3 sovereigns Ansel's debts - 12 groats mantle = **~50 gold sovereigns remaining**.
  - Monthly obligation: 5 silver crowns to Ansel.

### Ansel of the Broken Shield
- **Station**: Last male heir of the ancient Barons of Griffin. Now sworn "Master of the Horse and Senior Equerry" to Lied Evans.
- **State**: Pulled from squalor, debt, and rot-gut gin. Shaven, clothed in fine Evans-green broadcloth, carrying the ancient family lance and griffin-falcon standard. Restored to aristocratic dignity, bound to Lied by both material survival and the promise of future territorial restitution.

### High Archon Vane (Imminent in Ch 2)
- **Station**: Dean of the Silver Tower, Chief Judicial Arbiter of Crown Treaties.

### Prince Karl Wagner (Imminent in Ch 2)
- **Station**: Imperial Military Observer representing the Western Empire; studying statecraft at the Silver Tower.

---

## 3. Active Causal Threads & Status

| Thread ID | Thread Name | Phase | Current Reality & Tension | Next Beat |
|---|---|---|---|---|
| **T-15** | *The Griffin Rumour* | **ACTIVE & HIGH TENSION** | Unsettled on left page. The bold public entrance with Ansel ignited court scrutiny, curiosity, and factional espionage. Must be affirmed before the King's Bench. | Chapter 2: The Silver Tower; dealing with aristocratic skepticism. |
| **T-16** | *The Silver Tower Matriculation* | **CRITICAL INCEPTION (Ch 2)** | Lied enters the lecture halls of imperial arbitration; court-born rivals ready to test his standing. | Chapter 2: The debate over the unaligned grain-weight ratio before Archon Vane. |
| **T-17** | *The Birth of Edric Vale* | Pending Setup | Father's quarterly scrip will prove restrictive; need for an independent commercial engine. | Chapter 3: Renting the Tallyhouse shop. |

---

## 4. The Ledger (Lied's Personal Register)

### Left Hand (Unsettled Claims / Unmade Truths)
- *The Griffin Rumour: that the second son of House Evans travels under the personal protection and sworn counsel of the true blood of Griffin, to be affirmed before the King's Bench.* **[ACTIVE UNSETTLED HIGH-STAKES CLAIM]**
- *Silver Tower Standing: to secure private access to the Ministry's central tax registers before the winter term ends.* **[ACTIVE CLAIM]**
- *The Marcher iron-rebate deficit: thirty-six gold sovereigns annually.* **[LONG-TERM FISCAL DEBT]**

### Right Hand (Settled Facts / Reconciled Credence)
- *Passage by timber-ketch from Griffin to Castellon: one sovereign, four silver crowns.*
- *Ansel of Griffin: arrears cleared under Hodge's release; retained as Master of the Horse at five crowns monthly.*
- *The Chieftain's Blood-Oath: ratified at Raine Ford under forty witnesses.*

---

## 5. Chapter Context Handoff (Verbatim Excerpts)

### Closing Paragraphs of Book Two, Chapter 1 (For Chapter 2 Continuity):
```markdown
Lied reached inside his coat, his left fingers lightly touching the calfskin volume resting against his ribs.

He opened the book in his mind.

On the left-hand page, the entry remained untouched:

The Griffin Rumour: that the second son of House Evans travels under the personal protection and sworn counsel of the true blood of Griffin, to be affirmed before the King's Bench.

It was not settled.

It had not moved an inch to the right.

He had not won; he had merely placed his first piece upon the board. He had drawn the gaze of forty dukes and three ministries to an empty standard, and if he could not forge the reality to match the flag before the winter council sat, they would tear his skin from his bones.

Lied drew rein before the Great Arch of the Silver Tower.

The two giant statues of the High Archons looked down upon him from fifty feet of white granite, their stone eyes blind and unyielding in the winter wind.

Lied swung down from his saddle, handed his reins to Ansel, and stepped onto the first marble tread of the grand staircase.

The game in the capital had begun.
```
