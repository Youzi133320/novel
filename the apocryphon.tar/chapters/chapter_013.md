# Chapter 13: Payoffs

> *From the Commonplace Book of Lied Evans, Scholar of Griffin Academy:*
> 
> **[Unsettled — Written Left-Handed]**  
> *Silver Tower of Castellon: to enter the High Ministry before my nineteenth year without kneeling to the War Office.*  
> 
> **[Settled — Written Right-Handed]**  
> *The Inquest of the Red Reach: closed under royal commendation; border war averted; peace covenant lodged in the High Chancery.*  
> *Letter of Recommendation to Silver Tower: sealed under the gold eagle of Dean Winters.*  
> *Cathedral Testimonial of Pure Orthodoxy: signed by the Chapter Secretary under diocesan wafer.*

***

The smell of burnt pitch had washed from the stones of Raine Ford, but in the higher cloisters of Griffin, the air remained charged with that dry, metallic static that follows a lightning strike.

The couriers had ridden hard. By Wednesday morning, the royal heralds had crossed the river bridge from the capital, delivering three royal writs bearing the broad seal of the King’s Bench.

The inquest was closed.

Captain Jem was officially registered as an apostate lunatic who had perished of a sudden heart seizure while resisting arrest. Duke Victor Greven’s name did not appear upon the royal parchment; high peers of the realm do not appear in murder registers. But the King’s Council quietly cancelled the mobilization of the southern legions, the border garrison was restored to territorial command, and the forty burnt wagons were compensated out of the Duke’s private customs share under the polite heading of an "administrative indemnity."

The war was dead.

And in the quiet, carpeted study of the Dean’s Lodge, the payoffs were being counted.

Dean Winters sat behind his mahogany desk, a fresh porcelain dish of candied ginger at his elbow. He looked at Lied with the benevolent, hooded satisfaction of an investor whose high-risk shipping share has come into port with three holds of silk.

"The Council of Masters has met, Candidate Evans," Winters said, dipping a goose quill into a bottle of royal purple ink. "The Academy’s basements remain unvisited. The Crown’s commissioners have departed with their pockets full of polite excuses, and Master Brutus reports that our weapons-stores are in flawless territorial order."

He drew a heavy sheet of vellum from his drawer—creamy, gold-edged, stamped with the spread eagle of Griffin.

"The Silver Tower in the capital," Winters said, signing his name with a great, sweeping flourish that took up three inches of margin. "The faculty of higher statecraft and imperial arbitration. It is reserved for the heirs of earls and the senior scholars of the Crown. A second son from the northern defiles does not ordinarily walk through the Silver Gate, Lied."

He pushed the recommendation across the wood.

"Give this to High Archon Vane when your second year commences. It states that you possess a singular, indispensable genius for institutional pacification. You will not study under-clerking in the capital, my boy. You will study where the laws are written."

Lied picked up the letter. The ink was wet; the parchment was cool and heavy.

"I thank you, Dean Winters."

"Do not thank me," the Dean purred, popping a piece of ginger into his mouth. "A dead student is an administrative nuisance; a student who stops thirty thousand heavy horse from trampling my timber-lands is a statesman in the making. Go pack your boxes, Lied. You are becoming too large for this pond."

***

The second settlement arrived in the south cloister of the Cathedral.

Brother Marcus met him behind the monument to the Third Bishop, his habit clean, his purple fingers clutching a folded vellum document sealed with the double keys of Saint Jude.

"The Diocesan Testimonial of Clean Orthodoxy," Marcus whispered, his eyes darting toward the aisle where two canons were chanting the noon office. "Signed by the Bishop’s chancellor himself. It certifies that your research into the heresy vaults was conducted under direct episcopal commission for the suppression of demonological apostasy. No inquisitor in the realm can question your orthodoxy with this in your pocket."

Marcus reached out, his hand hesitating for a fraction of a second before touching Lied’s sleeve. The cleric looked at him with a strange, shivering mixture of terrified gratitude and superstitious awe.

"They are transferring me to the capital, Lied," Marcus muttered. "To the cathedral of the Holy City. The Bishop said my 'vigilance' in detecting the border heresy proved I was wasted in a provincial cellar. I am to be third clerk of the almonry."

Lied looked at the cleric’s scrubbed face, at the clean linen of his collar.

"Do not steal from the Pope’s basins, Marcus," Lied murmured with a quiet smile. "The pontifical inquisitors use hotter pincers than the ones in the gorge."

"I wouldn't dare," Marcus gasped, crossing himself furiously. "By the Seven Lights, I wouldn't dare."

***

He met Magister Aetherine under the bare lime trees of the Philosophers' Walk, where the river wind had blown the dead leaves into golden drifts against the balustrade.

The elven scholar wore her dark blue traveling cloak, her hands tucked into a muff of white ermine, looking out across the gray water where the merchant barges were moving again under the peace-oaths.

She did not look at him when he stopped beside her.

"The Chieftain's blood-glyph," Aetherine said, her voice cool and low. "It was drawn with three strokes of arterial blood. A true oath, Lied. I did not believe Gruk had the wit to ride forty leagues in five hours."

"Gruk did not ride alone," Lied said. "Lina cleared the pass."

Aetherine gave a faint, elegant tilt of her head. "The commoner girl from the tower. She used my third equation on the limestone. A crude execution, but mathematically sound. She has the brain of a stone-mason and the pride of an emperor's bastard. She will survive Griffin."

She turned her amber eyes toward him, the pupils narrowing to vertical slits in the winter glare.

"You have a dangerous habit, young Evans."

"Which one, Magister?"

"You assemble pieces that do not belong to the same game," she said softly. "An orc broker, a cathedral thief, an assassin novice, an elven scholar, and a peasant girl with an arithmetic slate. You make them dance to a music that only you can hear, and when the tune ends, they find they have saved your skin and thanked you for the privilege."

She stepped closer, her voice dropping into a register of chilling, absolute seriousness that silenced the wind in the branches.

"When you go to the capital, Lied, you will hear whispers of the Witches' Circle. A fellowship of women scholars who study the deep grammars and the unwritten names of the Seven Seats."

She touched his chest, her slender, ringed finger resting precisely over the split-calf book beneath his coat.

"Never seek them out," Aetherine said. "Never write to them. Never speak their names in an open room. They do not play games with paper, boy. They weave with living souls, and if a man tries to sit at their loom, they will unpick his life thread by thread until nothing remains except an empty chair."

She stepped past him without waiting for an answer, her blue silk skirts whispering over the dead leaves as she vanished into the mist of the north gallery.

***

In the afternoon, Gruk came to the stable-yard behind the Three Drowned Crows to settle his debts.

The orc was accompanied by a young nephew—a squat, thick-necked orc youth of sixteen named Morz, with skin the color of green moss and two budding tusks barely showing past his lip. Morz was hauling a heavy hand-cart loaded with three cured hogsheads of salted mountain salmon—a peace-offering for the lost brandy cellar.

"The blood-debt is dead, Lied," Gruk grunted, his scarred fist clapping Lied’s shoulder with enough force to rattle his teeth. "The chieftains are trading at the river. The road is open. My sister sent the salmon from the high lake."

Lied watched the young nephew.

Morz was standing by the cart, arguing with a human drayman over the price of four sacks of dried barley. The boy did not yell; he did not draw his hunting knife.

He stood with his thumbs hooked into his leather belt, his head tilted slightly to the right, his eyes half-closed, speaking in a low, measured, unhurried cadence that mimicked Lied’s exact vocal pauses. When the drayman demanded six crowns, the young orc tapped his thumbnail three times against the timber of the cart, looked the carter straight in the eye with cool aristocratic pity, and said: *"Four crowns, my good man. And you will deliver the sacks to the wharf before the third bell, or my uncle will inspect your road-charter at the bridge."*

The carter blinked, swallowed hard, and took the four crowns without another word.

Lied stood frozen in the gravel yard.

*The School.*

The thought rose in his mind with the cold, hair-raising clarity of a physical revelation.

The boy had never read his ledger. The boy knew nothing of Prophetic Utterance, of the Glass Hollow, or of the Seven Seats.

He had merely watched Lied negotiate twice across a wooden table.

And the method was already reproducing itself in the marrow of an orc.

***

At ten o’clock that night, Lied sat alone in his room in the third quadrangle, his traveling portmanteau packed upon the floor.

On the table before him lay the papers recovered from Captain Jem’s private desk at the frontier security station—three bundles of encrypted military correspondence that the county bailiff had handed to Lied to burn in the Academy furnaces.

Lied did not burn them immediately.

He sat with his iron stylus, systematically breaking the simple numerical cipher used by Duke Greven’s chancellery.

Most of it was routine treason: bribes paid to provincial toll-inspectors, schedules of military naphtha shipments, maps of undefended border villages marked for burning.

Then he turned to the third sheet.

It was headed with a single, Latin glyph: *Vascula.* The Vessels.

A list of forty-two names, compiled over two years by the heart demon's network across the northern marquisates. Each name was accompanied by age, birth-district, and an etheric aptitude rating.

They were gifted commoners. Children of millers, orphans of garrison soldiers, scullery wenches with anomalous arithmetic memories—young minds whose natural mana-channels were wide and pliable, unformed by high aristocratic tutors, perfect for the implantation of Celestial Heart Demons to serve as covert instruments of the ducal cabal.

Lied’s finger moved down the column.

Near the center of the parchment, his eyes stopped.

*Lina of Lisle Tower. Age 15. Natural arithmetic capacity: Tier Three. Prime candidate for Seventh Legion integration.*

Lied’s heart stopped beating for two full seconds.

Across the name, drawn in thick, dark scarlet ink with a single, brutal stroke of an iron reed, was a horizontal cancellation line.

In the margin beside the stroke, written in Jem’s flat, mechanical hand, was a dated notation:

*Canceled. Enrolled under territorial bursary at Griffin Academy, feast of the equinox. Protected under royal student charter. Unreachable.*

Lied sat in the silence of his chamber, the single candle guttering in the draft from the window.

His hands were trembling.

He remembered the cold morning in the steward's solar in Lisle. He remembered Barend standing by the door with his muddy boots, his cracked voice asking for an advance against his soldier's pay. He remembered his own careless, bored lie, spoken across the desk to get rid of an old man so he could finish counting his oats.

*I will see to Griffin. Her fees are paid for.*

A casual, selfish, unthinking lie.

And that lie had dragged twenty-eight sovereigns out of a drowned ship, broken an old covenant, forced open a closed road through forty leagues of mountain snow, and struck Lina’s name from the butcher’s ledger of a demon network three days before the kidnappers were scheduled to ride to her tower.

If he had been honest—if he had told Barend that the March held no money, if he had let the girl stay in the village to wash trenchers and scribe bills for the wharf—she would be lying in a stone cellar tonight with a chitinous demon gnawing her heart out from behind her ribs.

Lied picked up the sheet.

He held it over the candle flame until the vellum blistered, blackened, and caught fire, curling into gray ash that fell softly onto the stone hearth.

He watched the ash die.

He told no one.

***

The morning brought the black carriage.

It rolled through the Great Gate of Griffin at sunrise—a high, four-wheeled traveling coach of black-lacquered oak, bearing no coat of arms except the silver sun-burst of the Holy Inquisition upon its door-panels. Its four black stallions were lathered with white sweat, their iron shoes ringing like funeral bells on the cobbles.

From the carriage stepped Silas von Heide.

The High Inquisitor was thirty-five, tall, lean as a pike-staff, his black wool mantle fastened with three steel clasps shaped like burning thorns. His face was the color of bleached bone, his pale, colorless eyes deep-set beneath heavy brows, his thin lips bloodless and unsmiling.

He did not speak to Dean Winters; he did not bow to the proctors.

He walked straight to the Cathedral chapter-house, spent two hours with the charred skull of Captain Jem in the undercroft, and then demanded the parish registration rolls for the day of the parley.

Lied stood in the shadow of the library archway, holding his traveling cloak around him, watching the Inquisitor through the mist.

Silas sat at a small table in the cloister, turning the sheepskin leaves of the enrollment register.

His long, pale finger stopped on the third line of the matriculation list.

*Lied Evans. Dual Curriculum: Hall of Blades & Tower of Geometries.*

The Inquisitor did not merely read the Latin letters. From the velvet lining of his sleeve, he drew an antique brass astrolabe no larger than a pocket watch—a Holy Office phylactery attuned to the resonance of the **Name Seat**, the high metaphysical ledger through which the divine laws recorded every mortal soul.

Silas suspended the crystal needle over the inked signature.

The mercury dial did not settle into the steady silver glow of a common mortal name.

The needle shivered violently, spinning in frantic, erratic arcs until it locked between two opposed azimuths. Through the cut crystal lens, the ink of Lied’s name seemed to cast two distinct etheric shadows: the first upright and mortal, tethered to the Marcher soil; the second slanting backward with an impossible, celestial chill, as though a second hand—a thing born between divine light and deep demonic abyss—had held the iron pen alongside the boy's fingers when his soul was inscribed upon the world.

A demon-mark had touched the Name Seat.

Silas’s pale brows drew together into a slow, terrifying frown.

He took a bone stylus, touched the mercury until the needle died, and closed the brass casing with a sharp, metallic snap.

He did not call the guards. He did not speak.

He closed the parish register with a soft, heavy *thud*, rose from the bench, and turned his pale, colorless eyes across the quadrangle—not at the bustling crowd of students, but straight toward the dark recess of the archway where Lied stood in the shadow.

For three seconds, their eyes met across fifty yards of cold autumn air.

Silas did not smile; he did not nod. He closed his fingers around the Name Seat astrolabe inside his sleeve, turned his black mantle, and climbed back into his carriage, the iron doors slamming shut with the sound of a closing cell.

***

Lied returned to his rooms at noon to collect his portmanteau for the southern coach.

On his table, resting upon his woolen blanket where no servant had been permitted to enter, sat a package.

It was rectangular, eighteen inches long, wrapped in un-dyed linen and tied with raw hemp twine. There was no wax seal; there was no direction; there was no sender’s name.

Lied drew his hunting knife and severed the twine.

Inside, protected by layers of dry river-rushes, were three volumes bound in decayed vellum, their titles stamped in the angular, geometric glyphs of pre-Cataclysmic celestial grammar:

*The Seven Foundations of the Unspoken Word.*  
*The Mechanics of Somatic Division: On the Nature of Avatars.*  
*A Commentary on the Light Seat and the False God.*

Lied turned the brittle, fragrant pages with his left hand.

The books were priceless. They were treatises that had been burned by the Holy See four hundred years ago, works that existed only in the private collections of the highest imperial archons or the deepest vaults of the Witches' Circle.

He looked at the empty room. The window was locked; the chimney was cold.

Someone had walked through an iron-bolted oak door, laid three forbidden keys to the universe upon his blanket, and walked away into the rain without leaving a footprint on the floor.

***

Three hundred miles to the north, above the dark, wooded gorge of the Evans March, the autumn wind was tearing the yellow leaves from the branches.

High on the granite ridge, beside the ancient, gnarled oak that looked down into the black water of the Glass Hollow where a dying boy had spent two days in the dark nine years ago, a figure stood motionless against the gray sky.

Her mantle was black, lined with the silver fur of the northern fox, her hood pulled low over her brow.

She did not watch the road to High Crag; she did not watch the sheep in the valley.

Her eyes were fixed entirely toward the south, where the great highway wound through the hills toward the spires of Castellon, the seat of the King, the home of the Silver Tower, and the city where a boy with an empty ledger was about to invent his second life.

She smiled—a slow, terrifying, infinitely patient curve of her lips—and turned away into the shadows of the pines.
