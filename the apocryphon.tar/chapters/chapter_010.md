# Chapter 10: The Raids

> *From the Commonplace Book of Lied Evans, Scholar of Griffin Academy:*
> 
> **[Unsettled — Written Left-Handed]**  
> *The Border Wagon Inquest: the raiders of the Red Reach road are not of the Orc clans, and will be exposed under territorial inquest before muster.*  
> 
> **[Settled — Written Right-Handed]**  
> *Cathedral Heresy Transcript No. 412: deposition on border possession cases, copied under Cleric Marcus's seal.*  
> *Two jars of salt-brine and dried beef: delivered to Kiln Number Four.*

***

The smoke of the Red Reach wagons reached Griffin three days before the couriers.

It hung over the eastern horizon like a bruised purple stain against the pale autumn sky, smelling of scorched pitch-pine, roasted oats, and the bitter, oily stench of charred broadcloth. By Saturday noon, the first survivor arrived at the lower water-gate: a carter from the western valleys, his face wrapped in bloody rags where a flame-arrow had burned away his left ear, driving four screaming horses whose manes had been singed to the skin.

Forty-two wagons burned between the river bend and the boundary stone. Eleven guards slain. Three hundred bales of wool and eighty barrels of mountain ale looted or tipped into the gravel ditches.

In the taverns along the canal, the talk was of nothing else.

"Orcs," spat the draymen, slamming their pewter mugs onto the grease-stained boards. "The red-skins from the eastern steppes. They've broken the border truce. They came out of the scrub with two-handed cleavers and fire-jars, yelling their howling heathen chants!"

In the Great Quadrangle, young nobles were gathering in clusters by the sundial, their hands resting on the pommels of their gilt rapiers, talking loudly of honor, the King’s peace, and a winter campaign to burn the barbarian kraals back to the salt-flats.

Lied did not go to the taverns.

He sat on the fourth tier of the anatomical amphitheater in the Tower of Geometries, an open inkhorn between his feet, listening to Magister Aetherine.

Aetherine was an elf of the High Moon lineage, though she wore the midnight-blue silk of an Academy master rather than the forest-mantles of her people. She was slender, straight-backed as an ash bow, with skin the color of old ivory and ears that tapered to fine, silver-haired points. Her age was unguessable; she had taught etheric anatomy at Griffin while Viscount Robert’s grandfather was still wearing bibs, and she spoke the classical human tongue with an aloof, terrifying precision that made the boldest third-year students sweat through their collars.

On the demonstration slab before her lay a shattered piece of oak wagon-tongue, recovered from the burnt convoy by the county watch.

"Observe the fracture," Aetherine said, her voice cool and low, echoing through the tiered stone chamber like water dripping in an empty cave. She pointed a slender wand of polished bone at the blackened wood. "Human militia invariably attribute all frontier arson to orc shamanism. It is a comforting superstition. It assumes that violence is always crude, and that a barbarian's flame can be recognized by its savagery."

She tapped the charred timber.

"An orc war-magic circle operates through blood-resonance and the ignition of atmospheric sulfur. When an orc Berserker or Shaman directs flame against an obstacle, the ether bleeds outward in an expanding spiral. The wood does not burn evenly; it fractures along the fibrous grain, leaving jagged, saw-toothed carbon ridges and crystalline yellow deposits of sublimated sulfur in the ash."

She looked up, her clear, amber eyes sweeping across the forty students sitting in the stone tiers.

"Look at the specimen upon the slab. The carbonization is smooth. The depth of the burn is uniform to the thirty-second of an inch. The combustion was accelerated by an ether-refined petroleum distillate—the military naphtha manufactured exclusively at the Royal Arsenal of the capital."

A quiet rustle ran through the benches.

Two young lords from the War Office circle frowned, glancing at one another.

"Magister," said Felix Ashworth, raising a silk-cuffed hand from the front row. "Are you suggesting the raiders were equipped with imperial ordnance?"

"I am suggesting nothing, Master Ashworth," Aetherine replied, her amber gaze resting upon him with the flat indifference of a cat watching a sparrow through a window. "A scholar observes data; a politician invents intentions. I am telling you that the fire which consumed the Red Reach wagons was ignited by a three-fold geometric matrix known only to chartered military mages of the third rank, and that no orc between the mountains and the sea possesses either the mathematics to calculate the ratio or the furnaces to distill the fuel."

She waved her hand, and two servants in gray livery stepped forward to cover the slab with a black cloth.

"The lecture is concluded. The second-year class will submit their proofs on celestial deflection before Friday bells."

***

Lied walked out of the amphitheater into the cold drizzle of the cloisters.

His mind was running swift and cold, tracing the lines of a ledger that refused to balance.

If the orcs had not burned the wagons, who had?

To burn forty-two supply wagons on the King’s highway required sixty armed men, twenty heavy horses, and two gallons of military naphtha. You could not hide sixty armed men in the border scrub without the local pickets noticing, unless the pickets were looking the other way.

And you could not purchase military naphtha from the Royal Arsenal without a commander's requisition warrant.

Lied did not go back to his rooms.

He pulled his scholar’s hood over his brow, left the Academy precincts through the water-gate, and plunged into the maze of muddy alleys that led down to the timber-wharves of the lower canal.

The tavern was called the Three Drowned Crows. It was built half over the black, sluggish water of the canal basin, supported on rotting oak pilings that smelled of creosote and dead eels. Inside, through a fog of pipe-weed and roasting tripe, thirty orc river-men and mountain carters sat over iron flagons, speaking in the guttural, rhythmic grunts of the steppe dialects.

In the back booth, behind a curtain of greasy horse-blankets, sat Gruk.

Gruk was an orc broker of forty winters, broad as an iron chest, with skin the color of a wet river-slate and two heavy tusks curving upward from his lower jaw, bound in bands of tarnished brass. He wore a patched sheepskin waistcoat and was drinking hot gin from an unglazed clay bowl.

"Lied," Gruk grunted, his small, bloodshot eyes peering through the smoke. "The student boy. You bring my crystal money?"

"The crystals are gone, Gruk," Lied said, slipping into the wooden bench opposite the huge orc and laying his hands flat upon the grease-stained board. "The thief is dealt with. The proctors have closed the inquiry."

The orc let out a wet, whistling rumble from his nose. "Good. If Voss came into my tunnels with his witch-soldiers, my boys would have opened six bellies before midnight. But the roads are bad, Lied. Very bad."

"The Red Reach wagons," Lied said.

Gruk slammed his clay bowl onto the wood, spilling gin across his knuckles. His thick brow-ridge lowered until his eyes were nearly invisible beneath the bone.

"They blame my brothers," the orc snarled, his voice vibrating with suppressed, animal fury. "My sister’s clan is thirty leagues to the north, grazing their goats on the high moss. Yesterday, the Marcher militia rode into the border kraal at Bitter Creek, burned sixteen tents, and killed two boys who were cutting firewood. They say it was blood-price for the wool."

"It was not your sister's clan," Lied said.

Gruk froze. His heavy jaw worked slowly, his tusks gleaming yellow in the tallow light. "You know this?"

"I examined the timber," Lied said quietly. "The wagons were burned with imperial fire-fluid. The raiders came from the south, not the steppes."

He leaned across the table.

"Gruk. Who cleared the road?"

The orc took a long, burning swallow of his gin. He wiped his mouth with his broad thumb, his little eyes darting to the curtain to ensure no one was listening from the tap-room.

"Two days before the fire," Gruk whispered, his voice dropping into a harsh rasp, "my runners brought three kegs of mountain brandy down the high defile. The regular picket at the Stone Bridge wasn't there. A new squad was sitting on the road—riders in dark leather with un-crested iron skull-caps. Their captain took twenty crowns from my boy, told him the turnpike was closed for 'military survey,' and turned him onto the sheep-trails."

"Who was the captain?"

"He didn't give a name," Gruk said. "But he had a scar across his left ear, and he wore a heavy iron signet on his gauntlet. A split shield with an open eye."

Lied’s fingers twitched slightly against the table.

*An open eye.*

The insignia of the Frontier Security Guard—the provincial gendarmerie appointed by the Ministry of the Interior to police the trade turnpikes between the capital and the March.

"Thank you, Gruk," Lied said, rising from the bench.

The orc reached out a massive, hair-backed hand and caught Lied’s wrist. His grip was like an iron shackle, cold and unyielding.

"Lied," Gruk rumbled, his tusks inches from the boy’s face. "The clans are singing the death-songs in the high camps. The chieftains have sharpened their war-cleavers. If the Marcher lords cross the boundary river in armor, there will be blood from the mountains to the sea. Find the dog who burned those wagons. Or my people will find him, and we will burn the valley to the stones."

"The dog will be found," Lied said calmly, pulling his wrist from the orc’s grip without a flicker of fear. "Keep your boys off the road for four days. That is all I ask."

***

At ten o’clock that night, Lied unlocked the side wicket of the Cathedral of Saint Jude using the notched iron key he had taken from Brother Marcus.

The undercroft was pitch-black, smelling of incense, ancient dust, and damp lime. He walked with a small tallow lantern shielded beneath his coat, his boots clicking softly on the stones until he reached the third iron press in the records bay.

He did not have to search blindly.

Marcus had left a narrow parchment transcript tied with purple thread beneath the stone bench in the chapel cloister, exactly as commanded.

Lied unfolded the transcript upon the desk beneath the lantern light.

It was an excerpt from the confidential inquisitorial register of the diocese: *Inquest into Border Security Officers, Seventh District (Confidential).*

Lied read the lines swiftly.

*Captain Jem. Age thirty-eight. Formerly lieutenant of the Ducal Guard of House Greven. Appointed Warden of the Red Reach Turnpike by special patent of the Duke of Victor Greven, third year of the current peace. Commended by the diocesan commissary for zeal in suppressing itinerant orc heresy.*

Lied’s finger moved down the margin.

At the bottom was an addendum, written in the cramped, trembling hand of an elderly inquisitor who had died four months ago:

*Note: In the matter of Captain Jem’s annual spiritual examination at the feast of Pentecost. The candidate showed uncharacteristic rigidity during the recitation of the Seventh Light. When the consecrated salt was touched to his throat, the skin remained cold, and an irregular palpitations of the left carotid artery was observed—a rhythmic fluttering resembling an internal foreign organism. Investigation suspended by order of the Chancellor of Duke Greven.*

Lied leaned back against the stone press.

His breath was cold in the dark vault.

*A Celestial Heart Demon.*

The words rose in his memory from the forbidden treatises on demonology he had skimmed in the Bishop’s banned library.

A heart demon was not a wandering spirit or a horned brute from the nether-pits; it was an astral parasite cultivated by the high demon-cults of the ancient empire. It nested within the left ventricle of a living man, feeding upon his blood and his ambitions, replacing his conscience with an absolute, terrifying obedience to the master who held its binding-word.

A man possessed by a heart demon felt no remorse; he felt no fear; he did not sleep, and he could lie before an altar without his pulse moving by a single beat.

And Jem was Duke Victor Greven’s man.

Lied looked through the darkness of the crypt, his mind assembling the pieces with the cold, clicking precision of an iron clockwork.

Duke Victor Greven was the richest nobleman in the southern provinces, but his ducal lands held no iron and no silver; he was dependent upon the northern marches for his ores and his timber. For ten years, Greven had petitioned the Crown to establish a unified border command under his personal lieutenant-generalship, which would give him command of three royal legions, thirty thousand men, and the right to tax every mine between High Crag and the sea.

The King had refused him. The kingdom was at peace; the orcs traded quietly on the river; the Marcher viscounts defended their own borders.

There was no reason for a ducal army.

*Unless the orcs attacked.*

Unless forty wagons were burned, eleven guards slaughtered, and the frontier pushed to the brink of a bloody, catastrophic racial war that would force the King to grant Greven his legions in an afternoon.

Jem had not burned the wagons to steal wool.

He had burned them to manufacture a war.

Lied stood up. He blew out his lantern, locked the iron press with Marcus’s key, and climbed the stone stairs toward the high nave of the cathedral.

Outside, the rain had stopped, leaving the night air brittle and cold as glass.

From the northern ridges, three hundred miles away, he could almost hear the gathering murmur of the mountain muster—his brother Rodney sharpening his heavy lances, his father calculating the cost of fodder, the orc chieftains singing their death-chants around the smoke of their campfires.

A catastrophe was rolling toward the March like an avalanche down a shale slope.

And Lied Evans was standing at the bottom of the hill with a borrowed sword, a box of stolen heresy papers, and a dragon hatchling sleeping in a lime kiln.

He pulled his scholar’s gown tight around his throat.

"Very well, my lord Duke," Lied whispered to the cold stars above the cathedral spires, his mouth curving into that thin, merciless smile that was becoming his trademark. "You want an army. Let us see what it costs you."
