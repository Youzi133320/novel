# Book Two: The Capital's Deceiver
## Chapter 1: The Gates of Castellon

> *From the Commonplace Book of Lied Evans, Scholar of the Silver Tower:*
> 
> **[Unsettled — Written Left-Handed]**  
> *The Griffin Rumour: that the second son of House Evans travels under the personal protection and sworn counsel of the true blood of Griffin, to be affirmed before the King's Bench.*  
> 
> **[Settled — Written Right-Handed]**  
> *Passage by timber-ketch from Griffin to the Lower Water-Gate of Castellon: one sovereign, four silver crowns.*  
> *Tavern-slate and lodging arrears for Ansel of the Broken Shield: three gold sovereigns, paid in hand to the landlord Hodge under notarized release.*  
> *One dark woollen riding mantle with brass clasps, for an equerry: twelve silver groats.*

***

The city of Castellon did not begin with walls; it began with coal-smoke, low fog, and dead water.

Three leagues before the river reached the first water-gate, the clean willows of the southern valleys vanished, choked out by miles of seasoning-sheds, rope-walks, and brick-kilns that vomited black, greasy vapor into the low November sky. On the sluggish brown current of the Great River, broad-beamed freight-ketches from the eastern sea jostled against flat-bottomed coal-punts, their skippers cursing in five dialects over the screaming of gulls and the iron clatter of dredging chains.

Above it all, straddling the great limestone ridge like an ancient cyclopean collar of bleached bone, rose the capital of the realm.

Castellon was built on three tiers.

At the waterline lay the Lower Basin: a sodden labyrinth of timber wharves, herring-curing sheds, and narrow, overhanging tenements where forty thousand watermen and dye-stewers lived in the permanent damp. Above them, carried on the massive, soot-blackened granite arches of the Old Aqueduct, sat the Middle City: the broad cobbled avenues of the banking guilds, the iron-foundries, and the stone mansions of the merchant-magnates. And crowning the high crag, gleaming pale and cold in the winter sun above the industrial haze, were the white marble spires of the King’s Palace of Mirrors, the Cathedral of the Light Seat, and the octagonal dome of the **Silver Tower**.

Lied Evans stood on the dripping fore-deck of the timber-ketch *The Stork*, his traveling mantle pulled tight against his throat.

He was nineteen.

His shoulders had broadened by two inches in the weapon-rings of Griffin, and beneath the dark green cloth of his Marcher tunic he wore a light, oiled mail shirt that did not clink when he walked. His dark hair was cut close above his ears in the clean, severe style of the southern courts, and in his right hand he carried an iron-banded leather sea-chest containing his books, his three rolls of gold sovereigns, and the sealed parchment letters of Dean Winters.

Beneath his breast, resting flat against his ribs over the old scar, was the calfskin ledger.

The ketch bumped against the greasy oak pilings of the Salt-Gate quay with a dull, shuddering groan that sent a shower of brown spray over the deck.

"Castellon!" the master roared, spitting tobacco juice into the foam as his deck-hands flung heavy hemp warps around the iron bollards. "All scholars, factors, and vagrants ashore! The King’s gagers board in ten minutes, and I have six kegs of un-cleared brandy under the ballast that don't need their thumbs on 'em!"

Lied walked down the slippery gangplank onto the wet cobbles.

The air in the port smelled of rotting cod-heads, boiling tallow, wet wool, and that peculiar, sharp, metallic stink of uncounted silver coin that lives in great commercial cities.

He did not hire a porter. He carried his chest by the iron handle, his grey eyes scanning the crowd of factors, water-guards, and broadsheet-peddlers who thronged the quay.

A young man in the blue-and-white livery of a city notary stood by the toll-post, distributing copies of the morning gazette.

Lied stopped. He dropped a copper penny into the clerk's wooden tray and took a damp, four-page broadsheet printed on coarse rag-paper: *The Castellon Mercury and Court Intelligence.*

His finger moved down the second column.

*From the Northern Marches: It is reported by travelers from the gorge that the late provincial conspiracy at Raine Ford was suppressed through the timely intervention of young Lord Evans, second son to the Warden of the Defiles. Reliable sources in the capital assert that the young gentleman travels to the Silver Tower under the extraordinary patronage of an ancient northern lineage—a knight of the true Griffin blood whose ancestral lance once guarded the High Kings.*

Lied folded the paper and tucked it into his pocket, his mouth curving into that faint, cold smile that was his trademark.

The rumour had arrived three days ahead of him.

That was the danger of a successful bluff: once a word gained momentum, the world’s imagination began to decorate it with gold lace and heraldic feathers until the original claim was lost beneath an impossible, floating fairy-tale.

A knight of the true Griffin blood.

The ancient Marcher barony of Griffin had been extinct in all official registers for sixty years; its castles were heaps of brambles, its lands confiscated by the Crown after the second rebellion, its heraldic falcons forgotten on cracked churchyard slabs. If the War Office or the high chancellors investigated the rumour and discovered that Lied Evans was traveling with an empty purse and an imaginary protector, the court would dismiss him as an insolvent provincial pretender before he set foot upon the stairs of the Silver Tower.

Lied turned his back on the great stone road that climbed to the palaces.

He walked down into the alleys of the chandlers' quarter.

***

The lane was called St. Jude’s Gut.

It was four feet wide, paved with un-dressed river rubble that was slick with pig-fat and discarded vegetable-trimmings, running beneath the dripping arches of the Old Aqueduct where the sun never penetrated. Here the small tallow-boilers and candle-dippers had their sheds, the air so thick with the nauseating stench of boiling suet and rendered sheep-fat that Lied had to press his sleeve against his mouth to breathe.

At the end of the court, leaning against the damp brickwork of a dye-house, stood a derelict three-story timber tenement, its gables sagging like the broken jaw of an old skull.

Lied climbed the rotting wooden stairs that wound around the outside of the building, his boots testing each tread before committing his weight.

On the third landing, beneath the leaking lead eaves where pigeons nested in the holes, he stopped before a door of rough pine planks, fastened with an iron hasp that was tied shut with a piece of dirty hemp twine.

From inside came the sound of a dry, hacking cough, followed by the clink of a clay bottle against a wooden floor.

Lied cut the twine with his thumb-knife and pushed the door open.

The garret was seven paces square, lit only by a hole in the roof where the slate had fallen in, letting a narrow shaft of grey winter light illuminate the wet floorboards. There was no hearth, only a pile of cold peat ash in an iron pot. On a straw pallet in the corner, wrapped in a threadbare horse-rug stained with ale and dried gutter-mud, lay a man.

He was twenty-four, with the long, fine-boned limbs of an aristocrat and the broad shoulders of a rider, but his cheeks were hollow, covered in ten days of reddish-brown stubble, and his linen shirt was black with grease around the collar. Beside his pallet lay three empty stoneware jugs of potato gin, a cracked leather saddle-bag, and an un-sheathed broadsword whose polished blade was spotted with brown rust along the fuller.

Ansel of the Broken Shield.

The last living male heir of the Barons of Griffin.

The young man opened one bloodshot blue eye, squinting against the gray light from the door. He did not reach for his sword; he reached for the nearest clay bottle, shook it, found it empty, and let his head drop back against the straw with a dry, rattling groan.

"The rent is five groats, landlord," Ansel muttered, his voice scraped raw with gin and cold damp. "And you won't get it until the carrier pays me for unloading the salt-carts on Tuesday. Go away and let me die in peace."

Lied set his iron-banded chest down on the floorboards with a heavy, ringing thud that shook the rotten partition.

He pulled the single wooden stool from against the wall, blew the soot from the seat, and sat down, his hands resting lightly upon his knees.

"The rent is four groats, Ansel," Lied said, speaking in that calm, measured cadence that belonged to an administrative office. "Your landlord is an illiterate tanner named Hodge, who has been overcharging you a penny a week because he knows you cannot read the parish tax-dockets."

The young man stiffened. He turned his head slowly, his eyes opening wide, taking in Lied’s clean bottle-green broadcloth, the white linen of his collar, and the silver scholar’s pins gleaming at his throat.

"Who the devil are you?" Ansel rasped, struggling up onto one elbow, the horse-rug falling from his bare, shivering shoulder. "A bailiff’s clerk? If my cousin in the south sent you to buy my sword-scrip, tell the bastard I'll use it to gut him first."

"Your cousin in the south died of the dropsy three months ago," Lied said. "And I am not a bailiff. I am Lied Evans."

Ansel blinked, his brow furrowing as he dragged his wine-soaked memory through the names of the kingdom. "Evans? The northern marcher? The boy who held the ford against the orcs?"

"The same," Lied said.

Ansel gave a short, bitter bark of laughter that ended in a cough. "Then you've come to the wrong street, Lord Evans. There are no heroics in St. Jude’s Gut. Only cheap gin and rats with the mange. What does an Evans want with a carter who sleeps on straw?"

Lied reached into his coat pocket.

He drew out a small pigskin purse, unbuckled the iron tongue, and tipped three heavy gold sovereigns into the palm of his hand.

The gold caught the grey shaft of light from the broken roof, glowing with that deep, warm, yellow fire that only royal bullion possesses.

Ansel stared at the coins. His breath stopped; his hand, resting on the dirty straw, twitched once, the long fingers clenching into a fist. But the look in his eyes was not gratitude; it was the fierce, rabid suspicion of an outcast who has been kicked too many times to believe in gifts.

"Whose throat do I have to cut?" Ansel asked, his voice dropping into a flat, ragged whisper. "Or is it my name you want? A deed of quitclaim on the Griffin lands, so your father can register the sheep-pastures without a lawsuit? Three sovereigns is cheap for a barony, Evans."

"Your grandfather lost the Griffin lands to the Crown by attainder forty years ago," Lied replied, his tone dry, level, and completely devoid of sentiment. "You have no deed to sell, Ansel. If I wanted a dead title, I could hire a scrivener at the water-gate to forge one for four silver groats."

"Then what is the gold for?"

"It is to pay your debts," Lied said. "Three silver crowns and four groats to the tapster at the Black Anchor. Two sovereigns to Hodge to burn this straw and release your saddle-bags. And the remainder to buy you a bath at the bagnio, a clean shirt, and a pair of boots that don't let the river mud onto your socks."

Ansel’s mouth twisted into a sneer. "Charity. The young lord comes down from the north with his father's gold to play at being a saint to the destitute."

"I am a second son with eighty sovereigns to my name, Ansel," Lied said, leaning forward, his eyes locking onto the young knight's face with cold, sharp clarity. "I do not give charity. I do not lend to beggars. And I do not waste gold on men who intend to die in an attic."

He reached down, picked up the rusted broadsword from the floor, and balanced the blade upon his two forefingers.

"The steel is four-ply folded iron," Lied observed, his thumb running lightly over the fuller where the faded, inlaid silver letters of the ancient griffin-motto still survived beneath the pit-marks: *The Word Holds the Mountain.*

He looked down into the young knight's bloodshot eyes.

"The court broadsheets say that I have arrived in Castellon under the personal protection of an heir of the Griffin blood," Lied said. "They say that a knight of your house rides at my right hand, as my sworn equerry and chief counselor of horse."

Ansel’s jaw worked slowly. "They say that? Why?"

"Because a rumor started on the northern turnpike, and the capital is an echo-chamber that loves nothing better than an ancient name," Lied said. "If I go to the Silver Tower alone, I am a second son on an under-clerk’s scrip, fighting forty dukes’ bastards for an empty stool in the chancery. But if I ride through the Great Gate with the true blood of Griffin carrying my standard, the court will wonder what your house has recovered from the north. They will wonder who is backing whom. And while they are wondering, we will take their seats."

Ansel let out a harsh, dry breath. "And when they look behind the standard? When they find out that the 'counselor of horse' doesn't own a mule, and that his ancestral sword is held together with lard and wire?"

"They will find what I choose to show them," Lied said. "They will see an ancient house that has kept its silence for sixty years, emerging from the borderlands in alliance with the March. But that requires a partner, Ansel. Not a drunkard who weeps into his potato gin."

Lied drew an official paper from his sleeve.

"Section twelve of the Restoration Statutes," Lied said, pointing to the Latin line. "A knight whose family suffered under the Third Attainder may petition the King's Bench for restitution of his honorifics, provided he is retained in an honorable martial capacity by a peer of the March. I am not a peer yet, but my father is. Ride with me as my equerry. Appear at the Silver Tower. Carry the standard. In exchange: five silver crowns a month, full board at the White Swan in the High Ward, three suits of clean broadcloth, and when the winter term ends, I will personally draft your petition to the High Chancellor."

Ansel stared at the parchment.

The room was completely quiet, save for the dripping of the rain through the broken slate.

The young knight looked at his hands—calloused, black with coal-dust, trembling with the aftermath of drink. He looked at the leaking roof, at the piles of cold peat ash, at the squalor that had been his grave for four years.

"Five crowns a month," Ansel murmured, his voice hardening as the fog of alcohol receded before the cold wind of a real opportunity. "And you buy the oats for the horses."

"I buy the oats," Lied agreed.

"And one more thing, Evans." Ansel pushed himself upright on the straw, his gaze direct and piercing. "If this is a cheat—if you are using my name to front a treason that puts my neck in a noose—I will not wait for the King's justices. I will take your ears with this rusted blade before they lead me to the block."

Lied smiled. It was a genuine smile, warm and razor-sharp.

"Fair terms, Ansel. Get your boots. The tanner is waiting on the landing."

***

The exit from St. Jude’s Gut was not without friction.

At the foot of the rotting timber stairs, standing in the mud beneath the dripping brick arch, was Hodge the landlord. He was a squat, greasy man with forearms like hams, accompanied by two dock-side bailiffs in boiled-leather jerkins, holding thick ash cudgels weighted with lead.

"Hold on, masters," Hodge barked, his little pig-eyes darting from Ansel's washed face to Lied's clean green cloak. "Master Ansel don't leave this yard. He owes four groats for the room, two shillings for the broken shutter, and three crowns in statutory interest for the winter arrears."

The two bailiffs stepped forward, their cudgels resting against their palms.

Ansel’s hand dropped instinctively to his rusty broadsword, his jaw tightening for a brawl.

Lied caught Ansel's wrist with his left hand, checking the blade before it could clear the scabbard.

Lied did not raise his voice. He took three paces forward, stepping directly into the mud before Hodge, and drew a narrow brass-bound slip from his pocket—a certified receipt from the Municipal Court of Assize, stamped with the blue ink of the toll-clerk.

"Landlord Hodge," Lied said, speaking with the icy, effortless authority of a circuit judge. "Your tenement sits upon municipal leasehold number four-twelve, held under the jurisdiction of the River Conservancy. Under section seven of the Urban Tenancy Act, a landlord who charges interest on rent arrears without registering the debt before the parish court commits an act of unlicensed usury, punishable by a ten-pound fine and three days in the pillory at the Fish-Market."

The tanner blinked, his fat jaw going slack. "Usury? What are you babbling about? The boy owes me—"

"The boy owed you sixteen silver groats," Lied interrupted, tossing three heavy silver crowns onto the muddy barrel between them. The silver rang sharp and clear against the wet wood. "There is eighteen groats. Keep the two groats as a composition for the broken shutter. If you or your ruffians take another step toward this gentleman, I will lodge a formal petition of extortion with the City Marshal before the noon bells strike. And you know very well what the Marshal does to unregistered tanners on the river bank."

The two cudgel-men looked at Lied’s crisp collar, at the silver scholar’s pins, and at the absolute, terrifying certainty in his eyes.

They did not ask to see his credentials. They took half a step backward into the rain, lowering their clubs.

Hodge stared at the three silver crowns. His fat fingers twitched, swept the silver into his dirty apron, and spat into the mud.

"Take your beggar and go," the tanner muttered.

Lied turned to Ansel. "The carriage is at the end of the lane."

***

At half-past eleven, the great bronze bell of the Cathedral of Saint Jude began to toll the noon office, its deep, resonant notes rolling over the slate roofs of Castellon like distant thunder in the mountains.

Along the King’s Highway—the grand, eighty-foot-wide avenue of white limestone flags that climbed from the river quays toward the high marble colonnades of the Upper City—the traffic of citizens, guild-officers, and noble carriages was parting to clear the center of the road.

Riding at the head of the avenue on a tall, black gelding with four white stockings was Ansel of Griffin.

He was transformed. He had bathed in the hot steam of the public bagnio; his jaw was shaven smooth, his reddish-brown hair combed back and tied with a black silk ribbon, and over his shoulders hung a tailored mantle of dark forest-green broadcloth, fastened with a silver brooch shaped like a stooping falcon. He sat his saddle with the easy, arrogant grace of a cavalry officer who had spent ten years in the northern marches.

In his right stirrup-leather was stepped an eight-foot lance of blackened ash, from which fluttered a swallow-tailed pennon bearing the quartered arms of House Evans and the silver-threaded griffin of his own blood.

Riding beside him on his roan gelding was Lied.

Lied wore his scholar’s gown of dark gray cloth, his linen collar unadorned, his posture unhurried, one hand resting lightly on the reins as he observed the monumental architecture of the capital with cool, aristocratic indifference.

Behind them rode two hired grooms in clean green fustian, leading the pack-mules laden with their leather chests.

It was an extraordinary spectacle.

A provincial scholar entering the capital was a common sight—dozens arrived every week on the carriers' carts. But a provincial scholar riding beneath the long-dead heraldic banner of the Griffin Reach, escorted by an equerry who carried the unmistakable, sharp profile of the ancient barons, was a political riddle that demanded immediate attention.

On the high marble terrace of the Ministry of the Marine, overlooking the Great Avenue, three high officials in velvet robes paused with their wine-cups in their hands, looking down through the balustrade.

"Look there," murmured Lord Corin, the First Commissioner of Tolls, pointing a ringed finger at the pennon. "The Evans boy from the northern defiles. The one Dean Winters commended for the border settlement."

"And the rider carrying his lance?" asked a second commissioner, an elderly judge of the Admiralty Bench.

The first commissioner squinted through his bone-mounted spectacles, his brows drawing together in sharp, incredulous shock.

"By the Light," Corin breathed. "It is old Baron Alden's grandson. Ansel. The lost heir who disappeared into the lower wards four years ago. They said he was dead of the drink."

"He doesn't look dead," the judge muttered, watching Ansel's tall, straight back and the clean gleam of the ash lance. "He looks like he has twenty lances behind him in the north."

"A masquerade," sneered a third official, a sharp-featured secretary wearing the purple livery of Duke Victor Greven's faction. "The boy picked up a starving vagrant from the ditch, washed his face, and gave him an old flag. It is an empty bluff to impress the Silver Tower."

"Perhaps," Lord Corin replied softly, his eyes never leaving the two riders as they trotted up the hill. "Or perhaps the Evans March has struck a private compact with the old Griffin loyalists. If House Evans holds the river dikes and the Griffin blood holds the mountain charters, the War Office will find the northern iron-contracts slipping through their fingers this winter. We had better send a runner to the Chancellor before the afternoon council."

The secretary did not argue. He turned from the balustrade, his face dark with suspicion, and hurried into the interior galleries to write his dispatch.

Lied did not look up at the ministry terrace.

He did not need to look.

He felt the shift in the atmosphere.

It was not the warm, uncritical adoration he had felt from Sister Eileen, nor the cold, dead silence of the lower village.

It was something far sharper, far more volatile: **suspicion, curiosity, and calculation**.

Dozens of minds were suddenly turning toward him—not believing the rumour, but unable to dismiss it. They were sending runners; they were checking registers; they were whispering in council chambers. The rumour was no longer an idle piece of provincial gossip printed in a cheap broadsheet.

It had become a volatile, high-stakes question that the entire court was now desperate to answer.

Lied looked across at Ansel.

The young knight sat rigid in his saddle, his eyes fixed straight ahead, his jaw clamped shut against the gaze of three thousand people watching him from the footpaths. Beneath his fine green mantle, Lied saw Ansel's hand trembling slightly against the ash shaft of the lance.

The boy was terrified. He knew that one wrong step, one misspoken word before a royal magistrate, and the entire fragile illusion would shatter into treason and debtor's prison.

Lied reached inside his coat, his left fingers lightly touching the calfskin volume resting against his ribs.

He opened the book in his mind.

On the left-hand page, the entry remained untouched:

*The Griffin Rumour: that the second son of House Evans travels under the personal protection and sworn counsel of the true blood of Griffin, to be affirmed before the King's Bench.*

It was not settled.

It had not moved an inch to the right.

He had not won; he had merely placed his first piece upon the board. He had drawn the gaze of forty dukes and three ministries to an empty standard, and if he could not forge the reality to match the flag before the winter council sat, they would tear his skin from his bones.

Lied drew rein before the Great Arch of the Silver Tower.

The two giant statues of the High Archons looked down upon him from fifty feet of white granite, their stone eyes blind and unyielding in the winter wind.

Lied swung down from his saddle, handed his reins to Ansel, and stepped onto the first marble tread of the grand staircase.

The game in the capital had begun.
