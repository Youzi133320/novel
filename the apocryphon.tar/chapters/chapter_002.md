# Chapter 2: The Scales That Won't Light

> *From the Commonplace Book of Lied Evans, Steward of the Lisle Holding:*
> 
> **[Unsettled — Written Left-Handed]**  
> *Lina of the Tower: Twelve gold sovereigns to the Bursar of Griffin, before the equinox.*  
> *Cross-Keys Sheep Fair: Forty-two bales of coarse fleece due for road-toll clearance before the magistrate's court closes at dusk.*  
> 
> **[Settled — Written Right-Handed]**  
> *Upper Weir jam cleared: three ash wedges, two crowbars, six pints of small beer for the tenant ditchers.*  
> *One roan gelding, shoed with four iron plates at Cross-Keys forge: eight copper bits.*

***

The clay of the river ditch was still drying to grey crust inside the cuffs of Lied’s trousers when the roan brought him into the market square of Cross-Keys.

It was mid-afternoon, and the rain had given way to that brittle, paper-thin northern sunlight that warms nothing except the tops of fence posts. A hundred and fifty head of mountain sheep were penned in hurdles of split wattle along the churchyard wall, their wet fleeces steaming with the thick, greasy stench of lanolin and fermented dung. Farmers in boiled frieze jackets shouted over the clatter of iron-rimmed dray-wheels, testing fleece by plunging their thumbs into the spine-wool to feel for burrs or scab.

Lied dismounted at the hitching post outside the bailiff’s court. His lower back throbbed with a dull, persistent ache from six hours of leaning over an oak pry-bar at the Upper Weir, but his collar was clean and his hair was combed back flat with a wet bone comb. A steward of the March did not appear before the freeholders of the district looking like a drowned ditcher.

"Master Lied," said Alder, the notary.

The old man sat behind a trestle table set out beneath the timber eaves of the market hall, out of the wind. A sheepskin cloak was pinned across his narrow shoulders with an iron bodkin, and his ink-well was embedded in a turnip hollowed out and filled with hot grease to keep the frost from curdling the black fluid.

Beside his elbow sat the apparatus of the Crown: the Scales of Oaths.

It was an ancient, unlovely thing of hammered cold-iron, no taller than a man’s forearm. Its twin pans hung from braided silver wire, balanced upon an agate fulcrum carved with the five-pointed crest of the royal judicature. When a merchant sworn to the King’s peace laid his hand upon the charter beneath it, the low-tier etheric lattice woven through the iron was meant to answer the presence of an authentic sworn name. If the contractor swore under his true identity, pledging his lawful person to the King's commercial peace, the silver wires drew faint phosphor from the air, glowing with the pale, steady luminescence of foxfire in a wet ditch.

If a man spoke under a borrowed face, or swore with a shadow name that owned no standing before the law, the iron stayed dead.

"Master Alder," Lied said, touching his hat-brim with two fingers. "My father’s toll-roll for the wool-drays. Twenty-two loaded wains from the eastern ridges, nine from the valley holdings. All dues accounted in groats, save for old Hallet, who claims three bags went to water-rot."

"Hallet claims water-rot every spring the frost breaks before Lent," Alder muttered, not looking up as his dried-leaf fingers turned the sheepskin page. He dipped his reed into the turnip and drew a brisk red stroke through the entry. "He can bring the rot-bags to the court dung-heap on Saturday or pay the fourpence fine. We don't take swamp-water on credit."

Before Lied could answer, a shadow fell across the bleached boards of the table.

The man who stepped between them was forty or thereabouts, wearing a traveling mantle of good indigo wool lined with squirrel pelts. The hem was muddy, but it was traveling mud from the southern turnpike, not the heavy red clay of the local sheep-runs. His boots had silver-plated buckles, and his hands, emerging from fur-trimmed mittens, were soft and white, the nails pared down to pink crescents.

"Master Notary," the newcomer said. His accent was smooth, rounded at the edges with the singsong cadence of the Midland river-ports. "I have the pleasure of addressing Master Alder, sworn factor of the territorial assize?"

Alder raised his watery grey eyes. He looked at the squirrel fur, then at the silver buckles, and finally at the man's throat, where an enamel badge of the Mercer’s Guild hung from a split cord.

"You have," Alder said. "And you're blocking the light. The court closes when the parish bell strikes five, and there are forty draymen behind you waiting to clear their fleeces."

"I shall not detain the court five minutes," the man said. He unhooked a leather folder from beneath his arm and laid it between the ink-turnip and the iron scales with a practiced, elegant flick of his wrists. "Aldous Clark, factor of the High Mere Trading Company, registered at the staple port of Oakhaven. I hold sixty bales of prime white fleece, mountain-washed and carded, currently lying in the shearing lofts at the high grange of Alder-in-the-Fell. My client in the capital has contracted for the consignment at nineteen groats the stone, delivery before the feast of Saint Jude."

He smiled, a pleasant, open expression that showed teeth surprisingly even for a traveler.

"The buyer’s agent requires a notarized delivery charter under the Marcher seal before the advance drafts can be issued through the goldsmiths at Cross-Keys. The statutory fee of three silver crowns is here."

He laid three heavy coins on the corner of the wood. They rang true—clear, high silver with the sharp bite of newly minted royal coin.

Lied did not move from the post where he stood. He rested his forearm against the roan’s saddle-leather, his eyes narrowed slightly against the pale glare of the sky.

Something was wrong.

It was not the man’s voice, which was musical and deferential, nor his paper, which bore the crisp purple stamp of the Oakhaven guild-office. It was something smaller, an administrative dissonance that snagged in Lied’s memory the way a burr catches in carded wool.

*Alder-in-the-Fell.*

Lied knew the parish rolls. When his father had set him to the Lisle stewardship ten months ago, Lied had spent three weeks in the damp archives at High Crag, reading the tithe surveys from his grandfather’s time down to the last sheep-dip ditch.

Alder-in-the-Fell was a high valley four leagues north of the gorge. It had five hundred acres of sour bracken, two limestone quarries that had filled with black water forty years ago, and six stone shielings where shepherds slept during the summer grazing.

It had no shearing lofts. The only roofed timber structure in the entire parish was an old tithe barn that had collapsed under wet snow during the third year of the winter blight, leaving only four blackened corner-posts and a mound of rotten thatch that the local wood-cutters used for target practice.

Old Alder pulled the document toward him with two ink-stained fingers. He read the Latin protocol with the weary speed of a man who had seen ten thousand identical charters.

"Sixty bales," Alder muttered. "Mountain-washed. Three hundred stone. Sworn under the territorial seal of the March."

"Precisely," said the merchant, his smile deepening. He took off his right mitten, revealing a gold signet ring cut with an anchor and three sheafs of wheat. He raised his bare right hand, palm forward, level with his ear. "I swear by the Light and the King's five wits that the goods are sound, dry, and stored under lock at the declared holding, free of prior lien or mortgage, to be delivered without fraud or evasion."

He lowered his hand and reached for the iron pen to sign the registry.

Beside the ink-well, the Scales of Oaths sat motionless.

The silver wires did not glow. No faint halo of foxfire gathered along the cold-hammered arms; no pale phosphor flickered in the agate fulcrum. The iron remained precisely what it had been three minutes before: an old, pitted piece of metal sitting on a grease-stained pine table in the cold air.

The merchant’s pen hovered half an inch above the sheepskin.

His smile did not falter, but the skin around the corners of his eyes tightened by a fraction of a hair's breadth.

"The air is damp, Master Notary," Clark said smoothly, giving a small, self-deprecating chuckle. "The etheric nodes in these provincial instruments often stiffen with the mountain mist. A touch of the warming-pan—"

"The nodes do not stiffen," Alder said. His voice had lost its dry boredom. It had become flat, heavy, and cold as a slate gravestone. He did not touch the three silver crowns. He left his hands resting on his ledger. "The King’s scales do not freeze, Master Clark. A sworn man lights them if his name is registered in the royal rolls, though the blizzard be six feet deep outside the door."

"I assure you—"

"Lied," Alder said, without turning his head. "You have the Marcher land-roll in your head. What sits at Alder-in-the-Fell?"

The merchant turned slightly. For the first time, his gaze took in the seventeen-year-old boy leaning against the horse. His eyes flicked over Lied’s mud-stained boots, the simple fustian coat, the lack of gold chains or livery. He dismissed him in an instant.

"My good lad," Clark said, reaching into his pocket with his left hand, "this is an affair of high commerce between chartered merchants. If the notary requires a local witness to verify the carriage routes—"

"There are no shearing lofts at Alder-in-the-Fell," Lied said.

His voice was quiet, lacking both anger and triumph. He spoke as though he were reading a line from the commissary ledger to an illiterate carter.

"The high barn fell in the third year of the sheep rot," Lied continued, his grey eyes fixed entirely on the merchant’s signet ring. "The timber was sold for mine-props to the stone quarry. The land is held under common copyhold by seven cottars who graze two hundred and forty black-faced wethers between them. Wethers don't yield sixty bales of virgin fleece, Master Clark. They yield sixty stone of coarse mattress-wool every three years, and half of that goes to the Evans weavers at High Crag to pay the winter grazing rights."

The market square seemed to drop into a sudden well of silence.

Two carters who had been arguing over a nose-bag of oats stopped talking. A bailiff’s constable, leaning against the timber pillar with a six-foot billhook in his fist, straightened his back, the iron rings of his hauberk clinking softly.

The merchant’s hand withdrew from his pocket. It came out empty.

"An administrative confusion," the man said. His accent was changing; the sweet, rounded vowels of the Midland ports were slipping away, revealing the harder, clipped consonants of the border towns down near the salt-marshes. "The factor who assigned the storage lots may have misnamed the parish. The contract—"

"Your name is Morris," Lied said mildly.

The man jerked his chin up as if he had been struck across the bridge of the nose with a switch of green birch.

"What?"

"Morris of Salt-Grave," Lied said, tapping his finger once against the leather roll in his belt. "You were selling salt-fish licenses at the Cross-Keys fair three years ago under a charter from the Bishop of the Isles. My father’s clerk noted the seal had been cut from an old episcopal dispensation and glued with tree-gum to a bill of lading. You paid a five-pound composition to avoid the pillory and left before the summer muster."

Alder did not wait for Morris to answer.

With a speed surprising in a man of seventy, the notary’s left hand shot out and swept the three silver crowns into his leather purse, while his right hand brought down a heavy wooden mallet upon the center of the desk with a crack like an ash bough snapping under ice.

"Fraud upon the King’s scales," Alder barked, his face dark with fury. "Constable! Take the badge and the ledger. Clear his pack at the inn and seal his saddlebags. The bond is forfeit to the Marcher chest, and the body goes to the parish cellar until the circuit justice sits on Thursday."

The constable stepped forward, his heavy hand descending upon Morris’s squirrel-fur collar with the dull, practiced weight of an iron shackle.

There was no struggle.

A man who lived by paper understood paper. The moment the land-roll was cited, the moment the scales remained dead, the entire fragile architecture of Morris’s afternoon had collapsed to dust. The pleasant smile was entirely gone, leaving behind the pale, pinched, exhausted face of a small-time sharper whose luck had run out on a gravel road ten miles from the border.

"A mistake," Morris whispered, his eyes darting toward the horses, then toward the crowd that was already gathering around the table with the cruel, hungry curiosity of villagers watching an ox stumble in the trace. "Only an error in the dates. I had the wool promised to me... a cousin in the south valley..."

"Take him down," Alder said, already dipping his reed back into the turnip. "And wash the table where his papers sat. The grease from his seal smells of pig-fat."

The constable hauled Morris away through the press of frieze coats and fleece-drays. The crowd followed them, shouting coarse jests and spitting into the mud where the merchant’s silver buckles had left neat square impressions.

Lied stood by his roan, watching the man’s retreating back until the blue mantle vanished beneath the low archway leading to the parish lock-up.

He had not moved. His pulse was slow and steady in his wrists.

*The scales had not lit.*

Lied walked slowly to the trestle table. He looked down at the iron apparatus. The twin pans hung quiet, suspended from their silver wires, grey and inert under the northern sky.

"Good memory, boy," Alder muttered, ruling another line across his parchment. "Your father would have let the thief sign, collected the three crowns, and let the merchant in the capital hang him next Michaelmas when the wagons didn't arrive. You saved the March a lawsuit."

Lied did not answer immediately. He reached out with his left hand, his bare fingers lightly brushing the rim of the left iron pan.

The metal was stone-cold. It felt like an iron pot left in a cellar, dead and hollow, lacking even the faint interior vibration that lives in steel when it is forged or heated.

"Why didn't it light, Master Alder?" Lied asked.

The notary glanced up, his brow furrowed with annoyance at being interrupted over a settled matter.

"Because he was swearing under a ghost-name, boy. Aldous Clark doesn't exist on any guild roll in Oakhaven. An etheric wire needs an authentic name anchored in the parish registry before the lattice will answer an oath. And when you spoke up, you proved his wool was smoke as well."

"I know his name was false and his wool was smoke," Lied said, his voice dropping into that quiet, speculative tone he used when he was talking to himself over the ink-wells. "But men pledge things they do not yet possess every week in the capital. Factors sell grain that is still green in the furrow; timber-merchants pledge oaks that are still standing in the high woods. The scales light for forward contracts all through the southern ports."

Alder grunted, blowing a speck of dried muck from his nib.

"Those men swear under their true blood-names, boy, and they hold the fields. Or they hold the silver to buy the fields, or they have a partner who owns the ships. The law knows where the bread is coming from, even if the flour hasn't been ground yet. The grain isn't in the sack today, but it *can* be there tomorrow. There is an open road between the tongue and the barn."

The notary pointed the blunt end of his quill at the empty street where Morris had been dragged.

"That fellow had no road. He had no true name, he held no land, he had no wool, and he had no credit with any living soul within three hundred leagues. His pledge was a hollow cheat with nowhere to land. You can't weigh smoke in an iron pan, Master Lied. The King’s magic isn't clever, but it knows the difference between a debt that can be paid and a hole in the ground."

Alder returned to his roll, his pen resuming its dry, regular scratching.

Lied stood motionless in the cold spring light.

A strange, quiet thrill ran through him, starting at the pale scar on his collarbone and spreading down through his left arm into the tips of his fingers.

*An open road.*

He thought of the scrap of cedar wood lying beneath the hay receipts on his desk in the high chamber at Lisle.

*Lina. Griffin bursary. 12 sov. Due equinox.*

He had no twelve sovereigns. The estate held no discretionary fund. His father would have choked on his own spleen before he gave a single silver groat to send a peasant girl to study geometry among the young lords of the south.

By every standard of the law, Lied’s promise to Sir Barend had been as false as Morris’s sixty bales of mountain fleece.

And yet.

Barend had gone down on his knee. Barend had wept. Barend was, at this very moment, sitting in the guard-room of the Lisle Tower, his stiff shoulder forgotten, telling his five troopers that the young master was an angel of the old blood who took care of his own.

The promise was not true today.

*But could it be made true tomorrow?*

If Lied worked the numbers, if he skimmed the secondary tolls, if he squeezed the grain-merchants, if he traded upon the absolute, unquestioning faith of six armed knights who would ride through the marsh at midnight at his word—could the road be built before the equinox arrived?

Morris had failed because his lie was a dead thing from the moment his breath left his lips. It was a closed loop, an empty cheat designed only to steal three drafts of merchant credit and run for the border. It had no future; it wanted no future.

A promise, Lied realized with sudden, terrifying clarity, was not a fact.

A promise was a draft drawn against the future.

If a man had the will, the nerve, and the cold, relentless precision to pay the balance before the voucher was presented at the counter—the world did not care whether the gold was in the chest when the word was spoken. The world only cared that the coin was on the table when the clock struck noon.

"Master Lied?"

Lied blinked. The market square came back into focus: the sheep steaming in the hurdles, the smell of malt and manure, the old notary watching him with a squint of mild curiosity.

"Your father's toll-sheet," Alder said, tapping the desk. "Are you taking the copy back to High Crag, or do I leave it with the bailiff?"

"Leave it with the bailiff," Lied said.

He took his hand from the cold iron scale. He felt extraordinarily light, as though the dull ache in his back had receded into the background of a wide, sunlit landscape whose roads had just become visible through the morning mist.

He unhitched the roan’s reins from the post and swung himself into the saddle.

"Master Alder," Lied said, looking down from the horse.

"Aye?"

"The three silver crowns Morris forfeited."

"What of them?"

"They belong to the Marcher chest," Lied said, his mouth curving into the faintest, cleanest ghost of a smile. "My father allows the local stewardship a tenth share of all court forfeitures within the valley bailiwick. That is three silver groats for the Lisle ditch-fund. Enter it in the ledger, Master Alder. I shall collect it on Saturday."

He turned the roan’s head toward the river road and touched his heels to its flanks, trotting out of the square before the notary could find the section in the statute book to see if the boy was telling the truth.
