# Chapter 4: The Ledger and the Room's Weight

> *From the Commonplace Book of Lied Evans, Steward of the Lisle Holding:*
> 
> **[Unsettled — Written Left-Handed]**  
> *Ella of the Scullery: possesses a natural hand for the keeping of tallies and the reading of estate dockets.*  
> *Midsummer Eve Guest: Master Corin, Chief Factor of the Marcher Wool-Hall, to attend the lower village feast and review autumn clip-options.*  
> 
> **[Settled — Written Right-Handed]**  
> *One volume, split-calf binding with iron brass-clasp, ruled in double margins: two silver crowns, four groats.*  
> *Seed-corn distribution for the West Meadow cottars: forty bushels, accounted against the autumn threshing.*

***

The book was bound in dark, oil-cured split-calf, thick enough to stop a hunting knife, with corners capped in beaten brass. It had cost Lied two silver crowns and four groats from the peddler who serviced the cathedral canons at Cross-Keys, and when opened flat upon the table, the parchment gave off the dry, clean smell of cedar shavings and powdered chalk.

Lied had divided every page with an iron stylus and a straight-edge of black oak.

Down the center ran a scored trench, the depth of a thumb-nail, separating the leaves into two distinct fields.

The right-hand side was ruled for facts: bushels weighed, tallies struck, silver tested on the touchstone, deaths registered, rents collected. On this side he wrote with his right hand, using black gall-ink and the formal, square chancery script his tutors had beaten into his wrist. The letters stood upright, heavy and unyielding, anchored to the sheepskin like fence-posts driven into dry gravel.

The left-hand side was empty.

Lied sat alone in the solar, the late spring twilight turning the lime-washed walls from gray to the pale blue of skimmed milk. Through the open casement came the smell of freshly turned soil and the sharp, resinous smoke of weed-fires smoldering along the river embankments.

He dipped his steel nib into the ink. He did not use his right hand.

He shifted the quill into his left hand, turning his wrist inward so the shaft pointed toward his ribs.

His left hand was not clumsy. Since his ninth year, since the two days he had spent lying in the dark at the bottom of the Glass Hollow with his ribs cracked and his breath rattling against the stone, his left fingers had possessed an odd, nervous fluency—a handwriting that slanted backward, swift, fluid, and slightly spidery, like the tracks of water-striders across a pool.

On the left-hand page, level with the first rule, he wrote:

*The girl Ella has an eye for ciphers, and reads the steward's day-book without error.*

He held the quill still, watching the black ink settle into the parchment grain.

It was a preposterous sentence.

Ella was fourteen, the third daughter of a carter from the lower marsh. Her knuckles were raw from scouring iron kettles with wood-ash, her left eye had a slight cast from an infant fever, and when she carried the tallow candles up the solar stairs, she moved with the fearful, hurried scuttle of a mouse that expects a broom at every corner. She did not know the alphabet. She could not count past twenty without touching her apron strings, and if asked to tell the number of sheep in a hurdle, she judged the crowd by the breadth of the wool rather than the heads.

Lied let the ink dry without sand. He closed the calfskin volume, latched its brass hasp, and slipped it into the private drawer beneath his table, turning the iron key twice.

***

Two days later, during the midday distribution of bread and cheese to the garden workers, Lied went down to the scullery to inspect the salt-beef barrels.

The cook, a fat, red-faced woman named Mother Hobb whose husband had been lost in the border levy, was shouting at two kitchen wenches over a crock of sour cream that had turned in the thunder-heat. In the corner by the grease-sink, Ella was scrubbing a three-legged iron pot with a handful of birch twigs.

Lied stopped by the door. He did not look at Ella directly; he looked at the bread-board where the day's rations were being cut.

"Mother Hobb," Lied said, raising his voice just enough to carry over the hiss of the roasting turnspit.

The cook stopped her tirade mid-breath, wiped her greasy palms upon her hempen apron, and dipped an awkward curtsy. "Master Lied. The beef is sweet, sir, I swear by the Church. Only two pieces had the yellow fat on top, and I boiled them down for soap-grease."

"The beef is acceptable," Lied said mildly. He glanced casually toward the dark corner by the sink, letting his gaze rest for three seconds upon the girl with the birch twigs. "I noticed the bread-tally this morning on the cellar slate. Who entered the loaves?"

Mother Hobb frowned, her small eyes darting across the room. "The carter's boy, sir. Or one of the stable-hands. I had no time—"

"It was not the carter's boy," Lied said, his tone light, conversational, and completely assured. "The numerals were drawn with three strokes instead of four, the way the notary clerks do it in the town. A very neat hand. I thought it was the little wench, Ella. My brother Rodney’s clerk told me the girl had an extraordinary eye for figures. He said she could audit a flour-bill faster than half the priests in the parish."

A dead silence fell across the kitchen.

Mother Hobb turned her head slowly, her jaw hanging slack, staring at the girl in the corner as though a turnip had suddenly sprouted wings.

The two wenches by the dairy-table stopped chopping, their mouths open.

Ella did not drop her pot. She froze, her birch twigs suspended an inch above the black iron, her neck crimson, her small shoulders hunched together as if she were waiting for a blow from a skillet. She did not raise her eyes, but Lied saw her small chest hitch—a sharp, sudden breath that pulled her apron tight across her ribs.

"Ella?" Mother Hobb breathed, her voice dropping into a register of shocked, suspicious awe. "That little slip of ditch-mire? Master Lied... she don't know an A from an ox-yoke."

"Perhaps you haven't watched her," Lied said, turning back toward the stairs with an indifferent shrug. "Look at her fingers. Slender, dry knuckles. That is a scrivener's hand, Mother Hobb. Keep her away from the scullery grease when the flour-invoices come in from the mill on Friday. I have no patience for greasy thumb-prints on my accounts."

He walked up the timber stairs without looking back.

***

The test did not work like sorcery.

There was no flash of etheric light, no sudden, miraculous appearance of knowledge in the girl's brain. What happened over the following three weeks was far more terrifying, because it was made entirely of ordinary human flesh and bone.

Mother Hobb stopped sending Ella to clean the grease-traps. A kitchen-mistress who possessed a scullery-girl praised by the Viscount's son for scholarship was a woman of consequence; Mother Hobb began setting Ella by the window with the wooden bread-tallies, commanding her to count the loaves and check the butter-crocks.

When the carrier brought the flour-bills from the mill on Friday, the girl sat with them for two hours by the bread-oven. She could not read the letters, but she possessed the stubborn, frightened cunning of a peasant child who has been given a warm stool by the hearth and knows that if she fails, she will be sent back to the frozen ditch.

She found a discarded horn-book behind the chapel stalls, left behind by the priest's nephew three years ago.

At night, while the other wenches slept on their straw pallets beneath the rafters, Ella sat beside the dying embers of the hearth, tracing the inked shapes of the Latin letters on the slate with a splinter of charred bone, whispering the sounds to herself until her tongue grew thick with ash.

On the twenty-first day after Lied had written the sentence in his calfskin book, he called for the quarter-roll of the miller's flour.

Ella brought it up the solar stairs.

She wore a clean apron of unbleached linen, her hair combed back into a neat linen coif. She stood before his desk, her chin held level, and laid the paper upon the cedar block with two clean, scrubbed hands.

"There is an overcharge, Master Lied," the girl whispered. Her voice was thin, but it did not waver. She pointed a clean thumbnail at the fourth line from the top. "Master Miller entered six sacks of rye as bolted white flour. The price on the docket is nine groats the sack. White flour is twelve, but the flour in the bins is gray, and it has the rye-husk in the grain. He owes the estate eighteen copper pence."

Lied looked at the paper.

He looked at the neat, stiff numbers drawn in the margin—crude, square, but completely accurate.

He looked up at Ella.

In her eyes there was no trace of magic. There was only that bright, fierce, hungry intelligence that lives in people who have discovered that they possess a weapon the world cannot take from them.

"Leave the slate," Lied said softly. "Tell Mother Hobb you are to have a tallow candle for your room every Monday, and five pence a month from the desk for ink."

"Yes, Master Lied."

She curtsied—a clean, proud inclination of her head—and walked out of the room, her step light and silent upon the boards.

Lied waited until the sound of her shoes died away on the stairs.

He unlocked his private drawer. He drew out the split-calf book, took the iron pen in his right hand, and drew a single, heavy line of black ink through the sentence on the left.

Beneath the scored trench, on the right-hand page, he entered:

*Ella of the Scullery: appointed under-clerk for commissary stores, confirmed by audit. Salary: five pence monthly.*

The transaction was closed.

***

The second lesson came not from a calculated design, but from the brutal indifference of the March.

In the first week of June, when the seven village elders came to the solar to pay their midsummer pasture-dues, they brought with them a deep, quiet dread. The previous autumn, wool-jobbers from the southern lowlands had cartelized the river crossings, driving the price of frontier fleece down to an ruinous fourteen pence the stone. The cottars were facing a winter of dry bread and salt-porridge unless they could bypass the middlemen and sell directly to the great guild-houses.

Lied looked at the men’s worn caps, their calloused palms, and their anxious, rheumy eyes.

He had a connection at High Crag: Master Corin, the Chief Factor of the Marcher Wool-Hall, who had been a trusted clerk of Lied's grandfather. A direct agreement with Corin would guarantee the Lisle villagers five silver groats above the market minimum, paid in advance before the shearing began.

"You won't sell to the river-jobbers this year, Hallet," Lied said, leaning forward across the desk with a clear, reassuring smile. "I have written to Master Corin. When the midsummer eve comes, he will ride down from the high castle as the guest of honour at the churchyard feast. He will sit at your table, taste your mutton, and inspect your fleeces on the rack. The Marcher Wool-Hall will take the entire clip under territorial charter."

Old Hallet’s breath caught in his throat. The seven elders looked at one another, their weathered faces cracking into sudden, stunned relief.

"Master Corin?" Hallet whispered. "The Chief Factor himself? In Lisle lower village?"

"He has accepted the invitation," Lied told them, his voice ringing with absolute, steady conviction. "Set your tables, clean your hurdles, and keep your fleeces dry. The factor will be here before the sunset bells."

That evening, in the quiet of his chamber, Lied dipped his pen into the ink with his left hand and entered the claim upon the left-hand page:

*Midsummer Eve Guest: Master Corin, Chief Factor of the Marcher Wool-Hall, to attend the lower village feast and review autumn clip-options.*

It was a sound, realistic plan. He had dispatched the formal letter of hospitality by the morning post; Corin had replied with a polite, affirming note; the guest-chamber in the manor had been aired and strewn with fresh lavender. It was a promise built upon a real road, with real wagons and real men.

And yet, over the following fortnight, Lied felt the strange, creeping pressure return to the room.

The village believed him entirely.

Because they believed, the very air of the valley seemed to thicken with momentum. The tenants whitewashed the churchyard wall; the women carded sample fleeces until the wool shone like combed silk; the village blacksmith forged a new spit for a whole roasted calf. When Lied rode through the village lanes, the atmosphere had that same dense, buoyant resistance he had observed with Ella—a tangible social mass, as though the thoughts of two hundred and forty people were physically leaning against his word, bracing it, holding it upright like timber shoring in a mine.

Then the world intervened.

Three days before midsummer, a sudden skirmish flared along the northern defiles. Viscount Robert ordered an immediate emergency mobilization of all Marcher supply-trains. Master Corin, as Chief Factor of the Wool-Hall, was requisitioned by the military council to commandeer every bolt of heavy broadcloth in the province for soldier’s winter cloaks. The roads north were placed under marshal law; civilian couriers were turned back at the bridges.

Lied’s messenger was delayed by a mudslide in the gorge.

The dispatch reached the Lisle solar at seven o’clock on the evening of midsummer eve.

Lied unsealed the wax. Corin’s note was hasty, scribbled in dry haste between military conferences: *Impossible to travel. Requisition orders from the Viscount. Regrets for the feast.*

Lied stood motionless by the window, the paper cold in his fingers.

Down in the churchyard, the tables were already laden. The candles were lit; the roast calf sputtered over the coals; the children had crown-wreaths of wild clover in their hair. Old Hallet stood by the road-gate in his best woollen coat, looking north along the empty turnpike where the twilight was turning from violet to dusk.

Lied walked down the hill alone.

He did not hide; he did not offer a smooth lie about broken wheels or sudden fevers. He walked into the middle of the crowded churchyard, stood before the high table where the empty chair of honour waited, and told them the truth.

"Master Corin will not be coming," Lied said quietly. "The Viscount has closed the mountain roads for the northern muster. The Wool-Hall cannot buy your fleece."

A stillness fell over the tables.

It was not anger. There were no raised voices, no curses hurled at the steward, no violent accusations.

What happened was something far colder, and infinitely more terrible.

Lied felt a sudden, sickening drop in his stomach—the sensation of stepping out into empty air where a solid stair should have been. The dense, humming pressure that had filled the valley for two weeks vanished in a heartbeat, collapsing inward like an empty cask crushed beneath an iron wheel.

Old Hallet stood staring at the empty seat at the head of the table.

His wrinkled shoulders sank by half an inch. He slowly took off his cap, looked down at the grease-spotted tablecloth, and nodded—once, twice—with the weary, stoic acceptance of a peasant who has been reminded of his place in the world.

"Aye," Hallet murmured, his voice flat as ditch-water. "The high castle is far away. We understand, Master Lied."

The villagers ate their mutton in silence. The fiddler did not unpack his bow; the children stopped laughing and sat quietly beside their mothers; by ten o'clock, the torches were snuffed out and the tables cleared.

The next morning, Lied walked down the village lane to inspect the blacksmith's coal-bin.

Hallet was repairing a fence by the pond. When Lied bade him good morning, the old farmer touched his cap with perfect, flawless feudal respect. He answered every question about the ditch-tithes and the drainage with punctilious obedience.

Then Lied mentioned the wool.

"I will ride to High Crag myself next month, Hallet," Lied said. "When the muster settles, I will speak to the bursar directly. We can still secure a charter for the second shearing."

Hallet did not argue. He did not object.

He simply lowered his head, his hands continuing to twist the hazel-withe around the fence-stake, and said: "Whatever the young master pleases, of course."

His eyes were completely blank.

Lied stopped. He felt the cold truth settling into his marrow like frost.

The man had obeyed him as a tenant obeys a lord, but the door behind his eyes was bolted from within. On the subject of the estate, of the taxes, of the roads, Hallet would follow him; but on the subject of outside guests, of great promises, of golden futures arriving from the south, Hallet would never believe a syllable from Lied’s mouth again as long as he lived.

The territory had hardened against him.

Lied walked slowly back to the manor house. He climbed the stairs to his solar, shut the oak door, and sat down at the table.

He took out the split-calf book.

He opened it to the left-hand page.

*Midsummer Eve Guest: Master Corin, Chief Factor of the Marcher Wool-Hall, to attend the lower village feast and review autumn clip-options.*

He took the iron quill in his right hand. He dipped the nib in the black gall-ink, poised the point above the text, intending to strike a line through the words to close the account.

His hand hesitated.

The nib hung a fraction of an inch above the sheepskin.

Slowly, deliberately, Lied set the pen back down in the cedar groove.

He did not cross it out.

To strike it out would be a coward’s vanity—an attempt to pretend that the debt had been paid or that the failure had never occurred. A failed claim was a fact as stubborn and real as an empty stone granary. It had been spoken; it had drawn the belief of two hundred men; and when the road broke, it had shattered the ground upon which it stood.

The sentence remained on the left-hand page, open, unsettled, and unredeemed. A permanent ledger-mark reminding him that reality was not a compliant servant waiting to be fooled, but a massive, unyielding stone that demanded payment in blood, time, and luck for every inch it was moved.

*Witness.*

Lied leaned back in his chair, staring at the open book in the morning light.

He had felt the room’s weight. He had seen belief lift a scullery girl out of the mire into scholarship; and he had seen the sudden, chilling severance when an unfulfilled promise snapped the thread of human trust.

He closed the calfskin volume and slipped it inside his coat, resting it against his breast.

The lesson was learned.

Now, three hundred miles to the south, the great gray towers of Griffin were waiting. And whatever claims he took across their thresholds, he would ensure his roads were built with steel before he ever opened his mouth again.
