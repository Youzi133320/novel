# Chapter 3: The Late Payment

> *From the Commonplace Book of Lied Evans, Steward of the Lisle Holding:*
> 
> **[Unsettled — Written Left-Handed]**  
> *Lina of the Tower: Twelve gold sovereigns to the Bursar of Griffin, before the equinox.*  
> *Chancery gap: Seven sovereigns, two crowns, eleven silver groats.*  
> 
> **[Settled — Written Right-Handed]**  
> *Ridge patrol bounty: One horse-thief, branded right ear, delivered to county gaol at Cross-Keys: five silver crowns.*  
> *Court forfeiture share, ex parte Morris: three silver groats, paid in full by Master Alder under protest.*

***

Three weeks had turned the gray mud of the lower ditches into black soup.

The willow shoots along the Lisle had begun to swell, their tips showing that pale, sickly yellow that promises green leaves if the night frost does not kill them first. In the yard beneath the steward’s solar, two boys with wooden scrapers were clearing the crust of salt and manure from the wagon-tongues, their rhythm broken every few minutes by the metallic *tink-tink-tink* of the smith peening an iron coulter.

Lied sat with his sleeves rolled to the elbow, a scrap of dry pumice in his right hand, scouring a greasy thumb-mark from the margin of the tenant list.

The stairs creaked. Not the hurried clatter of a stable-boy, but that slow, iron-plated tread that belonged to Sir Barend’s dropped right shoulder.

The latch lifted. Barend came in, bringing with him the cold, clean smell of high limestone and wet spruce. His face was wind-burned to the color of brick, his mustache crusted with salt, and over his leather brigandine he wore a new wool mantle of Evans green, fastened with a copper skewer instead of a brooch. He looked five years younger than he had on the morning the Upper Weir cracked.

In his left fist he held a linen money-bag, dark with greasy hand-dirt.

"Master Lied," Barend said. He did not hover at the threshold today; he walked straight to the table, set his boots firmly upon the wool carpet, and set the linen bag upon the cedar block with a heavy, ringing thud that set the ink in the turnip trembling.

"The ridge wolves?" Lied asked, blowing pumice dust from the sheepskin.

"A horse-thief," Barend said, his eyes bright beneath their grizzled brows. "One of the Black-Hedge clan from the eastern border. Took three brood mares from the miller’s paddocks on Tuesday night. We tracked him across the gravel flats above the high falls, boxed him into a limestone chimney, and had him by the throat before sunrise."

The knight wiped his nose with the back of his gauntlet.

"The magistrate at Cross-Keys paid out the county warrant this morning. Five silver crowns, full weight, struck at the royal mint before the coin was debased. Not a clipped edge on the lot."

"A clean job," Lied said. He reached for the inkhorn to credit the garrison patrol. "Keep two crowns for the troopers, Barend. Let them drink ale at the tavern on Saturday, and buy four new saddle-girths from the saddler. The ones in the stable are held together with twine."

Barend did not reach for the bag. He stood motionless, his thumbs tucked into his broad belt, his gaze dropping to the floorboards between his feet.

"The troopers have been paid their meat-scrip, sir," Barend murmured. His voice had taken on that quiet, halting stiffness that always accompanied his deepest moments of pride. "The girths can wait until the wool-fair. I brought the five crowns for the desk."

Lied paused, his pen poised half an inch above the entry.

"The desk?"

"The... the balance, my lord," Barend whispered. He raised his eyes, and in them was an expression of such pure, dog-like fidelity that Lied felt a strange, cold prickle run across the back of his scalp. "For Lina’s coach. And the books. I know five crowns is not two gold sovereigns, but the sheep-shearing begins in ten days, and the bailiff at Cross-Keys promised me the night-watch warrant for the wool-sheds. That will bring another crown and four groats."

Barend reached inside his tunic and pulled out a small piece of slate, its surface covered in crude, chalked columns of arithmetic.

"I have done the sums three times with Lina," the knight said softly. "The twelve sovereigns you sent down to the bursar under the Marcher warrant covered the entrance and the term-board. This five crowns is to repay the estate’s advance. I... I came to ask if the courier had brought the receipt back from the south. The girl hasn't slept in three nights for watching the road."

The world seemed to stop moving.

The sound of the smith peening the iron coulter in the yard vanished. The smell of the peat smoke in the room grew intensely sharp, bitter as gall.

Lied looked down at the desk.

*The receipt.*

A cold, heavy drop of sweat gathered at his hairline beneath his bangs.

He had forgotten.

He had completely, entirely, utterly forgotten.

In the twenty-one days since Barend had kneeled on these floorboards, Lied had spent forty hours waist-deep in river mud clearing the Upper Weir; he had argued sixty tenant leases with old Hallet; he had ridden twenty leagues to settle a boundary dispute between two drunken millers; he had audited four hundred bushels of seed-corn; he had caught Morris the merchant in the market square and filed away the theory of the unlit scales.

He had done everything an intelligent, meticulous, overworked seventeen-year-old steward was supposed to do to keep his father’s land from sliding into bankruptcy.

And the twelve sovereigns for Griffin Academy had never existed.

There was no bursary warrant. There was no discretionary fund from the timber tolls. No courier had ridden south; no gold had been paid to the bursary gate; no receipt had been written. In five days, the class of the vernal equinox would assemble beneath the high grey spires of Griffin three hundred miles away, the roll would be read, Lina’s name would be called, and when no gold appeared to answer the call, the proctor would draw a line of black ink through her name and grant the seat to the son of a wool-stapler from the coast.

Lied sat utterly still.

His mind was not racing; it had entered that strange, freezing stillness that came over him when he had fallen into the black water of the Glass Hollow as a child.

If he told Barend the truth now—if he looked into that weathered, hopeful face and said, *I was busy; I said it to keep you quiet; I forgot your sister's life while I was measuring barley sacks*—something fundamental would break. Not merely Barend’s heart, though that would shatter like dry pot-metal. The authority of the desk would be destroyed. The old soldier’s belief in the Evans blood would die. And Barend would look at him not with anger, but with that terrible, quiet contempt with which an honest soldier looks upon a coward who dropped his sword in the ditch.

Worse: Lied felt an intense, burning refusal in his own ribs.

*I said it,* his mind whispered, the thought hard as chipped flint. *I spoke the words across this wood. The world heard me say it.*

Barend was watching him.

The knight saw the young master’s long silence, the pale, motionless profile, the dark eyes fixed upon the blank sheepskin. To Barend, this was not panic; it was the cold, aristocratic deliberation of a Marcher lord who held men's lives in his ledger and weighed each soul before he answered.

"Master Lied?" Barend’s voice faltered slightly. "If... if the bursar required an additional seal... if the Marcher warrant was delayed by the snow..."

Lied raised his head.

His expression was as smooth and unreadable as an uncarved gravestone.

"The Marcher warrant was not delayed, Barend," Lied said. His voice was slow, level, and possessed of a terrible, quiet confidence that seemed to fill the room like cool water. "The warrant cleared the high chancellery two weeks ago. The bursar has the gold."

Barend let out a breath so long and shuddering it sounded like a dying man’s sigh. His broad chest collapsed, and his hands dropped against his sides.

"Then... the receipt?"

"The receipt is with the regional courier at Cross-Keys," Lied said, and as the lie left his lips, he picked up the quill with his left hand, the steel nib poised over a blank scrap of cedar. "The courier’s mule went lame on the turnpike three leagues north of the gorge. The pouches are sitting at the coaching inn until the mail-coach arrives on Thursday. I did not send for it because I had no intention of handing you a piece of paper until the girl's seat was confirmed by the rector's seal."

He drew the linen bag of silver crowns toward him.

"This five crowns stays on my table," Lied said. "I will deduct it from the estate’s ledger under your discharge account. Lina leaves on Sunday’s coach."

"Sunday," Barend breathed. "Sunday morning. I will hire the carrier’s cart to Cross-Keys. She has two trunks... mostly books and two woollen shifts."

"Give her three crowns from your own pocket for boots," Lied ordered, his tone curt, almost angry. "I will not have a scholar from the Lisle holding walking into Griffin with sheep-clouts on her shins. Now take your patrol report and get out. I have three accounts to balance before the bailiff brings the court returns."

Barend bowed. He bowed so low his nose nearly touched the oak edge of the desk, and when he walked to the door, his boots made no sound upon the carpet. He opened the latch with trembling fingers, stepped out into the wind, and pulled the oak door shut behind him as gently as if he were leaving a church during the consecration of the bread.

The moment the latch fell, Lied dropped the quill.

He buried his face in his hands.

*Twelve sovereigns.*

He had seven days. Sunday was four days away. The coach from Cross-Keys left at dawn on the feast of the equinox, and the driver would not take a passenger without three gold sovereigns for the four-week journey south, plus the bursary certificate sealed with red wax.

Lied stood up. He walked to the window and leaned his forehead against the cold, leaded glass.

Down in the yard, Barend was walking toward the stables. The old knight’s step had a spring in it that Lied had never seen before; when one of the stable-lads dropped a bucket, Barend caught it by the iron handle with his sound left hand, laughed aloud, and clapped the boy on the shoulder with enough force to stagger him.

*The man believes it,* Lied thought, and the thought was like an iron weight pressing down between his shoulder-blades. *He believes it so completely that if I told him the sun was rising in the west tomorrow, he would saddle his horse at midnight to meet it.*

Lied turned back to the room.

He opened his cedar lockbox.

Inside lay five silver crowns and seven groats—his entire personal wealth, accumulated over ten months of skimming penny-tolls and saving his clothing allowance. To this he added the five crowns Barend had just laid on the desk.

Ten silver crowns and seven groats.

A gold sovereign was worth six silver crowns on the royal exchange; a crown was three groats, or twelve silver pence. Ten crowns and seven groats amounted to exactly two sovereigns and a single lonely groat.

He needed twelve sovereigns.

He was short by nine sovereigns, five crowns, and two groats.

It was impossible. He could not sell the estate's horses; the bailiff would notice within an hour. He could not mortgage the mill; his father's clerk held the deeds at High Crag. He could borrow from the moneylender at Cross-Keys, but the moneylender demanded an elder son’s signature or land-scrip, and Lied was neither an elder son nor an owner of soil.

*An open road,* he reminded himself, his teeth grinding together until his jaw ached. *Morris failed because there was no road. The road does not exist until you dig it.*

He sat down at the desk. He pulled a sheet of heavy Marcher vellum toward him—not the rough sheepskin, but the good vellum reserved for correspondence with the Bishop's commissary.

Taking the pen in his left hand, he began to draft an authorization.

*To the Bursary Gate, Griffin Academy. Under territorial dispensation of the Evans March...*

A knock rattled the lower door.

Lied froze. He slipped the vellum beneath the oat tally.

"Come," he said.

It was not Barend. It was Master Alder, the notary.

The old man came up the stairs wheezing, his sheepskin mantle pulled tight around his neck against the river damp. Behind him trailed a stranger—a small, stout man in a beaver-skin cap, wearing a thick traveler's coat of un-dyed wool fastened with silver toggles. The stranger was mud-splattered to the armpits and smelled powerfully of fried onions and stale horse.

"Master Lied," Alder wheezed, leaning his hip against the doorframe to catch his breath. "Forgive the hour. But this gentleman came off the south post-rider at Cross-Keys an hour ago. He was asking for the steward of the Lisle."

Lied did not move. He kept his left hand flat upon the desk, covering the draft.

"I am the steward," Lied said. "Who is asking?"

The stout man took off his beaver cap, revealing a bald, pink skull fringed with grease-grey curls. He bowed, an awkward, commercial duck of the neck.

"Barnaby Finch, sir. Agent of the Merchant Adventurers of the South Reach."

"The south?" Lied’s eyes narrowed. "Lisle has no business with the South Reach. Our wool goes to High Crag."

"Not wool, my lord," the agent said. He drew a heavy pigskin pouch from his coat, unbuckled its brass tongue, and withdrew a folded parchment yellowed with the smoke of old hearths. "Four years ago, before the second border levy, your noble father, Viscount Robert, advanced twenty-five barrels of salt beef and nine wains of oak-timbers to my late master, Master Thomas of Oakhaven, to refit the trade-ketch *The Heron*. Master Thomas died of the sweat in the capital before the voyage settled, and the account was sealed in the merchant court."

The agent laid the parchment on the edge of the trestle.

"The probate court cleared the estate last month, sir," Finch continued, his tone dry and professional. "Under the King's commercial ordinance, territorial debts take precedence over common creditors. The estate was ordered to satisfy the debt in royal gold at the nearest Marcher bailiwick. Twenty-eight gold sovereigns flat: twenty-five in original principal and three in statutory interest."

The room became very cold.

Lied looked at the document. He looked at the wax seal—the split anchor of the Oakhaven admiralty court, cracked at the edge but indisputably authentic.

He looked at Master Alder.

The notary was squinting through his bone spectacles at the paper. "It's Thomas's hand, sure enough," Alder muttered. "I witnessed the bond myself when your father’s men loaded the beef at the river wharves. We wrote it off as a bad venture three years back. The Viscount told the council he'd have Thomas's skin for shoes if the ketch didn't return, but the ketch sank off the White Headland."

"The ketch sank," Agent Finch agreed pleasantly. "But the cargo was underwritten by the Guild of Marine Underwriters at the capital. The draft cleared ten days ago."

The agent reached into his deep coat pocket and drew out a small, heavy box of pear-wood bound with iron straps. He set it upon the table.

He lifted the brass hasp.

Inside, nestled in chopped sheep-wool to prevent the coins from clinking on the road, were three neat rolls of gold coins wrapped in parchment.

*Royal sovereigns.*

Struck with the broad crown of the realm, heavy, yellow, and cold as river ice.

"Twenty-eight sovereigns," Finch said. "Full weight, twenty-five in principal and three in interest. If the steward will inspect the weight and grant the discharge receipt under the territorial seal, my business in the March is concluded."

Lied did not breathe.

His heart was hammering against his ribs with a violent, suffocating cadence.

Four years.

A four-year-old dead debt, written off by his father, forgotten by the estate council, buried in an admiralty probate court three hundred miles away in a city he had never seen.

A debt from a drowned ship.

And it had arrived at his table.

Not next month. Not last autumn. It had arrived at four o’clock in the afternoon on the fourth day before the vernal equinox, exactly forty-five minutes after Lied Evans had looked an old soldier in the eyes and lied to him about twelve gold sovereigns for his sister's schooling.

Lied looked at his left hand, resting motionless upon the desk.

The skin was pale. The knuckles were still red from the cold.

Beneath his fingers, the cedar shaving lay hidden.

*It wasn't a coincidence.*

The thought came to him not with the thrill of magic, but with the cold, hair-raising terror of a man who has casually pulled a loose hemp rope in the dark and heard the groan of an iron drawbridge rising behind him.

The world had not cared where the money came from.

The world had simply found the nearest uncollected balance, the oldest forgotten draft, the most plausible legal mechanism that lay within reach, and had dragged it across three hundred miles of turnpike to deliver it to this table before the word spoken in this room could fall to the ground and break.

"Master Lied?" Alder muttered, squinting at him over his spectacles. "Do you want me to test the weight on the scales? If the count is good, I have the lead seals in my bag. We can crate the box before nightfall."

Lied took his hand slowly from the desk.

"Crate it for whom, Master Alder?"

"For High Crag, of course," Alder said, as if explaining the weather to a child. "This is dead-debt restitution on an estate chattel from four years back. It belongs to Viscount Robert's personal chest. Under territorial statute, all probate recoveries over twenty crowns must be sealed under notary wax within three days and conveyed under armed escort to the central treasury. You cannot leave twenty-eight gold sovereigns sitting in a wooden drawer over a cow-shed, boy. If the auditors at the high castle find so much as a groat missing, your father will have the bailiff's ears, and mine along with them."

Lied stood up. He did not raise his voice; he moved around the table with that calm, deliberate precision he used when inspecting defective masonry.

"Agent Finch," Lied said politely. "The receipt of full discharge."

He took his quill, dipped it into the black ink, and signed the admiralty roll with his right hand, impressing the brass seal of the Lisle stewardship into the warm red wax Finch held out.

"Your business is concluded, Master Finch," Lied said. "Take your mule to the stables, eat your dinner, and sleep soundly. You have the March's clean release."

The agent bowed, pocketed his stamped charter with immense relief, and backed out of the room, leaving the door shut behind him.

Lied turned back to the notary.

Alder was already reaching into his satchel for the red lead-tape to bind the pear-wood chest.

"Leave the tape, Master Alder," Lied said quietly.

Alder paused, his withered brows drawing together in sharp suspicion. "Lied. I have known your father forty years. He does not forgive an unsealed ledger. If you think to touch a penny of this gold—"

"I am not touching a penny of it unlawfully," Lied interrupted, reaching behind him to the shelf of sheepskin-bound volumes. Without hesitating, his fingers pulled down a narrow, dust-covered folio: *The Statutes of Border Defense and Auxiliary Levies, Third Revision.*

He opened it to a ribbon marked three seasons ago and laid it flat before the notary's nose.

"Section fourteen, clause nine," Lied said, tapping a clean fingernail against the dried Latin text. "Read it."

Alder squinted, his lips moving soundlessly as he read the cramped chancery hand: "*...in the event that any frontier holding shall enter an active state of border alert following the capture of known outlaws, the resident magistrate or steward holds statutory discretion to retain all accrued penalty interest in full, together with up to four-tenths of any unbudgeted principal recovery within the district bailiwick, without prior warrant from the high chancellery... to be allocated toward defense reserve or the sponsorship of auxiliary scholars in the strategic arts.*"

Alder looked up, his watery eyes narrowing. "A state of border alert? What nonsense is this? The valley is quiet as a churchyard."

"The valley was quiet until two hours ago," Lied said, tapping Barend’s leather money-bag. "When Sir Barend dragged a horse-thief of the Black-Hedge clan off the high ridge. The prisoner is currently sitting in the county gaol under an official territorial bounty. An armed incursion across the boundary stone constitutes an active state of border alert under Marcher law, Master Alder. It has been signed by the magistrate, and the bounty was paid this morning."

The notary opened his mouth, then shut it again.

"Four-tenths of twenty-five sovereigns of principal," Lied continued with smooth, surgical precision, "is exactly ten sovereigns. Add the three sovereigns of statutory interest which the statute awards to the local district in full. That gives the Lisle stewardship thirteen gold sovereigns of completely autonomous, discretionary defense credit."

"And what strategic defense are you buying with thirteen sovereigns, boy?" Alder asked, though his voice had lost its certainty. "Iron pike-heads? Powder?"

Lied drew Lina’s Griffin certificate from beneath the oat roll and laid it beside the statute.

"Lina of the Lisle Tower," Lied said. "Admitted to the faculty of natural arithmetic and etheric geometry. Section sixteen defines all students of higher ether-craft under territorial bursary as reserve defense scholars of the March. Twelve sovereigns to the Bursary Gate of Griffin. She will owe the Evans March five years of military consulting upon graduation. It is legal. It is documented. And it is within the letter of my father's own laws."

Alder stared at the vellum, then at the open statute book, his jaw working slowly.

"Your father will know you twisted his words," the notary muttered. "He wrote that clause thirty years ago to buy horses during the hill-wars, not to send a soldier's sister to study numbers with the dukes."

"My father will see that his second son turned a drowned, forgotten debt of beef into an educated mage-scholar bound to House Evans for five years, while delivering fifteen gold sovereigns of unexpected profit into his central treasury," Lied replied, his eyes dark and steady. "He may call me a slippery bastard, but he will not call me a thief. And there is one more thing, Master Alder."

Lied picked up the thirteenth gold sovereign from the table and rolled it across the wood until it tapped gently against Alder’s knuckles.

"Under the provincial audit charter, a notary who executes a local defense retention in the field is entitled to a statutory composition fee of one gold sovereign, paid out of the retained interest. If this chest goes to High Crag unsealed, the Viscount’s high chancellor will take the processing fee, and you will receive fourpence for the courier hire. Sign the retention warrant, Master Alder. Take your sovereign. Enter the remaining fifteen sovereigns for the central treasury. And let the girl go to Griffin."

The old man looked down at the gold coin resting against his hand.

He looked at the open law-book, then at the cold, unyielding face of the seventeen-year-old boy standing before him.

A slow, wry grimace crossed Alder's wrinkled mouth, stretching the yellow skin over his cheekbones.

"Gods above," the notary muttered, shaking his head. "You have your grandfather's gall and your father's stomach for paper. Give me the seal."

Alder pulled the ink-pot toward him, took up his iron pen, and signed his name with a heavy, scratching stroke across the margin of the retention docket. He pressed his official ring into the wax, scooped the gold sovereign into his leather pouch with a single sweep of his palm, and pushed the twelve sovereigns toward Lied.

"May your scholars be worth the parchment, Master Lied," Alder said, turning the key in the remainder of the chest. "Because if she fails her exams, you will be answering this account in front of your father's council with empty hands."

"She will not fail," Lied said.

He picked up the twelve gold coins. They were heavy, cool to the touch, and unyielding.

The coin was real. But it was not the chance arrival of the Oakhaven draft that had saved him; it was the cold, patient knowledge of the law, the ruthless exploitation of an old soldier's capture, and the calculated bribe to an old notary that had built the road between his word and the world.

He had borrowed from the future. And with ink, silver, and statute, he had paid the first installment.
