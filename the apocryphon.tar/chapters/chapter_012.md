# Chapter 12: The Parley at the Ford

> *From the Commonplace Book of Lied Evans, Scholar of Griffin Academy:*
> 
> **[Unsettled — Written Left-Handed]**  
> *The Chieftain's Blood-Oath: a covenant of perpetual peace between the Orc Clans and the Evans March, carried under royal bone-seal.*  
> 
> **[Settled — Written Right-Handed]**  
> *The Blood-Debt of Gruk: twelve thousand silver groats of seized mountain spirits, discharged in full by blood-service at Raine Ford.*  
> *Captain Jem of the Frontier Guard: unmasked under the King's peace; Celestial Heart Demon purged before sunrise.*

***

The mist on Raine Ford was the color of dirty sheep-wool, smelling of freezing river silt and wet horse-iron.

It was four o’clock in the morning, two hours before the winter dawn, and the shallow gravel crossing where the road met the river was choked with eighty yards of black, fast-running water carrying needle-thin flakes of skimmed ice.

On the western bank, deployed in two tight, professional ranks behind timber palisades, stood forty men of the Frontier Security Guard, their heavy arbalests notched on their iron rests, the steel stirrups gleaming dully in the light of pitch-pine torches. Behind them were sixty Marcher militia, local tenant farmers armed with bills and boar-spears, their teeth chattering with cold and terror.

At their head sat Captain Jem on a heavy bay stallion. He wore black plate-armor without an armorial crest, his iron gorget fastened tight around his throat, his broadsword resting point-down upon his right stirrup. He sat with that rigid, unnatural stillness that belongs to dead wood or cold iron, not blinking as the sleet drove against his visor.

Across the eighty yards of grey water, on the eastern gravel reach, stood the orcs.

There were sixty warriors of the steppe clans—broad-chested, flat-faced men and women in boiled-oxhide coats and split-mail hauberks, their two-handed cleavers held across their chests, their wolf-dogs snarling on hemp leashes. At their center was Elder Morkar, a massive, white-bearded shaman leaning on an ash spear bound with horsehair braids. They had come to trade winter peltry; they had found forty crossbows leveled at their chests.

The wind from the high defiles shrieked through the bare willows, rattling the willow-switches like dry bones.

"Captain Jem!" called the militia sergeant, his voice cracking with the nervous, frantic tremor of a man who wants to run. "They're shifting their ranks! The shaman is chanting! If we don't loose now, their vanguard will hit the shallows before we can cock the winches!"

Jem did not turn his head.

His right hand rose slowly, the black steel gauntlet closing around the hilt of his broadsword.

"Wind the arbalests," Jem commanded. His voice was flat, dry, and possessed of a terrible, mechanical emptiness that lacked all human heat. "Aim for the women and the pack-beasts. When the line breaks, the horse will charge the shallows. Spare no one."

The steel cords groaned as forty winches turned in unison.

"Loose—"

A solitary horn-call tore through the freezing fog.

It was not a military bugle; it was the sharp, insolent blast of an Academy post-horn, high, clear, and ringing like silver off granite.

Before Jem could drop his blade, a single rider exploded out of the willow bottoms, splashing into the river shallows at a dead gallop.

The roan gelding hit the icy water with a roaring shower of spray, its hooves churning the gravel bars, lunging straight into the sixty yards of black water that separated the two battle-lines.

"Hold!" a voice rang out across the water.

It was not a general’s roar; it was the crisp, aristocratic command of a lord cutting through the clamor of an unruly tenant court.

Lied drew rein in the middle of the ford, water foaming around the roan’s stirrups.

He was eighteen, bare-headed in the freezing sleet, his dark hair plastered against his temples, his scholar’s bottle-green mantle soaked to the waist. He wore no armor except the rented mail gorget at his throat, and in his right hand, held high above his head for every man on both banks to see, was an antique scroll-case of yellowed mammoth-bone, carved with the runic sun-wheel of the ancient high kings.

The scroll-case was entirely empty.

Lied sat his shivering horse beneath forty leveled arbalests, his face calm, his posture unhurried, his grey eyes locked directly onto Captain Jem across twenty paces of swirling river water.

"Lower your steel, Captain," Lied called out, his voice carrying over the roar of the current with the effortless resonance of an open bell. "You are looking upon an envoy of the High Chancery of House Evans, bearing the Great Charter of the Northern Defiles."

The militia sergeant lowered his crossbow an inch, his mouth hanging open. "Master Lied? The young steward?"

Jem’s bay stallion stepped into the shallows, the water rising to its fetlocks. The possessed captain’s eyes, pale and dead beneath his visor, fixed upon Lied with that strange, vibrating hesitation that always seized heart demons near the Evans boy.

"Candidate Evans," Jem said, his voice grating like an iron file against bone. "You are interfering with a royal security action under ducal charter. The barbarian tribes have committed open murder upon the King’s highway. Return to the bank, or you will be shot where you sit."

Lied gave a clear, ringing laugh that echoed off the granite bluffs.

"A royal security action?" Lied sneered, leaning forward over his pommel with withering contempt. "Against an official diplomatic embassy of the High Steppes? You are illiterate, Captain Jem, or your ducal master forgot to teach you the King's commercial treaties."

Lied shook the bone scroll-case, the hollow ivory rattling loudly in the freezing air.

"I hold here the Blood-Oath of the Great Chieftain of the Iron Steppes," Lied declared, projecting every syllable toward the ranks of the Marcher militia. "A covenant of perpetual peace, sealed in ancestral blood before the winter solstice. The Chieftain has formally disavowed the raiders of the Red Reach road. He has condemned the arsonists as outlaws, and this embassy has ridden three hundred miles through the snow to deliver the formal blood-restitution into the hands of House Evans!"

A stunned, disbelieving gasp rippled through the militia lines.

On the eastern bank, the orcs did not lower their cleavers, but Elder Morkar’s white head snapped up, his yellow eyes narrowing in profound, suspicious shock. The shaman had signed no covenant; the Chieftain was forty leagues away across the high passes.

"He lies," Jem hissed, his horse backing into the foam as the heart demon beneath his ribs fluttered with sudden, violent agitation. "The orcs sign no treaties! It is a trick to gain time! Crossbows—"

"Shoot me, Captain," Lied interrupted, his voice dropping into that terrifying, icy calm that brook no contradiction. "Shoot the son of Viscount Robert Evans while he stands as sworn herald under the bone-seal of the realm. Shoot me in front of sixty Marcher tenants who know my name, my face, and my brother’s cavalry. Shoot me, and my father will hang you and your entire garrison from the willow trees before the frost melts."

Lied thrust the bone case toward the militia sergeant.

"Under territorial law, a treaty under bone-seal must be examined and read aloud before a single bolt is loosed! We wait for the dawn bells. When the first light touches the high peak of the Crag, the seal will be broken before both armies. If the blood-oath is false, you may loose your bolts. But if you loose one bowstring before the sun rises, you die as traitors to the Crown."

The militia sergeant lowered his weapon entirely, his men following his lead, stepping back from the water’s edge with stubborn, peasant solidarity. They would fight savages, but they would not shoot their lord's son for a southern captain with cold eyes.

Jem sat rigid in his saddle, his broadsword trembling in his grip.

He had forty crossbows, but thirty of them belonged to local men who would not loose upon an Evans.

"Until dawn, boy," Jem whispered, his voice dark with venomous fury. "Two hours. And when your empty bone-case is opened, I will take your head myself."

Lied did not answer.

He turned his horse in the deep water, facing east into the freezing wind, watching the black, jagged wall of the mountains.

He had bought two hours.

And forty leagues away, across three feet of fresh mountain snow, the road was completely blocked.

***

Five hours earlier, in the high pass of the Black Chimney, the world had come to an end.

A massive wall of gray shale and uprooted pine, saturated by the winter thaw, had collapsed across the narrow gorge, blocking the ancient pack-trail with fifty thousand tons of shattered limestone. Beyond that gorge, barely six leagues across the eastern plateau, lay the winter encampment of the Great Chieftain; but between the riders and the kraal stood fifty feet of solid rock.

Gruk had sat on his huge black courser, staring at the impassable grey barrier with his tusks bared in hopeless, snarling agony, his runners weeping with exhaustion as they clawed uselessly at the stones with their bare hands.

Then the cart had arrived.

It was a small, two-wheeled postal dray drawn by a foam-lathered mule, chartered three hours before midnight when an urgent slip of vellum in Lied’s spidery hand had been shoved under the door of the Academy's ether-laboratory: *Jem is marching on Raine Ford; Sir Barend’s garrison is in the line; the high road will be blocked before dawn.*

Lina of the Tower had jumped from the box before the wheels stopped, her face pale, her linen coif caked in road-grit, hauling a heavy pine chest filled with glass carboys and copper wire onto the snow. She had used her student requisition warrant to clean out the laboratory's emergency supplies of unrefined etheric acid—not for Lied, but because she would tear the mountains down before she let an Evans duke slaughter her brother in a muddy ditch.

"Stand back, you great stupid ox!" she had screamed at Gruk, pushing the three-hundred-pound orc aside with the fury of a wild-cat.

"The road is dead, girl!" Gruk had roared, his fists tearing at his hair. "The mountain has fallen! We cannot cross before noon!"

"The mountain is made of limestone and quartz," Lina had snapped, her hands flying over her chalk-slates, her pencil moving across the ratios of etheric combustion with terrifying, machine-like speed. "Limestone dissolves under an acidic thermal inversion. If I align thirty pounds of unrefined ether-crystals along the cleavage plane of the lower bedding-stratum and ignite them with an imperial percussion-cap, the expansion gradient will throw seventy percent of the rubble into the southern ravine."

"What is she talking about?" Gruk had babbled, looking at his warriors.

"Shut up and carry the jars!" Lina had shrieked, shoving three heavy earthenware carboys of volatile etheric acid into his arms. "Put the blue ones where I marked the chalk! If you spill a drop, your feet will burn off to the ankles! Move, you miserable barbarian, move!"

For two hours, while the freezing rain turned to sleet, the fifteen-year-old commoner girl had directed forty orc warriors through the snow, driving copper rods into the fissures, measuring geometric angles with a string and a lead bob, her thin fingers bleeding from the jagged stones.

Then she had struck the iron flint.

A blinding, roaring thunder-crack had split the night—not a crude gunpowder blast, but a clean, terrifying expansion of blue celestial fire that had sheared through forty feet of solid limestone along the bedding planes with the precision of a diamond-saw.

The rubble had cascaded into the ravine with a sound like a mountain falling into the sea.

The road was open.

Gruk had thrown the girl onto the croup of his courser, spurred the black beast until the horse screamed, and charged into the eastern dark toward the Great Chieftain's kraal like an arrow loosed from an ash bow.

***

At Raine Ford, the first thin, grey line of dawn was beginning to touch the high granite tooth of High Crag.

The sleet had turned to cold, drifting mist.

On the western bank, Captain Jem dismounted. He walked into the shallow water, his broadsword drawn in his right hand, his black plate-armor clinking softly against his spurs.

"The sun is up, Candidate Evans," Jem said, his voice flat, dead, and utterly devoid of mercy. "The bells are striking at the chapel. Deliver the bone-case, or I give the order."

Lied sat his horse in the middle of the river.

His lips were blue with cold; his legs had lost all feeling beneath the freezing water.

He held the bone scroll-case in his left hand.

The turnpike road out of the eastern mountains was silent. There was only the wind in the bare willows and the dull murmur of the water over the stones.

*An open road,* Lied thought, his jaw clamped shut to stop his teeth from chattering. *I dug the road. But the wagon is late.*

Jem stepped forward, the water rising to his knees.

He reached out his left gauntlet to snatch the bone case from Lied’s hand.

"A cheat," Jem hissed, his mouth curling into a triumphant, demonic snarl. "A hollow trick from an under-clerk’s son. You have nothing."

A thundering, earth-shaking roar exploded from the eastern ridge.

It was not a horse. It was an avalanche of black horse-flesh, screaming foam, and iron-shod hooves tearing through the scrub.

Gruk burst out of the pine trees on his black stallion, the beast bleeding from both nostrils, its flanks white with lather. Behind him, clinging to his broad leather belt with both hands, her teeth bared in feral triumph, was Lina.

The orc charged into the river shallows without checking his stride, throwing a massive, blood-smeared bundle of cured bull-hide straight through the air toward the middle of the ford.

"Lied!" Gruk bellowed, his voice rattling the bluffs like a war-drum. "Take the oath!"

Lied caught the bundle against his chest with both hands.

The hide was wet. It was warm.

It smelled of fresh blood, wild sage, and horse-sweat.

Spread across the five-foot square of cured leather, painted in three broad strokes of hot, dark arterial blood, was the twin-horned mark of the Great Chieftain of the Iron Steppes, impressed over with the ancient bronze seal-stone that had not left the high altars in four hundred years.

The Chieftain had signed.

Lied unrolled the leather with a single, sweeping snap of his wrists, holding the blood-red glyphs high before the eyes of both armies.

"The Blood-Oath stands!" Lied shouted, his voice ringing with the immense, triumphant weight of a promise that had been dragged across seventy miles of mountain rock to land upon this river before the clock could strike. "Signed by the Chieftain! Sworn under blood! The war is dead!"

On the eastern bank, sixty orc cleavers slammed against sixty iron shields with a deafening, rhythmic roar: *"The Oath! The Oath! The Oath!"*

The Marcher militia on the western bank threw their caps into the sleet, cheering until their throats bled, weeping in the sudden, blinding relief of men who had been pulled back from an open grave.

Jem stood frozen in the middle of the river.

His black gauntlet dropped to his side. The dead, pale eyes beneath his visor widened with absolute, disbelieving horror.

The plan was broken. The war was dead.

"No," Jem whispered, his voice trembling with a high, cracked, monstrous vibration that did not belong to a human throat. "No... the Duke... the legions... the blood must flow..."

He raised his broadsword with both hands, lunging through the water straight at Lied’s horse, his face twisting into a hideous, slobbering mask of inhuman fury.

Before his blade could fall, a shadow dropped from the willow branches above the bank.

It was Isolde Gregory.

She came down like an owl—silent, black-clad, hitting Jem’s shoulders with the full, bone-crushing momentum of an executioner.

Her thin stiletto drove through the gap in his neck-guard, severing the tendon of his right arm. Jem gave a high, gurgling shriek, dropping his sword into the shallows as they crashed into the gravel together.

Isolde pinned his left arm to the stone with her iron-plated knee, her dagger point pressed against his eye-slit.

"You dropped these on the turnpike three nights ago, Captain," she murmured coldly, tossing a brass container of military ether-naphtha onto the wet stones. "Master Brutus sent me to collect the property of the Crown."

Lied dismounted from his roan, stepping through the freezing shallows until he stood over the thrashing, pinned officer.

He did not draw his sword.

He reached inside his tunic, drew out the salt-tempered iron key from Brother Marcus—the five-toothed ward-key cast from church-iron to seal the Cathedral’s Reliquary of Anathemas against demonic corruption. Channeling the cold, crystalline clarity of his left hand, Lied forced his own etheric awareness through the metal, awakening the consecrated runes forged into the iron teeth, and slammed the holy ward directly against the center of Jem's chest, right over his left ventricle.

"In the name of the Seven Lights and the territorial peace of the March," Lied said, speaking with that terrible, quiet authority that carries the weight of a sovereign court, "show your master."

The consecrated iron touched the skin beneath the slashed doublet.

A sound broke from Jem’s throat—a high, bubbling, insectoid shriek that sent twenty horses rearing back in the water as the demon inside him met the unbearable rejection of consecrated iron.

Beneath the wet wool of his shirt, the skin of his chest began to convulse.

A dark, pulsing crimson knot, the size of a pigeon’s egg, bulged outward through the muscle, fluttering with the obscene, frantic heartbeat of a trapped wasp. The flesh split; a cloud of black, sulfur-reeking smoke hissed into the freezing air, and from the open wound emerged a pair of tiny, segmented mandibles of semi-translucent scarlet chitin, snapping frantically at the light.

*A Celestial Heart Demon.*

The sixty Marcher militia stumbled backward in screaming, retching horror, crossing themselves, dropping their spears into the mud.

The two royal proctors and the county bailiff, who had just arrived on the western ridge with the morning post, stared down at the river shallows with faces as white as chalk.

It was seen.

By sixty soldiers, forty orcs, three Academy scholars, and the sworn officers of the county bench.

It could not be denied; it could not be papered over; it could not be buried by a duke’s chancellor in the capital.

The demon shrieked once more, withered under the cold morning light, and dissolved into a puddle of black, foul-smelling grease upon the stones of the ford.

Jem’s body went limp in Isolde’s grip, his dead eyes rolling back into his skull.

The ford fell into an absolute, ringing silence, broken only by the steady rush of the cold winter water through the gravel.

Lied stood in the shallows, the bloody bull-hide of the peace-covenant resting across his arm.

He turned his head.

On the eastern bank, Lina was sitting on the gravel by Gruk’s horse, her thin shoulders shaking, her hands black with ether-burns, weeping with the silent, exhausted fury of a girl who had worked a miracle and hated the world that had demanded it of her.

Beside her, Gruk waded slowly into the shallow water, his massive boots crushing the ice-rinds. The huge orc looked down at the dead demon, then at the blood-signed covenant of the Great Chieftain lying across Lied’s arm.

"Sixty casks of brandy are puke in the dirt, student," Gruk rumbled, his tusks bared in a broad, ferocious grin that carried no mockery. He drew his hunting dagger, swept the edge across the scarred leather of his left bracer, and shaved away the dried crust of his blood-vow with a single, slicing stroke. "You gave my people back the river road, and you saved my sister’s kraal from the Duke’s fire. The blood-debt is dead. From this sunrise to the end of snows, the clans ride with the Evans boy."

The blood-debt was paid. In full.

Lied drew out the split-calf book from his coat with his left hand, the parchment pages fluttering in the morning wind.

He dipped his iron pen into the black gall-ink.

With a firm, heavy stroke of his right hand, he drew a single, clean line of black ink through the entry on the left:

*The Chieftain's Blood-Oath: a covenant of perpetual peace...*

Beneath the scored trench, on the right-hand page, he inscribed:

*Ratified at Raine Ford under the eyes of forty witnesses. The war never happened.*

He closed the book with a dry, solid thud that sounded like an iron gate clicking into its post.

The winter sun broke through the clouds above High Crag, throwing long, clean golden shafts of light across the river, warming the water where the blood had washed away into the sea.
