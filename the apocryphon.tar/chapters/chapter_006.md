# Chapter 6: Making It True

> *From the Commonplace Book of Lied Evans, Steward of the Lisle Holding:*
> 
> **[Unsettled — Written Left-Handed]**  
> *The Lisle–Auden Diversion Covenant: to be sealed with the Marcher Great Falcon and ratified by the Auden clan elders before the seventh day expires.*  
> 
> **[Settled — Written Right-Handed]**  
> *Riding horse hire and toll-bridge fees, High Crag turnpike: twelve silver groats.*  
> *Auden family notary search-dues at the Priory of Saint Jude: two silver crowns.*

***

A lie told to keep back seven feet of river water has a lifespan of about thirty seconds; a lie told to a Marcher baron over a hearth-fire lasts until the third day, when his factor begins to calculate the interest on paper.

Lied had precisely four days left.

On Saturday morning, Baron August Auden’s senior bailiff would saddle his black mule, ride up the gravel highway to the high granite walls of High Crag, and present himself at Viscount Robert’s chancery with an iron scrip-box under his arm. He would ask for the ratified copy of the supplemental covenant, the formal schedule of the ten-percent iron rebate, and the counter-signature of the Marcher treasury.

And the Viscount’s high chancellor, a dried-up canon of the cathedral who had counted every copper penny that had passed through House Evans since the third year of the hill-wars, would look over his spectacles, discover that no such council had ever sat, no supplemental warrant had ever been drafted, and conclude that Viscount Robert’s seventeen-year-old second son had committed high territorial forgery in the name of forty tenant cottages and a field of rye.

Lied sat in the small timber tap-room of the Cross-Keys coaching inn, a pint of thin cider sitting untouched beside his elbow.

Spread across the table before him were two documents.

The first was a clean sheet of heavy imperial vellum, the texture of kid-leather, which he had purchased for four silver groats from the Cathedral illuminator. Upon it, using his right hand and the formal, unyielding chancery script of the high bench, Lied had drafted the text of the *Supplemental Water-Covenant and Sluice-Right of the Lisle River.* It contained thirteen clauses, each balanced with the ruthless, legalese precision of a veteran conveyancer. To circumvent the high chancery’s statutory limits on permanent alienations, Lied had structured the instrument not as a perpetual grant, but as a *triennial rolling service-covenant*: it granted House Auden their ten-percent rebate on crude pig-iron shipped through the river wharves, legally capped at thirty-six sovereigns in any single fiscal year; and in return, it bound the heirs of Auden to hoist their three western relief-gates whenever the river touched the three-foot-eight notch on the stone pier—four inches lower than the old treaty, securing the Lisle meadows against summer spates forever.

It was an exquisite piece of statecraft.

It lacked only two trifles to become sovereign law: the clan seal of House Auden, and the Great Falcon seal-ring of Viscount Robert Evans.

"Master Lied," said Sir Barend, stepping into the booth and pulling the baize curtain across the arch. The knight had spent forty-eight hours in the saddle, his eyes veined with red, but he had shaved his jaw and wore his formal Marcher mantle. "I found him."

Lied looked up. "Where?"

"The Priory of Saint Jude, three leagues above the gorge," Barend said, leaning across the table and speaking beneath the roar of the tavern hearth. "He lives in the dower-house behind the chapter-stalls. Half-blind, seventy-four years old, and hates his nephew August enough to spit at the sound of his name."

"Elder Jethro," Lied murmured, tapping his finger against the table.

"The same," Barend nodded. "When August’s father died twelve years back, Jethro claimed the clan wardenship under the old copyhold charter. August called in three mercenary lances from the low country, locked the old man out of the high keep, and pensioned him off on forty sheep and ten barrels of salt-pork a year. Jethro hasn't spoken to the hall in eight years, but under the clan foundation charter, he still holds the second key to the family vault and the elder's raven-stamp."

Lied folded the vellum neatly along its middle crease and slipped it into his leather portfolio.

"Finish your cider, Barend," Lied said, rising and reaching for his wool mantle. "We are going to pay our respects to the church."

***

Elder Jethro Auden sat in a wicker armchair before a miserable hearth of damp alder-roots, his knees wrapped in a mold-spotted bearskin. His hands trembled with the palsy of old age, his knuckles swollen to the thickness of walnuts, but his eyes, watery and yellow around the irises, fixed upon Lied with the suspicious, venomous sharpness of an old badger in a ditch.

On the table between them sat a stoneware bottle of dry plum brandy and the small, iron-bound box containing the Auden clan seal.

"Ten percent on the iron," the old man rasped, his voice whistling through three broken front teeth. "The boy thinks he's clever. August is a thief, a glutton, and the son of a sow, but he knows what pig-iron is worth. My brother sold the river rights for fifty gold nobles thirty years ago, and August gave away the family dikes for nothing."

"Baron August did not give them away for nothing, Elder Jethro," Lied said mildly. He sat on an uncarved three-legged stool, his posture deferential, holding a horn cup of the bitter brandy without drinking. "He gave them away to save his own bullocks on the flats. But the covenant he signed five years ago was an informal memorandum with my father's bailiff. It has no clan standing."

Lied leaned forward, his voice dropping into that quiet, confidential cadence that invites a listener into an inner circle of grievance.

"The Marcher chancery cannot ratify a treaty that lacks the elder clan signature," Lied continued smoothly. "Under the ancient customs of the Northern Defiles, an alienation of territorial water-rights requires the assent of the senior blood-heir. If Baron August signs alone, the iron rebates are paid directly into his personal privy purse. He will use the silver to hire more low-country lances, buy rich southern wine, and laugh at the priory."

Jethro’s jaw worked savagely. "The bastard would," he hissed, his trembling hands clutching the fringe of the bearskin. "He bought two velvet doublets last winter while my roof-timbers were dripping rain onto my bed."

"Sign the confirmation as Clan Warden, sir," Lied said, drawing the heavy vellum from his folder and laying it beside the iron seal-box. "Clause nine specifies that one-tenth of all rebate silver is paid directly to the Warden's hospice at Saint Jude for the perpetual maintenance of the family tombs. August cannot touch it; the Viscount’s auditors will pay it directly to the Prior’s bursar."

The old man squinted at the parchment. He could not read the Latin clauses, but his finger traced the ink where the word *Saint Jude* stood in red chancery capitals.

"One-tenth," Jethro muttered. "Thirty gold crowns a year... paid to the Prior..."

"For your table, sir," Lied whispered softly. "And for firewood that doesn't smoke."

The old man looked up at Lied. There was a moment of ancient, cunning hesitation—the suspicion of an old peasant who has lived through fifty years of Marcher treachery. Then Jethro gave a dry, cackling rattle that passed for a laugh.

"Give me the wax," the elder barked.

Five minutes later, Lied walked out into the priory cloister.

In his folder lay the vellum. At the bottom, beside the space left for Viscount Robert, was the crude, sprawling signature of Jethro Auden, pressed over with the deep, sharp impression of the three ravens in dark green wax.

One half of the bridge was built.

Now he had to steal the stone for the other.

***

High Crag rose above the northern gorge like an iron hammer dropped into the pine forest.

It was not a palace of marble and glass like the châteaux of the capital; it was a brutal, wind-scoured mountain fortress of black granite, its curtain walls twenty feet thick at the base, its battlements bristling with iron balistas aimed north toward the barbarian ridges.

Lied rode through the portcullis on Sunday afternoon, twenty-four hours before Baron August’s bailiff was due.

The outer bailey was in an uproar. Three companies of Marcher heavy horse had just returned from the northern border muster, their armor caked in grey road-mire, the grooms shouting over the whinnying of stallions, the air thick with the smell of wet horse-blankets, roasted mutton, and wood-tar.

Lied did not go to his father’s great hall.

He walked straight to the armory tower, where the clatter of steel on stone was loudest.

In the armorer's vaulted gallery, his elder brother Rodney was sitting on an upturned oats-barrel, stripped to his leather arming-doublet, his thick, muscular forearms glistening with sweat. A blacksmith was kneeling before him with a pair of pincers, levering a bent iron plate from the calf of Rodney's greave where a crossbow bolt had grazed the steel.

"Lied!" Rodney bellowed, his broad, sun-reddened face breaking into an enormous grin the moment he spotted his younger brother in the doorway. "Look at this! Three inches higher and the dog would have taken my kneecap! Did they tell you down in your cabbage-patch? We rode forty leagues through the high scrub, burned two raider stockades, and took sixty mountain ponies before the frost broke!"

"I heard the horns from the lower valley," Lied said, stepping over a pile of chainmail links and clasping his brother’s greasy forearm. "You look like you've been sleeping in an iron stove, Rodney."

"I have been sleeping in an iron stove," Rodney laughed, wincing as the smith hammered a rivet home with a sharp *clack*. "Three weeks in the saddle, living on dried beef and sour beer. The Viscount is in the council chamber with the captains, arguing over the fodder bills. He’s in a foul temper—the treasury clerk told him the campaign ran three hundred crowns over the estimate."

Lied’s pulse remained perfectly steady.

"Speaking of fodder bills," Lied said, slipping his portfolio onto the armorer's workbench beside a stack of requisition orders. "I brought the midsummer flood returns for the Lisle. The Upper Weir jammed on Thursday; we lost four hurdles and two ash wedges, but the embankments held."

"Good boy," Rodney said carelessly, leaning back against the wall while the smith buckled the repaired greave. "I told the old man you'd keep the ditchers from drowning. Did you need money?"

"Not money," Lied said. He drew a bundle of seven documents from his case—all of them legitimate, routine Marcher dockets: timber-salvage permits, ditch-clearing scrip, and fodder allowances for Barend’s patrol.

Sandwiched neatly between the third and fourth sheets, with only its margin and signature line visible beneath the parchment flaps, was the *Supplemental Water-Covenant.*

"I need the Marcher seal on the emergency timber-clearance vouchers," Lied said, his tone dry, bored, and completely official. "The smith at Cross-Keys won't sharpen the estate's axes without the Viscount’s stamp, and my own seal only covers five crowns."

Rodney reached for the small leather pouch hanging from his belt.

Attached to his girdle was a heavy iron key and a silver signet ring—not the great territorial seal of the March, which Viscount Robert kept in his private vault, but the *Falcon Privy Seal*, the second seal used by the heir and the marshals for signing military warrants and administrative expenditures during active service.

Under Marcher law, the Falcon Privy carried the full authority of the house on all regional service warrants and rolling contracts beneath a single-year encumbrance of fifty gold sovereigns—a statutory boundary that Lied’s thirty-six-sovereign triennial clause cleared with fourteen sovereigns to spare.

"Take it," Rodney grunted, unhooking the signet and tossing it across the workbench. "You have the steady hand. Stamp the lot, sign my name on the fodder vouchers, and leave the papers with the clerk. If I have to read another line of Latin tonight, I'll choke."

Lied caught the heavy silver ring in his left hand.

The metal was warm from his brother's body.

"I'll have them filed before the bell strikes five," Lied said.

He stepped to the writing desk in the corner of the armorer’s lodge, out of the glare of the hearth.

His hands did not tremble.

He took the round cake of red sealing-wax, softened the corner over a grease candle, and smeared a thick, scarlet circle upon the parchment.

He laid Jethro’s clan covenant flat.

With his right hand, he pressed the silver Falcon into the hot wax until the three talons and the hooked beak took deep, razor-sharp form in the scarlet pool. Beneath it, in a firm, flowing clerk's hand, he inscribed: *Confirmed under the Privy Seal of the March, Rodney Evans, Lieutenant-General of the Defiles, for Viscount Robert.*

The seal was authentic. The signature was authentic.

The treaty was alive.

***

The gap, however, remained.

Lied rode out of High Crag before sunset, leaving the ratified document in the hands of the high chancellor’s under-clerk, with strict instructions that it was to be handed to Baron August Auden’s bailiff upon his arrival on Saturday morning.

When the bailiff presented his credentials, the clerk would cross-check the roll, find the document already signed by Rodney and Jethro Auden, enter the ten-percent rebate into the toll-schedule, and file the roll in the stone presses without disturbing the Viscount over a routine matter of drainage.

Baron August would get his iron rebate.

The Lisle holding would keep its floodgates open.

The lower village would never drown.

But as Lied rode south beneath the gathering twilight, listening to the steady clop-clop of his horse’s shoes on the limestone road, the cold arithmetic of the world asserted itself in his mind.

A ten-percent rebate on four hundred tons of northern iron was thirty-six gold sovereigns a year.

Under the Marcher budget, that shortfall would not appear on Viscount Robert’s table this week, or next month. It would appear at the great annual audit at Michaelmas, two years from now, when the total revenue of the river wharves was tallied against the high treasury projections.

There would be a hole.

A quiet, gaping deficit of seventy-two gold sovereigns in his father’s books, sitting squarely beneath the line marked *Lisle District Tolls.*

The Viscount would not execute his son for a treaty that saved the valley; but he would require every single copper groat of that shortfall to be paid back out of Lied’s personal allowance, his future inheritance, and the rents of the Lisle estate.

Lied touched his breast.

Beneath his fustian coat, the split-calf book rested flat against his ribs.

He had not escaped the cost.

He had merely converted a sudden, violent catastrophe—a wall of mud and water that would have destroyed four hundred human lives in an afternoon—into a slow, grinding debt of thirty-six sovereigns a year, payable in silver and labor over the next decade of his youth.

He pulled his horse up on the high ridge overlooking the Lisle valley.

Down in the twilight, the river was running smooth and yellow within its banks, the green rye meadows spreading peaceful and intact toward the dark willow bottoms. In the lower village, three dozen chimneys were sending up straight, thin threads of blue woodsmoke into the evening air.

A faint smile touched the corners of Lied’s mouth.

It was a terrible bargain. It was an impossible burden for a seventeen-year-old boy with no lands of his own and five crowns in his pocket.

*A debt drawn against the future.*

He had built the road. Now he would have to spend the next five years paving it with gold.

He touched his heels to the roan’s flanks and trotted down the hill into the gathering dark.
