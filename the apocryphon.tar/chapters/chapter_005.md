# Chapter 5: The Late Flood

> *From the Commonplace Book of Lied Evans, Steward of the Lisle Holding:*
> 
> **[Unsettled — Written Left-Handed]**  
> *The Lisle–Auden Diversion Covenant: stands in full legal force and will be ratified under renewed Marcher terms before the high council at Lammas.*  
> 
> **[Settled — Written Right-Handed]**  
> *Lisle Upper Sluice: reinforced with six oak baulks and forty gravel hurdles: three crowns, two groats.*  
> *Emergency courier mount to High Crag: one brown mare, wind-galled at the left hock: compensated under Marcher transport scrip.*

***

The rain had begun on Tuesday as a dull, steady northern drizzle, but by Thursday night the wind had swung around from the high peaks, bringing down a black deluge that turned the mountain brooks into roaring torrents of mud and uprooted pine.

Lied was awakened at three in the morning by the drumming of horse hooves in the courtyard.

He was out of his bed before the rider hit the gravel, pulling his wool tunic over his linen shirt in the dark. When he reached the solar landing, holding a smoking pine taper, Sir Barend was already clumping up the wooden treads, water cascading from the skirts of his boiled-leather coat like rain from an eaves-trough.

"The marker-stone at the lower bend is gone," Barend said without greeting. His breath came in ragged, white plumes. "The water rose two feet between midnight and the third watch. The ditchers are out with torches, but the gravel bank at North Dike is weeping yellow soup. If the crest hits us before dawn, the lower meadows and the seed-barns are drowned."

Lied did not swear. He thrust the pine torch into an iron sconce on the wall, walked to the deed-press in the corner, and turned the heavy brass key.

"The diversion covenant," Lied said calmly, his fingers flicking through the parchment rolls tied with rot-softened leather thongs. "My grandfather signed a thirty-year drainage pact with old Lord Auden when the canal was cut. When the river passes the four-foot notch on the boundary pillar, Auden is bound by territorial law to open the three western floodgates and divert the surplus across the Stony Flats."

"They haven't opened," Barend barked. "I rode past their boundary ditch an hour ago. The oak sluice is dropped tight, the iron chains are padlocked, and Baron August has two men with crossbows sitting in the gate-house with a fire going."

Lied’s fingers found the roll.

It was tied with silk tape that had faded from green to dirty yellow, sealed with the three crows of House Auden.

He pulled the tape. He spread the vellum flat upon the trestle table beneath the smoking taper.

His eyes ran down the Latin clauses, skipping the titles and the long invocations of the Light, searching for the term-schedule at the bottom.

His finger stopped.

A cold, hollow sensation opened in his gut.

*Term: thirty years from the feast of Saint Michael.*

Lied did not need a slate to do the arithmetic. His grandfather, Viscount Edward, had signed the covenant thirty-five years ago, in the year of the three moons. The thirty-year term had expired five years back, during the long autumn when Viscount Robert had taken an arrow in the shoulder at the border siege and lay fevered at High Crag for four months.

The treaty had lapsed. Nobody had renewed it. Nobody had even read it. For five years, the Lisle holding had existed downstream of a locked dam by mere habit, relying on dry summers and the lazy assumption that an expired piece of sheepskin still held back the river.

"Master Lied?" Barend’s voice dropped, catching the sudden stillness in the boy's shoulders.

"The covenant expired five years ago," Lied said quietly. He rolled the vellum shut, snapping the rotten silk ribbon. "Baron August owes us nothing. If the water breaks our dykes, he loses two acres of sour brush, while we lose half the winter rye and forty tenant cottages."

Barend cursed, a short, vicious soldier’s blasphemy. His hand dropped to the hilt of his broadsword. "I have six horses. We can ride to the gate-house, break the chains with an iron maul, and hoist the sluice ourselves."

"And by noon Baron August would have twenty horsemen in our fields and a formal petition of armed trespass before my father’s council," Lied said. He reached for his riding boots, jamming his heels into the stiff, wet leather. "You don't fight a Marcher baron over a broken lease with six garrison troopers, Barend. You fight him with the one thing he fears more than water."

"And what is that?"

"A worse agreement," Lied said.

He took his heavy oiled mantle from the peg, picked up the calfskin ledger from the desk, and tucked it into his breast.

"Saddle the roan," he told the knight. "And bring your livery coat with the Evans crest. You are not an armed raider tonight, Barend. You are the escort to a formal diplomatic envoy of the March."

***

They rode north along the river road in the teeth of the gale.

The Lisle was no longer a river; it had become an angry, swollen monster of yellow foam, carrying bloated sheep-carcasses, fence-rails, and masses of tangled hazel-brush that battered against the stone piers of the bridges with the sound of muffled cannon-shot. In the low pastures, lanterns flickered through the rain where tenant families were frantically driving pigs and cattle up the wet slopes toward the churchyard.

Near the boundary weir, where the Auden canal branched off to the western flats, a crowd of figures was labouring in the driving rain.

They were not soldiers. They were peasant women, gray-haired cottars, and half a dozen novices from the nearby convent of the Open Link, all soaked to the skin, dragging wicker hurdles filled with river gravel to shore up a crumbling earthen shoulder.

Among them was a young woman in the coarse, unbleached linen habit of a novice nun, her veil pinned back with iron skewers, her bare forearms smeared with black clay. She had a timber lever braced beneath an oak hurdle, throwing her whole slender weight against the wood to hold the breach while two old men shovelled sod around the base.

She looked up as the horses splashed through the shallows.

Her face was pale, scrubbed raw by the wind, her grey eyes wide with exhaustion and an unyielding, fierce devotion. She looked at Lied’s green mantle, at the silver crest gleaming on Barend’s breastplate, and for an instant her breath caught, her hands freezing on the muddy lever.

Lied did not halt. He touched his hat-brim to her in passing, his voice cutting through the roar of the water: "Hold the bank another hour, Sister! The gates are coming up!"

He drove his heels into the roan's ribs and thundered past the weir, galloping up the gravel rise toward the stone towers of Auden Hall.

***

Baron August Auden received them in his lower hall, wearing a fur-lined bed-gown over his breeches, his graying hair uncombed, holding a steaming posset of spiced ale in a silver-gilt cup.

He was a squat, broad-shouldered man of sixty with the suspicious, heavy-lidded eyes of a border lord who spent half his life calculating road-tolls and the other half defending them from his cousins. Two men-at-arms with steel skull-caps and short partisans stood behind his high-backed oak chair, their hands resting on the ash shafts.

"Lied Evans," the Baron said, not rising. He took a sip of his posset, letting his gaze travel deliberately over Lied's mud-caked boots and soaked hair. "A wet night for a boy to be riding the March. Does your father know you're roaming the roads while your ditchers are drowning?"

"My father is currently reading a dispatch from the King's Warden," Lied replied.

He did not wait to be offered a chair. He stepped directly to the center of the hearth-rug, unhooking his cloak with a single, crisp motion and dropping it onto a side bench. Beneath the wet wool, his green fustian tunic was dry, his linen collar smooth, his posture unyielding as a drawn rapier.

"I have come for the weir keys, Baron August," Lied said.

The Baron gave a dry, wheezing chuckle that had no humor in it. "The weir? The weir is shut, young Evans. And it will stay shut. My tenants are grazing seventy bullocks on the Stony Flats. If I hoist the timber gates, those meadows will be two feet under mud before sunrise."

"And if you don't hoist them," Lied said, "the main river channel breaks its bank at North Dike in forty minutes."

"A pity for North Dike," the Baron said, shrugging his broad shoulders. "An act of God, as the priests say. Your father should have maintained his embankments."

"It is not an act of God," Lied said, stepping forward until the toes of his riding boots touched the stone hearth-curb. His voice was level, cool, and carried that strange, resonant clarity that commanded absolute stillness in the room. "It is an act of breach. Under the Lisle–Auden Diversion Covenant, signed under the seal of the Crown's justice, this estate is bound to receive the flood-crest whenever the water touches the four-foot notch. The marker was submerged at two bells."

The Baron set his cup down on the small table beside him with a sharp clatter. His heavy brows drew together, his small eyes narrowing in cunning triumph.

"You should read your archives more closely, young master," August sneered. "The thirty-year term expired five years ago, come Michaelmas. The parchment is dead sheep. I owe House Evans neither a bucket of water nor an acre of grass."

Lied let a slow, cold smile touch his lips.

It was a smile of complete, dismissive pity—the look an experienced merchant gives to an ignorant rustic who has misread the weight-mark on a sack of flour.

"Did you truly believe Viscount Robert would allow a treaty governing the safety of the lower March to lapse?" Lied asked softly.

The Baron froze. His hands, resting on the arms of the oak chair, tightened their grip.

"What do you mean?"

"I mean, Baron August, that you are reading from an unrevised copy," Lied said, speaking with the smooth, unhurried cadence of a lawyer laying out an open-and-shut case before the high bench. "When my father was wounded in the northern campaign five years ago, the Marcher Council held an extraordinary session at High Crag. A supplemental extension warrant was signed under the privy seal, renewing the diversion rights in perpetuity, tied to a compensatory rebate on the Cross-Keys iron-tolls."

Lied drew an envelope of folded linen from inside his tunic. It was blank, sealed only with a wafer of common red wax, but he held it between two fingers with the careless casualness of a man holding a royal writ.

"The high chancery dispatched the formal ratification rider yesterday morning," Lied continued, his grey eyes locked onto the Baron's face with unblinking force. "He was delayed by the mudslide in the high defiles, but he carries the Viscount’s signature and the confirmation of the revised toll-rebates. House Auden receives a ten-percent exemption on all smelted iron passing the river wharves for seven years."

The Baron’s breath hissed between his teeth.

Ten percent on iron was a fortune. The Auden smiths consumed four hundred tons of northern pig-iron every winter for tools and horseshoes; an exemption of ten percent would save the estate three hundred gold sovereigns over the course of the charter.

"A ten-percent rebate..." August muttered, his eyes darting to the sealed paper in Lied's hand, then to Barend's scarred, impassive face. "Your father never offered ten pence, let alone ten percent."

"My father is a soldier, not a fool," Lied said, taking another step forward, his voice hardening into an iron edge. "He knows what seven feet of flood-water costs the March. And he knows what an illegal refusal costs you, Baron August."

Lied leaned down, his face barely two feet from the older man's nose.

"If those gates remain closed when the crest hits, North Dike will break. And when the water drains, my father will not sue you in the county court. He will bring three companies of heavy horse to this gate with an indictment of territorial sabotage, impound your iron wagons at the bridge, and take the Stony Flats as indemnity under military distress. You may keep your bullocks dry tonight, my lord, but you will pay for them in ash and stone before the harvest."

The two men-at-arms behind the chair shifted their boots, their partisans wavering.

Baron August stared at the boy.

He searched Lied’s face for hesitation, for a tremor in the jaw, for a flicker of fear in the dark eyes. He found nothing. There was only that terrible, calm certainty—the posture of a young lord who held the power of life and death, backed by the immense, brutal military might of the Evans March and the cold authority of the King’s law.

The heavy silence in the hall stretched for five agonizing heartbeats, broken only by the drumming of the gale against the leaded windows and the distant, muffled roar of the rising river.

The Baron swallowed hard.

"Ten percent on the iron," August rasped, his voice cracked with tension. "Signed by the Viscount."

"Signed by the Viscount," Lied repeated without a blink. "Delivered to this table before the week is out. Or the gates stay shut, and we ride home to muster the garrison."

The Baron sat motionless for two seconds more. Then he slammed his fist against the arm of his chair.

"Giles!" he bellowed at the steward standing in the passage. "The weir keys! Take the black mare and ride to the sluice-house. Tell the watchmen to pull the iron chains to the fourth notch. Hoist the gates!"

***

When Lied and Barend rode back down to the weir, the change was already beginning.

With a deep, groaning shriek of protesting iron that could be heard over the fury of the gale, the three great oak floodgates of the Auden canal were rising into their timber gantries. A foaming wall of black water, four feet high and twenty yards broad, surged into the relief channel, roaring westward across the empty flats of scrub and gravel.

Down on the main river, the boiling crest faltered.

The yellow flood that had been lapping within two inches of the North Dike embankment dropped by half a foot, then a foot, its ravenous velocity checked as the pressure bled away into the diversion canal.

The dike held.

Along the earthen bank, the exhausted villagers and cottars collapsed onto their gravel hurdles, shouting in breathless, disbelieving joy, their wet faces turned up to the dark sky.

Lied drew rein beside the muddy shoulder where the nuns had been labouring.

The young novice, Sister Eileen, was kneeling in the clay beside an abandoned wicker hurdle. Her grey veil was ruined, plastered to her temples with yellow mud, her fingers bleeding where the rough split hazel had torn her palms. But her hands were clasped tightly against her breast, her eyes fixed upon the young nobleman sitting upon his roan gelding in the rain.

She looked at him as though the clouds had parted and a messenger from the Seven Seats had descended in armor of light.

"He heard us," Eileen whispered, her voice trembling with an ecstasy of pure, unshakeable faith that cut straight through the roar of the water. "We prayed for the dikes when the third watch broke... and the Light sent him."

She bowed her head into the mud, crossing herself with two scarred, clay-smeared fingers.

Lied looked down at her from the saddle.

He felt the sudden, immense weight gather around his shoulders—not the cold, dead resistance of the lower village, but a warm, blinding, terrifying influx of absolute credence, radiating from the girl’s kneeling figure with the force of an open furnace door.

He did not smile.

He felt the calfskin book resting against his ribs, burning against his skin through his wet linen shirt.

He had opened the gates. He had saved the rye, the barns, and the cottages of the lower March.

And now he had precisely seven days to forge his father’s seal, invent an iron-rebate charter out of whole cloth, and prevent Baron August from discovering that the salvation of the valley had been bought with a sheet of blank paper.
