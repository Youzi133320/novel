# Chapter 9: Crystals in the Tunnels

> *From the Commonplace Book of Lied Evans, Scholar of Griffin Academy:*
> 
> **[Unsettled — Written Left-Handed]**  
> *Underground Vault Ledger: the deficit of fourteen raw ether-crystals to be written off as structural bleed before the proctorial audit.*  
> 
> **[Settled — Written Right-Handed]**  
> *Confidential access to Cathedral Heresy Registers, Class Three: secured from Cleric Marcus in exchange for silence on the altar scrip.*  
> *One abandoned lime kiln, vault tier four: secured under double iron bolt and salt-ward for private stowage.*

***

Beneath the paved quadrangles of Griffin lay a second, darker city that had never seen the sun.

It was an ancient honeycomb of high-vaulted stone tunnels, carved through the wet river limestone five hundred years ago when the first kings had fortified the gorge. Over the centuries, three different masters had claimed the dark: the Academy ran its ceramic ether-conduits and lead drainage pipes through the upper vaults; the Cathedral of Saint Jude maintained its deep water-purification wells and relic cellars in the middle tier; and through the damp, unmapped bottoms, where the limestone wept cold sulfur water into the river, moved the sledges of Gruk’s orc smugglers, hauling un-taxed mountain spirits and raw peltry beneath the feet of the town watch.

It was a quiet arrangement, preserved by mutual blindness and regular bribes.

Until the crystals began to disappear.

Energy crystals were the currency of the high arts—hexagonal prisms of pale cobalt quartz mined from the deep northern granites, charged with raw ether to stabilize the laboratory furnaces and power the Cathedral’s cleansing wards. In three weeks, fourteen master-prisms had vanished from the storage lockers of the third gallery: heavy, un-cut stones worth twenty gold sovereigns each, kept behind iron grates that showed neither broken hasps nor filed hinges.

The Academy blamed the smugglers. Gruk’s orcs swore by their blood-axes that they had touched nothing heavier than spirit-kegs. And the Cathedral chapter muttered darkly of demonic intrusion and threatened to bring down the episcopal inquisitors from the capital to scour the cellars with holy fire.

Lied walked the middle tunnel at two bells past midnight, carrying an unhooded oil lantern in his left hand.

He wore his dark fustian fencing-jacket and high boots greased with tallow against the lime-damp. At his right hip hung his short practice-rapier, and under his left arm was tucked a sheepskin logistics roll he had borrowed from the Academy bursary after three hours of polite drinking with the sub-librarian.

Lied had not come to hunt thieves for the proctors.

He had come because he had spent forty minutes auditing the Cathedral’s purification receipts that afternoon, and the arithmetic had made him laugh.

He stopped outside the heavy oak door of the Cathedral’s lower tallow-store.

Through the iron grating above the lintel came the pale, yellow flicker of a tallow candle, accompanied by the dry, frantic rustle of turning parchment and the clinking of small copper counters upon a slate.

Lied pushed the door. It was unlatched, held only by an iron dog to keep the draft from blowing the candle out.

Inside, sitting on a turned-up salt-barrel beneath a low granite arch, was Cleric Marcus.

Marcus was thirty-two, thin-nosed, with the delicate, scrubbed skin of a diocesan clerk and the round tonsure of the Order of Saint Jude. His black habit was tucked up into his hempen girdle to keep the hems out of the cellar grime, and before him, spread across a pair of butter-tubs, were two ledgers.

The right-hand ledger was bound in official cathedral calfskin, stamped with the bishop's keys.

The left-hand ledger was an un-bound notebook of coarse wrapping paper, filled with small, cramped columns of numbers written in purple ink.

Beside Marcus’s elbow was a small pigskin pouch, open, showing the gleam of unclipped silver shillings and three gold angels taken from the parish tithe-basin.

"The third bell has struck, Brother Marcus," Lied said mildly, leaning his shoulder against the doorpost. "The canons are singing Matins in the high stalls. Aren't you late for your prayers?"

Marcus sprang up from the barrel with a squeak like a stepped-on terrier.

His ink-horn overturned, vomiting a black puddle across the butter-tub. His white hands fluttered frantically over the purple notebook, attempting to shove it beneath his habit, while his knee knocked the pigskin pouch to the floor, sending twenty silver coins rolling across the wet flagstones.

"Who... who goes there?" Marcus stammered, his face turning the color of skimmed milk. "This is consecrated ground! The chapter stores are closed under episcopal seal!"

"I am Lied Evans," Lied said, stepping into the cellar and shutting the door behind him with his heel. He did not touch the scattered coins; he set his lantern on the edge of the tub and looked down at the two ledgers. "First-year candidate, Dual Curriculum. And amateur auditor of the parish drainage accounts."

Marcus recognized the green-and-silver scholar’s pin. He stopped trembling, his thin lips setting into a sharp, cornered snarl.

"A student. You have no business in the deep vaults, boy. I will report you to Master Brutus before dawn. Trespass upon Church sanctuary carries three months in the stocks—"

"The right-hand ledger," Lied said, pointing a finger at the bishop’s book, "enters the annual alms-collection of the lower parish at one hundred and forty silver crowns. The left-hand notebook enters the actual counting at two hundred and twelve crowns."

Lied leaned down, his grey eyes catching the yellow candlelight.

"Seventy-two silver crowns missing in four months. A very neat leak, Brother Marcus. You enter the shortfall under the 'Uncollected Tithe' ledger, blame the winter flood for the poverty of the cottars, and write off twelve missing ether-prisms as 'smuggler theft' to balance the books with the archdeacon."

Marcus choked. He took half a step backward, his back hitting the cold granite wall.

"You... you cannot prove—"

"I don't need to prove it," Lied said politely. "I have only to take this purple notebook to the Cathedral Prior, and by sunrise you will be in an iron cage beneath the river bridge, waiting for the bishop’s tribunal to strip your tonsure with hot pincers."

The cleric slid down the stone wall until his knees touched the floor. His hands came together in a shaking, desperate knot against his breast.

"Mercy, Master Evans... by the Light, have mercy. My mother is widowed in the southern valley... my brother is in debtor’s prison at the port... I only took what the rich merchants wouldn't miss—"

"Stand up, Marcus," Lied said, his voice cold and brisk. "I am a steward, not a priest. I don't care about your soul, and I have no interest in your mother's rent. Get on your feet and pick up your silver."

Marcus scrambled up, wiping his running nose with his sleeve, gathering the fallen coins with frantic, shaking fingers.

"What do you want?" the cleric whispered, his eyes wide with terrified cunning. "Half? I can give you ten crowns tonight... fifteen next week—"

"Keep your stolen shillings," Lied said. He reached over the tub, closed the purple notebook, and tapped it against the cleric's breastbone. "I want keys. And I want ink."

"Keys?"

"The archival vault in the cathedral undercroft," Lied said. "Where the Bishop stores the confidential heresy depositions, the regional trial rolls, and the confiscated grimoires from the border districts. You have the third clerk’s key to the iron press."

Marcus stared at him as though he had grown horns. "The heresy files? Those are sealed under episcopal interdict! If anyone catches you reading the trial rolls—"

"Nobody will catch me, because you will leave the side wicket unbolted between midnight and the third watch every Thursday," Lied said. "And whenever I ask for a transcript from the high registry, you will copy it in your neat little purple hand, sign the diocesan certification, and leave it beneath the stone bench in the chapel cloister."

He stepped closer, his shadow stretching across the ceiling.

"A clean trade, Marcus. Your neck remains un-stretched, the bishop keeps his peace of mind, and I get my books. Do we understand each other?"

The cleric swallowed hard, his throat clicking like a dry lock.

"We... we understand each other," Marcus croaked. He reached into his habit, drew a heavy iron key with five notched teeth from a leather cord around his neck, and laid it in Lied’s palm. It was cold, heavier than common ore, cast from the salt-tempered church-iron used to seal the Cathedral's Reliquary of Anathemas against demonic corruption. "May the Light forgive me."

"The Light has other things to watch," Lied murmured, feeling the faint, holy vibration of the iron against his skin before slipping it into his waistcoat. "Now wash your butter-tub. And if you steal another crown from the poor-box this month, I'll have the Prior audit your firewood bills."

***

The theft of the fourteen ether-crystals, however, remained an unclosed account.

If Marcus had only stolen silver, who had taken the stones?

Lied left the tallow-store, leaving Marcus scrubbing ink from his boards, and descended into the fourth tier—the abandoned limestone galleries where the air grew warm, humid, and smelled of sulfur and dead stone.

Here, sixty feet below the foundations of the Academy, the ancient lime-burners had dug their kilns four centuries ago. Great circular shafts of fired brick, fifteen feet broad and thirty feet deep, opened into the gallery floors like black throats, long abandoned and choked with fallen rubble.

Lied walked slowly, his lantern hooded to a single slit of yellow light.

His boots made no sound upon the soft limestone dust.

He stopped beside the edge of Kiln Number Four.

A faint, high-pitched scratching sound was coming from the darkness below.

*Scritch. Scritch. Crunch.*

It sounded like an iron chisel biting into dry chalk, followed by a wet, choking cough that ended in a tiny, whistling sneeze.

Lied unhooked the lantern from his belt, leaned his stomach against the crumbling brick rim, and lowered the beam into the shaft.

The light cut through thirty feet of black air, illuminating the floor of the kiln.

Lied’s breath caught in his throat.

Sitting in a nest of chewed oak timbers, dried sheep-wool, and broken stone chips was a dragon.

It was not a great, mountain-shaking wyrm of the ancient sagas; it was an infant hatchling no larger than an overgrown boar, its body covered in soft, velvet-textured scales of dull slate-blue that had not yet hardened into steel. Its wings were short, leathery, and folded awkwardly against its flanks like wet parchment, and its neck was slender as a heron's.

The creature was violently ill.

Beside its nest lay the shattered, gnawed remnants of five hexagonal ether-prisms—the missing Academy crystals. The hatchling had crunched them like sugar-candy, and the raw, unrefined ether had fermented inside its belly, causing its cobalt scales to swell, blister, and weep tiny droplets of electric-blue sap that sizzled when they touched the dust.

The little beast was shivering, its golden, slit-pupiled eyes clouded with fever, coughing weakly as tiny puffs of pale violet smoke trickled from its nostrils.

It saw the lantern light.

It raised its head, opened its jaws—revealing two neat rows of translucent, needle-sharp teeth—and gave a miniature, pathetic hiss that ended in a wet hiccup.

Lied did not move for ten seconds.

*A dragon hatchling.*

Under imperial law, a dragon of any age found within fifty leagues of a royal city was the property of the Crown, to be executed by the King’s huntsmen or chained in the imperial menagerie as a trophy of war. If Magister Voss discovered this creature, it would be vivisected on a lead table in the Tower of Geometries within six hours to measure its mana-glands.

Lied looked at the broken crystals.

He looked at the little beast’s swollen belly, at the small, webbed paws clutching a half-eaten chunk of raw quartz, and at the fierce, frightened intelligence burning through the fog of its golden eyes.

It was not a monster. It was a stray child that had crawled into a pantry and eaten three pounds of dry salt.

"Stupid," Lied whispered softly.

He set his lantern on the rim, took a coil of hempen rope from his shoulder, and climbed down the iron rungs set into the kiln wall.

The hatchling backed away into the rubble, its back spines bristling, snapping its jaws in warning.

Lied stopped six paces away. He sat down flat upon the stone floor, crossing his legs, keeping his hands open and palms-up on his knees.

From his coat pocket he drew a clean linen napkin. Inside were two thick slices of cold roast beef from the Silver Spoon larder and a small wooden phial of bitter almond oil—an emetic he had carried since his first days auditing the rancid pork barrels at Lisle.

He laid the beef on a flat stone between them.

The hatchling’s nostrils flared. The scent of roasted fat and garlic cut straight through the fever in its brain. It crept forward an inch, its blue claws clicking against the limestone, its golden eyes flicking from the meat to Lied's face, then back to the meat.

"You have a belly full of raw quartz, little thief," Lied said in a low, rhythmic murmur, speaking with that quiet, clinical gentleness he used with frightened horses. "The ether is boiling your liver. If you don't vomit those stones, your belly will crack before sunrise."

He dipped a finger in the almond oil and smeared it across the fat of the second slice.

The hatchling hesitated, its slender neck arching, then darted forward with the speed of an adder, snapping the first piece of meat from the stone and swallowing it whole.

It reached for the second piece.

It gulped the oiled beef down in a single ravenous snap.

Three minutes later, the emetic hit its stomach.

The hatchling gave a muffled shriek, its wings flapping violently against the brick walls, its head whipping from side to side. It fell onto its flank, retching with desperate, convulsive spasms, until with a violent heave it vomited a steaming mass of half-chewed crystal shards, yellow bile, and black oil onto the stones.

It lay shivering, exhausted, its sides heaving like a bellows, its pale blue scales dull and wet with sweat.

Lied stood up. He used a flat shard of brick to scrape the vomit into a corner, burying the glowing crystal fragments under six inches of dry lime dust so the etheric scent would not rise to the higher tunnels.

He pulled a clean woollen scarf from his neck, knelt beside the little beast, and gently wrapped the soft cloth around its shivering chest.

The hatchling growled—a tiny, vibrating rumble in its throat—but it did not snap. It leaned its small, scaleless chin against Lied’s knee, its golden eyelids drooping with the overwhelming exhaustion of a fever that had finally broken.

Lied touched the smooth crest above its eyes.

The skin was warm, resilient, and felt like polished boxwood.

"Fourteen crystals," Lied whispered, his thumb lightly stroking the hollow behind the creature's ear. "A deficit of two hundred and eighty gold sovereigns on the Academy ledger. If I turn you in, Voss gets his dissection, and I get an empty pat on the shoulder from the dean."

He leaned down, looking into the half-closed golden eye.

"A dead dragon is meat for the scholars. A live dragon is a partner in the vaults."

The hatchling made a soft, clicking sound with its tongue, curling its tail around Lied’s wrist.

Lied pulled the split-calf book from his breast.

Taking his quill in his left hand, writing by the dim yellow beam of the hooded lantern, he inscribed upon the left-hand page:

*Underground Vault Ledger: the deficit of fourteen raw ether-crystals to be written off as structural bleed before the proctorial audit.*

Beneath it, he wrote:

*Tally: lodged in Kiln Number Four. To be provisioned with three pounds of clean butcher's scrap weekly, and schooled to keep its mouth shut.*

He closed the book.

He latched the brass clasp, tucked the sleeping hatchling into the corner beneath a pile of dry sheep-skins, and climbed the iron rungs toward the surface, the iron key to the Cathedral heresy files clinking softly against the coins in his pocket.

The thief was caught.

The Church was bought.

And down in the deep dark of Griffin, Lied Evans had just acquired his first loyal monster.
