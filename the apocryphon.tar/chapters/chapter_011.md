# Chapter 11: Three Clients

> *From the Commonplace Book of Lied Evans, Scholar of Griffin Academy:*
> 
> **[Unsettled — Written Left-Handed]**  
> *The Blood-Debt of Gruk: twelve thousand silver groats of seized mountain spirits, or the right hand of Lied Evans before the first snow.*  
> *Captain Jem’s supply convoy: to be redirected through Raine Ford at the third hour of dawn.*  
> 
> **[Settled — Written Right-Handed]**  
> *Griffin Bursary Commission: four gold sovereigns received from Dean Winters for preliminary auditing of the lower conduit dockets.*  
> *Cathedral Altar-Repair Fund: seven silver crowns credited under Brother Marcus’s voucher.*

***

A man who tells the whole truth to three different factions in the middle of a border crisis is a fool who will be found dead in a ditch with three different kinds of iron in his back.

Lied sat in the small, octagonal consulting room of the Dean’s Lodge, where the fire was built of sweet dry beech and the leaded windows looked out over the quiet lawns of the Inner Quadrangle.

Across the mahogany table sat Dean Winters.

Winters was sixty-five, possessed of four chins, a velvet skull-cap the color of over-ripe plums, and the watchful, hooded eyes of a churchman who had survived three royal successions without losing a single acre of Academy timber. He was peeling an orange with a small ivory penknife, his thick thumbs working the skin with slow, oily precision.

"The Council of Masters is deeply troubled, Candidate Evans," Winters said, his voice a smooth, rich purr that belonged in a cathedral choir. "The Warden of the Defiles has sent three dispatches demanding our students be mustered into the territorial militia. If royal commissioners come down to Griffin to inspect our armories, they will inevitably ask why forty etheric furnaces are burning day and night in the third basement."

The Dean severed a crescent of orange, popped it into his mouth, and chewed twice.

"The Academy requires a quiet inquest, Lied. We require an accounting of the Red Reach wagons that leaves our laboratories unvisited, our scholars at their books, and our charters un-examined by the King’s justices. You have... a certain reputation for settling awkward margins without disturbing the high registers."

He pushed four heavy gold sovereigns across the wood.

"The bursary fund for administrative assistance. What can you tell me?"

Lied did not touch the gold. He kept his hands clasped over his knees, his bottle-green tunic buttoned to the chin.

"The wagons were burned by military fire-fluid, Dean Winters," Lied said smoothly, offering the first slice of the truth. "A rogue band of low-country deserters, operating under forged Marcher passes. They used the old sewer tunnels beneath the south wall to bypass the toll-gates."

Winters paused, his ivory knife hovering over the orange. "Not the orcs?"

"The orcs are innocent of the fire, sir," Lied said, his grey eyes clear and completely steady. "If you allow the Marcher captains to inspect the tunnels, they will claim the Academy was harboring raiders. But if you seal the third sewer wicket with four baulks of fresh timber and report a 'structural cave-in' to the provincial magistrates, the Crown will look for the deserters along the turnpike, and the Academy’s basements will remain sovereign under our charter."

The Dean smiled—a slow, moist spreading of his lips that showed yellow teeth.

"An admirable engineering solution, Candidate Evans," Winters murmured, sweeping the four sovereigns toward Lied with the flat of his knife. "A cave-in. Very tidy. The masons will begin before nightfall."

***

An hour later, in the drafty vestry of the Cathedral of Saint Jude, Lied met his second client.

Brother Marcus stood behind the iron screen of the confessional, his face pale as sheep-tallow, his purple ink-stained fingers trembling against his beads. Beside him was an elderly canon in a fur-lined amice—the Archdeacon’s secretary, who looked as if he had not slept since the smoke of the burning wagons had drifted over the city.

"The Bishop is beside himself, Master Evans," the canon hissed through the iron lattice. "The common folk are gathering outside the palace gates, screaming that the orcs have desecrated the shrine at Bitter Creek! If this heresy is not answered, the town will burn the barbarian quarters before Sunday!"

"The Church requires a culprit," Lied said, his voice dropping into that cool, ecclesiastical hush that mimicked the sanctity of the stones. "A clear, identifiable evil that justifies the wrath of the faithful without dragging the Cathedral into a territorial war."

"Yes! Exactly!" Marcus stammered, nodding frantically. "A heresy we can condemn from the pulpit!"

Lied drew a folded slip of parchment from his sleeve—the second slice of the truth.

"The raiders carried blasphemous talismans of an isolated border sect," Lied said, his tone solemn, measured, and grave. "A dead splinter group of three apostates who operated in the limestone caves above the falls. I have provided the parish coroner's burial dockets for three unidentified brigands who perished of the winter gangrene in the gaol three months ago and were cast into the lime-pits. Their physical markings align with the carters' panicked descriptions."

Lied leaned closer to the iron lattice, his voice hardening into a sharp legal warning.

"Under canon law, an apostasy whose adherents are already dead and sealed in quicklime is classified as an *extinct heresy*. The Bishop can pronounce the formal excommunication from the high pulpit, declare the evil extirpated from the diocese, and close the inquest. If you name a living sect, your inquisitors will drag fifty innocent weavers from their looms, the mob will burn the market tenements, and the King's justices will arrive to investigate the rioting. Deliver the dead men, Canon. It closes the altar books, and it leaves the streets quiet."

The canon snatched the paper through the lattice, his eyes devouring the pious, airtight Latin formulas Lied had crafted.

"An extinct heresy," the canon breathed, his fingers trembling with profound relief. "The archdeacon can read the sentence before compline! The flock will see justice done, the collection basins will overflow with thanksgiving offerings, and not a single artisan will be dragged from his shop!"

Marcus slipped seven silver crowns through the screen—a tithe-bounty for the detection of apostasy.

"Go with the Light, my son," the canon whispered fervently.

Lied pocketed the silver. "May the Light keep its eyes shut," he murmured under his breath, and stepped out into the rain.

***

The third client was waiting in the damp cellar beneath the cooperage at the river wharf.

Gruk did not offer orange slices or Latin benedictions. He sat on an empty spirit-cask, sharpening a six-foot two-handed cleaver with a slab of coarse gray slate, the rhythmic *shhk-shhk-shhk* of the steel filling the dark room with the scent of hot iron and whale-oil.

"The chieftains have crossed the ridge," the orc rumbled, not raising his head. "Four hundred lances are sitting in the scrub above Raine Ford. If I do not send word by tomorrow dawn, the torches go into the valley farms."

"The wagons were burned by Captain Jem," Lied said, delivering the third and most dangerous slice of the truth. "Of the Frontier Security Guard. He is carrying a Celestial Heart Demon beneath his ribs, and he answers to Duke Victor Greven."

The stone stopped moving against the blade.

Gruk looked up, his tusks bared in a snarl of cold, savage hatred. "A demon? A human duke?"

"Greven wants a war," Lied said, stepping to the lantern-light. "He wants thirty thousand soldiers under his personal command, and he wants the northern iron-mines. If your chieftains charge across the river tomorrow, you give him exactly what he needs to wipe the clans from the border."

"Then we take Jem's head tonight," Gruk growled, rising to his feet, his massive shoulders blotting out the wall. "I will take twenty boys, break the gates of his stockade, and drag his liver into the street."

"And the Duke will declare you proved his case," Lied snapped, his voice ringing with sudden, whip-like authority that made the huge orc pause. "An armed assault on a royal security station? Greven would have his legions mobilized before the blood was dry on your knife. You will wait, Gruk. You will hold your lances at the river until I give the word."

"Wait for what?" Gruk spat. "Until your priests burn more tents?"

"Until I put Jem in the middle of Raine Ford with his demon showing," Lied said, his eyes burning with cold grey fire. "In front of the Marcher lords, the Academy masters, and the King’s inspectors. When the demon is seen, Greven’s plot is broken, and your people are cleared of the fire."

The orc stared at him for five long seconds, his heavy chest heaving.

"Three days, student," Gruk rasped, thrusting his cleaver into its greasy leather scabbard. "Three days. If the sun comes up on the fourth day and Jem is still breathing, my boys take the road."

***

Lied walked back toward the Great Quadrangle through the misty cloisters of the Upper Library.

It was nearly midnight. The stone arches were empty, the torch-smoke clinging to the damp vaulted ceiling, when a shadow detached itself from the recess of the third buttress.

It made no sound. No scrape of boot on stone, no rustle of wool.

Before Lied could turn his head, a cold, slender strip of polished steel was pressed flat against the skin of his throat, right above the left carotid artery, where the pulse beat against the razor-edge.

"Stand still, Candidate Evans," a voice whispered.

It was a woman’s voice—cool, quiet, and possessing the dead, emotionless rhythm of a surgeon examining an incision.

Lied did not move. He kept his chin elevated by half an inch, his eyes flicking sideways.

She was eighteen or nineteen, slender, wearing the black silk arming-doublet of the newly established Assassin faculty—the secretive curriculum transferred from the eastern marquisates that autumn. Her dark hair was cropped close to her skull like a boy’s, her skin pale as lard, her eyes the flat, unreflective black of polished obsidian.

Isolde Gregory.

"Mistress Gregory," Lied said, his voice conversational, though the cold steel was chilling his sweat. "If you are looking for the lecture on poison-extraction, it was moved to the North Tower."

"I am not looking for lectures, Lied," she said, her breath smelling faintly of peppermint. Her left hand reached around his shoulder with terrifying, practiced speed, dipping into his breast pocket and pulling out the leather portfolio that contained his duplicate carriage sheets.

She held the papers in the moonlight with one hand, the dagger never wavering an eighth of an inch from his jugular.

"I have been auditing the transport dockets for Master Brutus," Isolde murmured, her eyes flicking across the numbers with impossible speed. "You told Dean Winters that the raiders used the sewer tunnels to enter the city. But the sluice-gate logs for Thursday night show the water was three feet above the arch—a dog couldn't have swum through without drowning."

She turned a page.

"And you told Brother Marcus that the apostates came from the upper gorge. But the carriage rolls for the salt-wharves show three wagons of un-taxed mountain spirits were cleared through the river barrier two hours after the fire, signed under your private steward's stamp."

She tilted the blade slightly, the cold iron biting into his skin until a tiny, warm bead of blood welled against the steel.

"You are juggling three different lies, Master Evans," Isolde whispered, a faint, razor-thin smile touching her pale lips. "And one of them belongs to Duke Greven’s men. Who are you selling the Academy to?"

Lied’s mind worked with the speed of an uncoiling spring.

She was an Assassin-path scholar. She was trained to spot discrepancies, eliminate political liabilities, and strike without emotion. If he tried to explain the Celestial Heart Demon, she would assume he was mad or playing for time, and her knife would slit his throat before he finished the sentence.

If he defended his integrity, she would hand the portfolio to the proctors, and the entire fragile web would unravel.

He had to give her a bone.

A bone with enough meat on it to satisfy her hunter’s instinct, but small enough to keep her away from Raine Ford.

*A contained failure.*

The words rose in his mind, cold, ruthless, and necessary.

"I am not selling the Academy to Duke Greven," Lied said, speaking through his teeth without moving his throat. "I am selling spirit-licenses to Gruk."

Isolde paused, her dark eyes narrowing.

"What?"

"Look at the third entry on the bottom docket," Lied whispered, his breathing steady. "The wine-cellar beneath the old cooperage on the river wharf. Gruk has sixty kegs of un-taxed brandy sitting behind the false wall tonight, waiting for the southern carters. I took twelve crowns to sign the gate-clearance. The 'raiders' were an excuse to keep the watch away from the basin."

He swallowed, letting his voice carry just enough shame, just enough petty aristocratic greed to make the story completely, disgustingly believable.

"I am a second son with no land, Mistress Gregory. I need seventy sovereigns to pay my tuition. Take the cellar. Expose the spirits. You will have your credit with Master Brutus, the Academy will seize sixty kegs of brandy, and you can tell the Dean you caught a student taking bribes from an orc."

Isolde stared at him for four long seconds.

Her blade did not move, but her black eyes flicked between his face and the parchment in her hand.

She saw a clever, cowardly younger son who had tried to play at being a smuggler to pay his tailor's bills, caught in the dark by a superior operative.

It was small. It was sordid. It was entirely human.

She drew the knife away from his throat with a clean, fluid motion, sliding the blade into the sheath hidden beneath her forearm.

"You are a very small thief, Lied Evans," Isolde said, her voice dripping with pure, aristocratic contempt.

"I am a student," Lied replied, dabbing the bead of blood from his collar with his sleeve. "Small thieves live longer than great ones."

"Not tonight," she said coldly. She snatched the docket containing the cooperage address. "Stay in your rooms, Evans. If I see you near the river basin before morning, I'll take your ears."

She turned and vanished into the darkness of the cloister as silently as a wisp of smoke.

***

Two hours later, the bells of the Town Watch began to ring from the river wharves.

Lied stood on the high stone terrace of the library, looking down through the freezing mist toward the lower canal.

Red torches flickered around the old cooperage. Shouts, the barking of watch-hounds, and the splintering crash of oak doors echoed over the dark water. Moments later, three heavy wagons rolled out of the alley, loaded with seized casks of mountain spirits, surrounded by thirty armed constables with billhooks and lanterns.

Beside the water-gate, standing in the shadows of an archway, was Gruk.

The orc was surrounded by four of his largest runners. He was not shouting; he was watching the confiscated wagons with a face like carved granite.

Then Gruk turned his head.

Across two hundred yards of cold, misty night, his bloodshot eyes looked straight up to the high terrace where Lied stood.

The orc raised his right hand.

He did not make a fist. He drew the edge of his broad hunting-knife slowly across the palm of his hand, letting the dark, thick blood smear across his knuckles in the moonlight.

Then he pointed the bloody blade directly at Lied’s breast.

*The blood-debt.*

Lied did not flinch. He stood motionless at the stone balustrade, his hands gripping the cold granite until his knuckles were white.

He had saved the larger game. Isolde had taken the bait; she had seized the spirits, satisfied her suspicions, and cleared him of political conspiracy. She was already writing her report on the 'smuggler cellar' for the proctors, leaving the turnpike investigation wide open.

But the price was paid.

Gruk had lost three years of underground labor, sixty kegs of prime spirit, and his faith in the Evans boy.

Lied unlatched the split-calf book from his breast.

Under the cold light of the moon, writing with his left hand, his steel nib made a harsh, tearing scratch across the parchment:

*The Blood-Debt of Gruk: twelve thousand silver groats of seized mountain spirits, or the right hand of Lied Evans before the first snow.*

He looked at the words.

They sat upon the left page, raw, bloody, and open.

"Raine Ford," Lied whispered into the freezing wind, his teeth set like an iron trap. "It all comes due at Raine Ford."
