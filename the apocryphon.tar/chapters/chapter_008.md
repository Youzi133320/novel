# Chapter 8: Griffin

> *From the Commonplace Book of Lied Evans, Scholar of Griffin Academy:*
> 
> **[Unsettled — Written Left-Handed]**  
> *Silver Spoon Society: to secure standing among the Inner Bench before the winter solstice without pledging territorial collateral.*  
> 
> **[Settled — Written Right-Handed]**  
> *Gate of Blades: passed on third tally, sixty-two points (Master Brutus presiding).*  
> *Gate of Geometries: passed on aggregate calculus, fifty-eight points (Magister Voss presiding).*  
> *Matriculation fee and term-lodge deposit: twenty-four gold sovereigns, receipted under the Rector’s seal.*

***

The city of Griffin was built around a limestone gorge three hundred miles south of the Evans March, where the river was wide enough for sea-going ketches and the air smelled of burning canal-coal, dried parchment, and fried river-fish.

Above the tile roofs rose the Academy: seven walled quadrangles of soot-darkened granite, connected by high, covered galleries of open stone-tracery that bridged the limestone gaps like flying buttresses. Through the tall, narrow lancets of the upper tier, one could see the blue, electric glow of the etheric laboratories pulsing through the mist, while from the sunken yards below rose the dull, rhythmic *clack-clack-clack* of two hundred ash practice-swords striking the leather pell.

Lied stood in the Great Quadrangle, holding his enrollment scroll in his right hand.

He had turned eighteen two days before his coach crossed the river bridge. He wore a scholar’s gown of dark gray broadcloth, cut narrow at the shoulders to clear his sword-hilt, with the two silver pins of an unmatriculated commoner fastened at the lapel.

Behind the long oak barrier in the lower cloister, the Registrars of the Faculties sat beneath the royal crest.

"Name?" barked the under-clerk, dipping a long iron reed into an ink-vat the size of a soup-kettle.

"Lied Evans," Lied said, laying his papers on the board. "Second son of Viscount Robert of the Northern Defiles."

The clerk flicked through the Marcher certificates without looking up. "The faculty of Civil Administration and Diocesan Law takes fifteen sovereigns at entry. The lectures begin on Monday. Take your token to the east gate."

"I am not entering Civil Administration," Lied said.

The clerk paused, the ink dripping from his reed onto the blotting paper. He raised his eyes, squinting through round horn-rimmed spectacles at the slender, dark-haired boy standing before the barrier.

"The church history faculty is full," the clerk muttered. "The Bishop’s sons filled the benches a week ago."

"I am registering for the Dual Curriculum," Lied said, his voice clear, even, and perfectly polite. "The Hall of Blades and the Tower of Geometries. As a candidate for the Mage-Knight qualification."

The Great Quadrangle did not go silent; there were three hundred young men shouting, haggling over horse-hire, and unloading iron-bound chests in the court.

But around the registrar’s table, five people stopped moving.

A portly gentleman in the scarlet mantle of a senior proctor turned his head. Two young nobles in velvet cloaks lined with ermine, who had been laughing over a pair of fighting-cocks in a wicker hamper, turned to stare.

The clerk set his pen down with a dry, clattering sound.

"The Dual Curriculum," the clerk repeated, as though testing whether the Latin syllables carried a foul taste. "Young man, the Dual Path has not admitted a common provincial since the reign of King Alden. You require sixty points on the combat pell and fifty-five points on the higher calculus of ether-matrices. If you fail either examination, your entire entrance fee of twenty-four gold sovereigns is forfeit to the Academy chest, and you are barred from the civil faculties for three academic years."

"I am aware of the ordinance," Lied said. He reached into his coat with his left hand, drew out a pigskin pouch, and poured four rolls of heavy gold coin upon the oak barrier.

They rang true—twenty-four heavy, yellow sovereigns, struck at the royal mint, bearing the unclipped crown of the realm.

"Enter the name, Master Registrar," Lied said softly. "The gold is full weight."

The clerk stared at the gold. He looked at Lied’s quiet, steady grey eyes, shook his bald head with the sour disgust of an old bureaucrat watching a fool throw inheritance into a mill-race, and struck the iron stamp into the black ink.

"Candidate Evans," the clerk rasped, slamming the seal onto the register. "Pell trials at the third bell. Geometries at sunset. May your tutors enjoy your father's silver."

***

The trial at the Gate of Blades was not a duel; it was an execution conducted with blunt oak.

Master Brutus, the Academy’s Chief Arms-Instructor, was six feet four inches of grizzled frontier veteran, his nose flattened like a pig’s snout, his bare forearms crossed with white, ropy scars from thirty campaigns in the eastern marches. He sat on an iron-banded bench beside the sand-ring, a five-foot ash stave balanced across his knees, watching forty aristocratic candidates hack at the straw pells with polished tourney-blades.

When Lied stepped into the sand, the heavy iron breastplate he had rented from the armorer pinched his collarbone, the greaves clanking against his shins.

"Evans," Brutus grunted, glancing at the slip of sheepskin in his fist. "The boy from the Lisle holding. Your brother Rodney could split a horse from withers to hock with a single downward sweep before he was nineteen. Can you?"

"No, sir," Lied said, resting his two-handed practice blade point-down in the grit. "My brother Rodney weighs eighteen stone and eats two capons for breakfast. I weigh eleven stone and prefer my meat boiled."

A muffled snicker broke out among the young nobles lounging along the timber rail.

Brutus did not laugh. His pig-eyes narrowed, cold and dangerous.

"Step into the square," the master commanded. "Three exchanges with Sergeant Garrow. Touch his leather twice, or take three clean blows to your iron without dropping your guard. If your knees touch the sand, you're out."

Sergeant Garrow was a broad-shouldered Marcher sergeant whose mustache was dyed with tobacco juice. He held a six-foot oak greatsword weighted with lead in the pommel, and he moved with the terrifying, effortless economy of a professional slaughterer.

*First exchange.*

Garrow did not feint. He stepped forward with a brutal, descending diagonal stroke that would have broken a bullock's neck.

Lied did not try to parry.

He had spent two sovereigns the previous night hiring an impoverished fourth-year bladesman to dissect Garrow’s habits over four flagons of ale at the Red Boar. Garrow had a stiff left knee from an old winter siege, and when he launched a heavy downward cut, his right foot advanced six inches further than his hip, leaving his center of gravity committed to the sand for a third of a second.

Lied pivoted on his left heel, ducking beneath the whistling oak. The heavy wooden blade struck the sand with a wet, thudding *whump*, spraying grit over Lied’s greaves. As the sergeant recovered, Lied’s iron-shod hilt snapped upward, tapping the leather gorget at the sergeant’s throat with a dry, sharp *clack*.

"Point," Brutus grunted from his bench.

*Second exchange.*

Garrow was no longer bored. His eyes turned yellow with professional malice.

He came in low, sweeping the greatsword in a vicious horizontal arc aimed to take Lied’s legs from under him. Lied sprang backward, but the oak grazed his shin-guard with enough force to spin him half-round. Garrow’s back-hand pommel caught Lied squarely in the middle of his rented breastplate.

The iron plate bent inward with a sickening groan.

The breath left Lied’s lungs in a violent, ragged gasp. His vision swam with black spots; the pain in his cracked ribs—the old ache from the Glass Hollow—screamed like an open wound. He staggered three paces, his heels dragging in the sand, his knees bending until they were two inches from the grit.

*If your knees touch the sand, you're out.*

Lied did not look at Garrow. He looked through the red fog of his pain at the wooden rail, where sixty young men were watching him fail.

He felt the calfskin book against his ribs, under the bent iron.

*I wrote it.*

The thought was not a prayer; it was an iron lever pried beneath a falling stone.

He drove his teeth into his lower lip until the blood welled sweet and salty against his gums. His right leg locked straight. With a dry, rattling gasp that sounded like a saw hitting an iron nail, he dragged his weight upright, his blade coming up into a trembling, two-handed high guard.

Garrow stepped in for the kill, his stave cocked for a downward hammer-strike.

Lied did not parry. He threw his whole body forward into the sergeant’s chest, catching the wooden stave between his crossed iron gauntlets, fouling the swing before it could gather speed. With his left forehead, he struck Garrow’s leather visor a savage, clattering crack.

Both men crashed into the sand in a tangle of limbs and clattering armor.

Brutus stood up from his bench, his ash stave rapping twice against the oak post with the force of a mallet.

"Halt!" the master roared.

The sergeant scrambled up, swearing under his breath, spitting sand.

Lied rose more slowly. His breastplate was dented, his lip was split, and blood was dripping from his collarbone down into his linen shirt, but his feet were planted six inches apart in the grit, his point wavering toward Garrow’s throat.

Brutus walked into the square. He looked at the dent in the breastplate, then at Lied’s unblinking, furious eyes.

"Sixty-two points," Brutus said, his voice flat as ditch-water. "Ugly. Clumsy. Fought like a tavern-brawler with two knives in a cellar."

The master tapped Lied’s shoulder with the blunt end of his stave.

"A pass, Evans. A beginning."

***

At sunset, in the high, silent vaulted hall of the Tower of Geometries, they gave him a slate of black marble and an iron stylus.

The examination was administered by Magister Voss, a tall, gaunt scholar whose hair was as white as sheep-curd, wearing the midnight-blue silk of the High Archon's circle. Around the circular chamber sat thirty candidates, their faces pale under the green glow of the ether-spheres suspended from the ceiling, their styluses scratching in desperate, furious silence.

The problem was an etheric flow-matrix: calculating the pressure-gradient of an expanding celestial combustion within a three-fold runic circle, bounded by seven shifting geometric nodes.

Lied stared at the marble slate.

His ribs throbbed with a dull, sickening rhythm; his right wrist was swollen from Garrow’s pommel-strike.

He knew the foundational equations; his chaplain at High Crag had drilled the basic ratios into him, and he had read the surveyor’s grammar until the pages were thin. But the seventh node was an irregular equation—an unstable ratio that refused to resolve into a clean Latin derivative.

He held the stylus in his right hand.

The number would not come.

His mind was running against a blank stone wall. If he failed the geometries, the twenty-four sovereigns were gone, his father's allowance was terminated, and he would be on the road back to the March before the morning bells.

Lied closed his eyes.

He took a slow, deep breath, letting the smell of cold limestone and burning ether-oil fill his head.

He shifted the iron stylus from his right hand to his left.

The moment the iron touched his left fingers, the strange, crystalline clarity descended upon him—that terrifying, hyper-rational focus he had felt when Barend had laid the Griffin letter upon his desk in the winter.

He looked at the slate.

He did not calculate the seventh node; he *looked* at it. He saw the gap between what the equation claimed to be and what the ether actually did when it struck a cold surface. An etheric matrix was not a mystery; it was an account-book. It was an inventory of energy entering a stone, and if the energy did not balance on the right, it was because someone had stolen three bags of oats on the left.

His stylus moved across the black marble in a swift, fluid, backward-slanted scrawl.

He struck out the third harmonic. He inserted a secondary derivative based on the rate of heat-bleed through limestone—an empirical deduction drawn from his hours watching the iron coulters peened at the forge.

He laid the stylus on the slate.

Magister Voss drifted down the aisle, his silk robes whispering against the flagstones like dead grass. He stopped beside Lied’s bench, picked up the slate, and peered at the scratched white lines through a lens of green crystal set into an iron ring.

The scholar’s pale brows drew together until they met over his hawk-nose.

"This is not the imperial method," Voss murmured, his voice reeking of cloves and old books. "You have balanced an etheric expansion using the accounting principles of a provincial toll-collector."

"Does it balance, Magister?" Lied asked quietly.

Voss stared at the slate for twelve agonizing seconds.

"Fifty-eight points," the scholar whispered, his lip curling with cold academic distaste. "By the grace of the Light and an unholy fluke of vulgar arithmetic. A pass, Candidate Evans."

The old man dropped the slate onto the table with a clatter.

"May you never build an arch I have to walk under."

***

The tap-room of the Silver Spoon Society smelled of sweet southern pipe-weed, spiced vintage wine, and the fine cured goatskin of thirty easy-chairs.

It was an exclusive, unchartered club occupying the first floor of an ancient timber mansion overlooking the college water-gate. Membership was not granted by the Academy; it was granted by four black balls dropped into an ebony urn by the sons of counts, judges, and high merchants who believed that four years at Griffin were meant for making ministries, not reading books.

Lied sat in a corner chair of dark ox-hide, wearing a new tunic of deep bottle-green, his bruised collarbone concealed beneath a collar of fine river-port cambric. Beside him sat Edwin Colin, an amiable, plump young viscount from the western valley whose father owed Viscount Robert three hundred sheep from an old border arbitration.

Across the low mahogany table, lounging back with one silk-stockinged leg thrown over the carved arm of his chair, was Felix Ashworth.

Ashworth was twenty, with hair the color of polished brass, eyes like pale glass, and an ancestral manor eighty miles from the capital that produced forty thousand bushels of wheat every harvest. He wore a doublet of purple velvet embroidered with gold bees, and in his white hand he turned an enameled silver snuff-box with the idle, condescending grace of a man who had never seen an iron coin in his life.

"Evans," Ashworth said, his voice a smooth, languid drawl that carried over the murmur of the card-tables. "The name is known, of course. Robert Evans holds the northern gate. But I was speaking with my uncle’s secretary from the War Office last night. He told me the Evans March was three years behind on its cavalry subsidies, and that the second son was sent south on an under-clerk’s scrip."

Two young gentlemen at the next table paused, their wine-cups halfway to their lips, their eyes turning toward the corner.

It was an execution by polite inquiry.

If Lied grew angry, he was a provincial barbarian; if he defended his father’s poverty, he was an insolvent dependent who would be black-balled from the society before the evening cards were dealt.

Lied took a sip of his wine. It was rich, sweet, and cost fourpence the glass—an extravagance he had paid for out of Rodney’s gold.

He did not look defensive; he looked amused.

"Your uncle’s secretary is an industrious man, Ashworth," Lied said, leaning back into the ox-hide with that cool, lazy posture he had observed in high judges at the assizes. "He counts the horses that appear on the muster-rolls. He does not count the horse-contracts held under private territorial lien at Cross-Keys."

Lied tapped his thumbnail against the mahogany table.

"My father does not draw royal subsidies for cavalry because an estate that accepts a royal horse-grant is bound to yield forty chargers to the Crown whenever the King takes a whim to hunt in the southern marshes. We prefer to maintain our own studs under private copyhold. It costs forty sovereigns a year more in oats, but when the Duke of Greven’s factors came looking for remounts last spring, they found the stable doors locked under territorial privilege."

Lied turned slightly toward Edwin Colin.

"You remember the grey stallions my brother Rodney took from the northern ridges last Martinmas, Edwin? The ones your father’s factor was inquiring after?"

Edwin Colin blinked, his round, pink face brightening with instant, eager corroboration. He knew nothing of stable liens, but he remembered his father cursing Viscount Robert over a boundary arbitrament involving seventy horses three winters ago.

"Oh, by God, yes!" Edwin declared loudly, slapping the table. "Magnificent beasts! Broad in the chest, seventeen hands high! My father offered eighty silver crowns for the pair, and Robert Evans wouldn't even let him look in the paddock. The March keeps its own stables, Felix. Everyone knows that."

Felix Ashworth’s pale eyes narrowed.

He looked at Lied’s bottle-green tunic. He looked at the clean, white cambric collar, at the unhurried grace with which the young provincial turned his wine-cup, and at Edwin Colin’s unhesitating, enthusiastic testimony.

In the currency of the Silver Spoon, a man who possessed no gold was a beggar; but a man who appeared to possess so much quiet, entrenched territorial influence that he could insult the War Office and hoard royal cavalry was an asset worth cultivating.

Ashworth closed his snuff-box with a soft, metallic *snap*.

"A sensible policy," Ashworth murmured, his lips curving into an accommodating, polite smile. "The War Office is run by clerks from the wool-staple. One must keep one's breed out of their hands."

He raised his wine-glass toward Lied.

"A glass with you, Evans. We must have you at the card-table on Thursday."

Lied raised his glass, returning the nod with just enough aristocratic indifference to keep the young lord wondering.

*Seeming not to need money,* Lied thought, feeling the cold weight of the lesson settle into his bones, *is worth ten times the coin in your pocket.*

He excused himself ten minutes later, stepping out of the warm, perfumed atmosphere of the club into the cool, windy twilight of the water-gate cloister.

***

The carrier’s post-wagon from the northern road was unloading in the gravel yard of the lower hostel.

It was a monstrous, six-wheeled dray caked in dried gray mire from the mountain passes, its six draft-horses steaming in the evening chill while the carter flung bundles of salt-cod, linen bales, and wooden trunks onto the stones.

Lied was crossing the court toward the library when he saw her.

Lina stood by the wagon wheel.

She was fifteen, small, thin as a willow wand, wearing a traveling mantle of coarse, home-dyed gray wool that had faded to yellow at the hem. Her boots were caked in dried marsh-clay, and her small, pale face was smudged with soot from the road-stoves, her brown hair pulled back into an untidy knot with a wooden skewer.

At her feet sat two small boxes of unpainted pine, tied with rough hemp rope.

In her right hand, clutched so tightly that her small knuckles showed white through the grime, was the Marcher bursary voucher bearing the red seal of the Lisle stewardship.

She was staring across the courtyard.

She was looking directly at Lied.

She took in his bottle-green broadcloth tunic, the fine white cambric of his collar, the silver pins of the Dual Curriculum gleaming on his chest, and the enameled silver token of the Silver Spoon Society pinned casually into his belt.

She did not curtsy. She did not drop her head.

She walked straight across the gravel, her heavy peasant boots crunching in the stones, her chin held so high that the cords of her thin neck stood out like wires.

She stopped two paces from him.

With a swift, savage motion of her arm, she slammed a heavy slate notebook—the crude, wood-framed slate covered in chalked columns of arithmetic—squarely against Lied’s chest.

"You," Lina hissed.

Her voice was low, trembling with a fury so fierce and concentrated that the breath caught in Lied’s throat.

"My brother Barend thinks you are an angel of the Seven Seats," the girl whispered, her dark eyes blazing with tears of pure, unadulterated humiliation. "He thinks you spoke a holy word and the high castle rained gold from the sky. He spent three days telling the village priest that the Evans family had taken our blood under their mantle."

She stepped closer, her finger pointing like a bodkin at the silver pins on his breast.

"I found the duplicate in your father's chancery rolls before I left the valley. I made the under-clerk show me the book. There was no education warrant, Master Lied. There was no bursary from the March. You stole a defense credit from an old dead debt, and you pledged my brother’s four years of garrison blood to buy my seat."

Lied did not back away. He caught the slate against his ribs, his grey eyes meeting hers in the twilight.

"The debt was paid, Lina," Lied said quietly. "The gold was real. You are matriculated under the rector’s seal."

"I am not your charity!" Lina choked, her voice breaking into a harsh, ragged whisper that was loud enough to turn the heads of two passing scholars. "I am not a hound you buy with scraps from your high table so my brother will die in a ditch for your father's fences! I will pay you every copper groat. Every sovereign, every crown, every farthing of interest, if I have to copy Latin rolls until my fingers rot off my hands!"

She snatched the slate back from his chest, her knuckles scraping against his wool tunic.

"Do not look at me in the lecture halls," she said, her voice dropping into a register of icy, absolute finality. "Do not speak to me in the cloister. I am here because I solved the surveyor's proofs, not because an Evans boy wanted to play at being a god with his father's ledger."

She turned on her heel, her heavy skirts whipping around her muddy shins, and marched toward the commoners' dormitory, hauling her two wooden boxes across the gravel with her own bare, bleeding hands.

Lied stood alone in the darkening quadrangle.

The wind from the river was cold, carrying the sharp, bitter tang of burning coal and wet limestone.

He felt the calfskin book resting against his ribs, under the bottle-green wool.

He did not feel angry. He did not feel insulted.

A strange, quiet thrill of profound admiration ran through him, starting at the scar on his collarbone and spreading into the tips of his fingers.

*She wasn't broken.*

She had looked through his lie, she had audited his fraud, and she had thrown it in his face with the cold, unyielding pride of an equal.

Lied pulled his cloak around his shoulders.

The Gate of Blades was passed. The Gate of Geometries was open.

And in the long, dark corridors of Griffin Academy, the board was set, the pieces were in motion, and the game had finally begun.
