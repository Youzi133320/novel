# Chapter 7: The Family Dinner

> *From the Commonplace Book of Lied Evans, Steward of the Lisle Holding:*
> 
> **[Unsettled — Written Left-Handed]**  
> *Griffin Academy matriculation: to secure standing in both the Hall of Blades and the Tower of Geometries before the winter term commences.*  
> 
> **[Settled — Written Right-Handed]**  
> *Lisle annual audit, provisional clearance under the High Chancery: zero emergency grain drawn from the central granaries.*  
> *From Rodney Evans, Lieutenant-General of the Defiles: twenty gold sovereigns, private gift without receipt.*

***

The high hall of High Crag did not smell of flowers or perfumes; it smelled of dried blood, mutton tallow, and wet dog.

Four great iron fire-baskets hung from the granite vaulting on blackened chains, dropping sparks onto a floor of rough flagstones where two heavy deerhounds gnawed the ribs of an ox. On the walls, the banners of House Evans—three silver falcons stooping against a field of forest green—were grimy with forty winters of peat soot, their silk fringes frayed by the mountain draft that whistled constantly through the unglazed arrow-slits.

Viscount Robert Evans sat at the head of the high trestle table, cutting a collop of cold salt-venison with his dagger.

He was fifty-six, with shoulders like an ox-beam and hair cropped close as iron wire, silvered over the ears. His jaw was scarred where an orc spear-point had glanced off his cheek twenty years ago, pulling the right corner of his mouth down into an expression of habitual, cold skepticism. He wore no jewels except the heavy iron ring of the Marcher Warden on his right thumb, and his woollen tunic was the same rough fustian worn by his company captains.

Between him and Lied sat Rodney, already half through his third horn of dark Marcher ale, a platter of fried trenchers and fat bacon grease stacked before his elbows.

"The Auden weir," Viscount Robert said.

He did not look up from his meat. The point of his hunting knife made a dry, rhythmic click against the trench-board as he carved a sliver of fat.

"The weir held," Lied replied. He sat upright on the backless bench, his hands resting in his lap, his plate untouched. "The high water was diverted across the Stony Flats at two bells before dawn. We lost six hurdles of gravel at North Dike, but the seed-corn stayed dry in the barns."

"I know it stayed dry," the Viscount said. His voice was deep, slow, and possessed of the cold weight of a portcullis dropping into stone grooves. "The under-clerk brought the harvest estimates yesterday. Two thousand bushels of clean rye from the lower valley, and not a single bushel drawn from the central granary for relief."

The knife clicked again.

"He also brought a supplemental drainage covenant, signed with Rodney’s signet and sealed with the Auden ravens."

Rodney paused, his drinking-horn halfway to his mouth. He wiped a streak of yellow ale-foam from his mustache with his sleeve, frowning across the table. "The timber-clearance vouchers? I stamped them in the armory. The smith wouldn't touch the axes without the Falcon."

"The smith got his axes," the Viscount said, his pale, grey eyes lifting slowly to fix upon Lied’s face. "And Baron August got a ten-percent rebate on four hundred tons of northern smelt-iron."

The room was quiet for three seconds, save for the cracking of the ox-bones between the hounds' jaws.

Rodney looked from his father to his younger brother, his broad forehead furrowing as he began to smell a trap. "Lied? What iron rebate?"

Lied met his father’s gaze without a blink. His hands remained loose, unhurried, resting upon the coarse wool of his trousers.

"The covenant signed by my grandfather expired five years ago, my lord," Lied said evenly. "Baron August had two crossbowmen in the sluice-house and a padlock on the chains. If the weir remained closed for another three-quarters of an hour, North Dike would have broken, forty cottages would have been swept into the river, and the March would have lost forty tenants, sixty cattle, and two hundred pounds of silver in winter taxes."

"And so you traded thirty-six gold sovereigns a year of my iron-tolls to save two hundred pounds of peasant bacon," the Viscount said.

"I traded a future rebate on iron that has not yet been dug from the hills," Lied corrected, "to preserve four hundred acres of rye that are currently standing in the fields. And I secured Elder Jethro’s clan signature on a perpetual covenant that binds the Auden heirs to hoist the gates at three-foot-eight forever. Under the old treaty, they did not hoist until four feet. We bought four inches of safety on the Lisle embankment in perpetuity, for the price of three dozen crowns a year that Baron August will likely spend buying grain from our own markets."

The Viscount chewed his meat with slow, agonizing deliberation.

He did not roar; he did not pound his fist on the oak. A Marcher lord who survived thirty years on the frontier did not lose his temper over a clever trade.

"A lawyer's answer," Robert said softly. "Smooth, neat, and smells of ink."

He pointed the grease-stained tip of his dagger at Lied’s chest.

"You took your brother's signet without his reading. You used an old man’s hatred of his nephew to buy a clan stamp. And you committed the March to a deficit that will appear on my treasury ledger two years from now."

"A deficit that the Lisle stewardship will service from its own timber profits and court compositions," Lied said, "without asking High Crag for a single copper groat."

The Viscount paused. A flicker of something dry, dangerous, and very nearly approving passed through the cold grey eyes, vanishing before it could become a smile.

"It had better," Robert said. "Because if the treasury clerk finds thirty-six sovereigns short at Michaelmas, I will take it out of your back with a bridle-rein."

He laid the knife down. He reached into the leather pouch at his hip, drew out a small wooden tally-stick notched with three deep cuts, and tossed it across the table. It slid over the grease-spotted wood and stopped against Lied’s empty plate.

"Griffin Academy," the Viscount said.

Lied looked at the stick. The three notches signified fifty gold sovereigns per annum, drawn quarterly against the merchant bank at the capital.

"Fifty sovereigns," the Viscount continued, picking up his horn of water. "It will buy your lodgings, your books, your lecture fees, and three decent tunics of gray cloth. You will live like the second son of a frontier marcher, not like a duke’s bastard. If you need wine, you will drink small beer. If you need horses, you will walk."

Lied picked up the tally-stick. The wood was seasoned oak, hard and smooth. "I thank you, my lord."

"Do not thank me yet," Robert said, his voice dropping into that flat, unyielding tone that brooked no appeal. "You leave for the south on Thursday. Your cousin Martin will take the Lisle stewardship before the harvest."

Lied’s fingers tightened on the oak stick.

The Lisle holding was his. He had cleared its ditches; he had audited its flour; he had faced down its flood; he had walked its muddy lanes until every tenant knew his voice. To hand it to Martin—a dull, pompous cousin who spent his days hunting otters with terriers—was to watch six months of ruthless administrative precision unraveled by an idiot.

"Martin does not know the copyhold boundaries," Lied said, keeping the fury entirely out of his voice.

"Martin is an Evans," the Viscount said coldly. "And he is here. You will be three hundred miles away in a schoolroom. Remember this, Lied: the stewardship was a loan, not an inheritance. You were allowed to govern to see if you had a head for paper, and you have proven that you can lie fast enough to keep your neck out of a noose. But on the March, men hold land by steel, not by paper. You have no land of your own, boy. And if you fail your examinations at Griffin, you will return to High Crag as an under-clerk in the salt-cellars."

The Viscount stood up. His heavy boots thudded against the flagstones as he turned, whistling for his deerhounds, and walked out of the hall toward his private apartments without looking back.

***

The tapers were burning down to the iron rings when Rodney came into Lied’s guest chamber.

The room was cold, furnished only with a narrow rope-bed, an iron wash-stand, and a narrow slit of window that looked out over the black, roaring gorge.

Rodney shut the heavy oak door with his heel. He was carrying an unlit pipe in his teeth and smelled of horses and old leather. He pulled the single wooden stool from the wall, sat down with his knees spread wide, and squinted at his brother, who was packing his linen shirts into a split-hide portmanteau.

"The old man gave you the whip, didn't he?" Rodney said, grinning with that rough, easy affection that had never changed since they were boys throwing pebbles at river rats.

"He gave me fifty sovereigns and took the Lisle," Lied said, folding a green woollen doublet with neat, mechanical movements. "It is what he does."

"Aye, it's what he does," Rodney agreed. He took the pipe from his mouth and tapped the bowl against his boot-heel. "He thinks you're going south to study civil law and Church history, like the Bishop's boys."

Lied stopped. He laid the doublet on the bed and turned.

"I am not studying civil law, Rodney."

Rodney paused, his blue eyes narrowing slightly. "Then what?"

"Mage-Knight curriculum," Lied said. "The dual faculty. The Hall of Blades and the Tower of Geometries."

The silence in the small room lasted five long heartbeats.

Then Rodney threw his head back and let out a roar of laughter that rattled the leaded glass in the window-slit.

"Mage-Knight!" the elder brother gasped, slapping his thick thigh with enough force to crack leather. "Lied! Little brother! You can barely parry a two-handed sweep without your elbows shaking, and the only magic you've ever worked was cheating a notary out of three groats! A Mage-Knight? Those madmen spend eight hours a day in sixty pounds of mail, and the other eight hours drawing etheric circles on stone until their noses bleed! Nobody has passed both trials since the third year of King Alden!"

"Someone passed it," Lied said quietly.

"Aye, sixty years ago! A duke's heir with three blood-lines and a chest of fire-crystals as big as an ox-cart!" Rodney shook his head, his laughter dying down into a look of genuine, worried bewilderment. "Why, Lied? You have the sharpest mind on the March. You could be the high chancellor in the capital before you're thirty. You could sit on the King's board of customs, take bribes from three merchant guilds, and live in a palace with four fireplaces."

Lied looked through the arrow-slit into the blackness of the gorge.

He thought of Morris of Salt-Grave, dragged through the sheep-dung because his promise was smoke.

He thought of the two hundred and forty villagers who had walked home in the dark because a road had broken in the high pass.

And he thought of the terrible, crushing weight that had settled over his shoulders when Eileen had knelt in the river mud, looking at him as though he were an angel of the Seven Seats.

"If you only hold paper, Rodney," Lied said, his voice dropping into that quiet, chilling register that had once silenced the notary at Cross-Keys, "a man with an iron sword can take it from you in five seconds. And if you only hold an iron sword, a man with a piece of paper can starve your army without drawing a knife."

He turned back to the room, his grey eyes clear and unyielding.

"I am not going to be a man who begs a baron for weir-keys. And I am not going to be an under-clerk waiting for my father to throw me an acre of scrub-land."

Rodney stared at his younger brother.

The big, rough soldier sat in the dim candlelight, looking at the slender boy who stood before him. For a moment, Rodney did not see the younger brother he had pulled out of the Glass Hollow eight years ago; he saw something else—a shape moving through the dark, cold and sharp as a spear-point, whose trajectory no wall in the March could turn aside.

Rodney sighed, a long, heavy breath that shook his thick shoulders.

"Madness," he muttered. "Absolute, raving lunacy."

He reached inside his arming-doublet.

His hand emerged with a heavy pigskin pouch, tied tight with horsehair cord. It was round, fat, and when he tossed it through the air, it landed upon Lied’s bed with a dull, heavy *clink* that sounded like lead hitting gravel.

Lied looked at the pouch. He did not touch it.

"What is this?"

"My share of the cattle-bounty from the northern ridges," Rodney said, rising from the stool and stretching his great arms until his joints popped. "Twenty gold sovereigns. Real sovereigns, struck at the capital, not clipped border silver."

"Rodney, you need that money for your chargers—"

"I have three chargers, and the March pays for their oats," Rodney barked, turning toward the door. He paused with his hand on the latch, his broad face half-shadowed by the dying taper. "The old man gave you fifty sovereigns to keep you on small beer and sour porridge. If you're going to try and crack two schools at once, little brother, don't do it with an empty belly. And buy yourself some decent steel. If I hear that an Evans boy got his teeth knocked down his throat by a merchant's son in the southern ring, I'll ride three hundred miles to break your other leg myself."

He pulled the door open, stepped out onto the cold stone landing, and pulled it shut behind him.

Lied stood alone in the chamber.

He looked at the pigskin pouch lying on the coarse wool blanket.

He picked it up. The gold was heavy, cold, and possessed of that deep, silent resonance that only coin bought with blood and steel ever carries.

Twenty sovereigns from his brother's bounty.

Fifty from his father's quarterly educational scrip.

And sixteen sovereigns cleared from the Lisle treasury—his statutory ten-percent commission as retiring steward, audited and released under Master Alder’s notarized discharge upon handing the valley rolls to Cousin Martin.

Eighty-six gold sovereigns in clean, unencumbered royal coin.

Lied unlatched the split-calf book from inside his tunic. He dipped his quill into the small traveling inkhorn on the washstand with his left hand.

On the left-hand page, below the long debt of the iron-rebate, he wrote:

*Lied Evans, student of the Dual Path: to pass the Gate of Blades and the Gate of Geometries at Griffin Academy, before the Michaelmas bells.*

He blew upon the ink until it dried.

Then he blew out the candle, pulled his boots off in the dark, and lay down upon the rope-bed to sleep.
