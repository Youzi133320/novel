# Chapter 1: The Careless Promise

> *From the Commonplace Book of Lied Evans, Steward of the Lisle Holding:*
> 
> **[Unsettled — Written Left-Handed]**  
> *Three wains of winter seed-oats, marked North Dike, unaccounted for at the dry-barn.*  
> *Lina of the Tower: Twelve gold sovereigns to the Bursar of Griffin, before the equinox.*  
> 
> **[Settled — Written Right-Handed]**  
> *Two tallow tapers issued to the ditch-watch: six copper pence.*  
> *Salted pork barrels, fourth cellar tier: twenty-two, sound under wax.*

***

The ink in the stone well had frozen twice since sunrise, and each time Lied had to hold the pot over the peat embers until the black skin thinned and gave up its smell of gall and vinegar. It was thin ink, supplied by his father’s clerk at a third of a copper penny the pint, and on rough sheepskin it spread like lichen if the pen lingered half a heartbeat too long.

Lied did not linger. His iron nib made a dry, rhythmic scrape across the grain, ruling out the line for the North Dike tenantry and entering the total in the narrow margin on the right.

He added the figures twice, his left thumb following the column down while his right hand held the quill poised an inch above the desk. The sum was short by eighty-four bushels, which was precisely three cartloads. Old man Hallet had sworn under oath three weeks before the frost broke that the sacks had been hauled into the high barn before the first sleet, but Hallet’s second cousin kept the malt-house by the river, and the malt-house chimney had smoked all through January while the rest of the valley burned wet alder.

It was not an outrage; it was simply three carts of oats. If he docked Hallet’s lease now, the family would eat their seed-corn before April and come begging at the manor gates before the barley was knee-high, and his father, Viscount Robert, would deduct the relief grain from Lied’s quarterly allowance with a line of dry Latin in the ledger.

Lied laid the pen across the groove in the cedar block. He rubbed his eyes with the heel of his palm. His knuckles were red from the draught that came up through the floorboards above the cart-shed, carrying the warm, sour steam of horse dung and wet hay.

A heavy tread climbed the outer wooden stairs, slow and uneven, accompanied by the dull clink of iron scabbard against iron stirrup-leather.

The door latch lifted. A gust of raw mountain air drove into the room, fluttering the loose slips of parchment weighed down under a river pebble.

Sir Barend paused on the threshold, his head ducked beneath the lintel. He was fifty or more, with hair like dirty salt and the thick, weathered neck of a man who had worn steel gorgets since the second border levy twelve years ago. He wore his patrol brigandine, the boiled leather stained dark across the chest where melting rime had seeped through the seams. He had wiped his boots at the landing, but the yellow clay of the low marshes still clung thick to his heels, and he remained by the door sill, unwilling to set foot upon the grease-spotted wool carpet that marked the steward's half of the room.

"Master Lied," Barend said. His voice was cracked, scraped raw by four nights of wind along the dry-stone dykes.

"Close the door, Barend," Lied said without looking up from the roll. "The smoke from the brazier is bad enough without the river fog driving it down my throat."

The knight turned, pulled the heavy oak door shut until the iron dog clicked into place, and took off his gauntlets. He tucked them under his left arm—the arm with the stiff shoulder that never quite came level with his collarbone—and stood at attention.

"The south sluice is cleared," Barend reported, reciting the sentences in the stiff, measured cadence of a garrison sergeant. "Two dead ewes dragged from the grating. Water is three inches below the sill at noon. If the high snow holds another week, the winter rye won't drown."

"And the horse patrol?"

"Six mounts sound. One threw a shoe on the gravel reach near the boundary stone. The smith at Cross-Keys has no charcoal until Tuesday, so I had the beast walked home."

Lied made a small stroke against the fodder ledger. "Good. Take a jug of small beer from the pantry on your way down, and tell the cook I said you were to have bread and bacon. You look like something fished out of the mill-pond."

The old knight did not move. He stood with his thumbs hooked into the broad leather belt that supported his broadsword, his gaze fixed on the low cross-beam three inches above Lied’s head. His leather coat creaked softly as his chest rose and fell.

Lied capped his inkhorn and tilted his head. "Something else?"

Barend shifted his weight from his sound leg to his bad one. In the field, facing a dozen cattle-thieves from the upper ridges with bows drawn, the man would not have hesitated three seconds before giving the order to dress ranks. Here, before an ink-splattered trestle table and a seventeen-year-old boy in a frayed fustian doublet, he looked extraordinarily uncomfortable.

"A private matter, my lord."

"I am not your lord," Lied said mildly. "My brother Rodney is your future lord, and my father is your present one. I merely keep the accounts so the Viscount doesn't have to smell sheep while he reads about them. Sit down before your leg gives out."

Barend hesitated, then pulled the stool from against the lime-washed wall, scraping its splayed legs across the grit. He sat gingerly on the front two inches of the rush seat, keeping his muddy boots tucked back beneath his calves. From the breast of his brigandine, beneath the oilcloth flap that kept rain off his shirt, he drew a small, square packet wrapped in waxed linen.

He laid it on the edge of the desk.

"Lina," Barend said. He cleared his throat, found the sound too loud in the low room, and dropped his tone an octave. "My sister."

Lied glanced at the parcel. "The one who does the sums for the grain mills?"

"She does more than sums," said Barend, and for a fraction of a second his tired eyes hardened with something fierce and stubborn. "The parish priest had her reading the Vulgate before she was nine. Last autumn, when the surveyor came through from the capital to map the river holdings for the new tithe, he gave her three problems on a slate. Geometric proofs. Things with triangles and etheric ratios."

"And?"

"She solved them before his boy had finished baiting the horses," Barend said. He pushed the waxed parcel forward an inch with two blunt, scarred fingers. "The surveyor left a letter. A testing certificate from Griffin Academy. The preparatory faculty for natural arithmetic and ether-craft."

Lied picked up the parcel. The wax was cold and smelled of beef tallow and old pine resin. Inside, folded twice and sealed with grey wafer, was a single sheet of heavy rag paper—not the cheap sheepskin of the March, but genuine vellum, cream-coloured and smooth as milk. The seal was impressed with the split shield and compasses of Griffin, the great academy three hundred miles to the south, where the sons of counts and wealthy merchant-magnates were taught the arts of statecraft, war, and the higher geometries of magic.

Lied read the lines swiftly. His Latin was serviceable, drilled into him by his father’s chaplain until his palms had blistered under the ruler.

The certificate was clear. Lina of the Lisle Tower had been examined in absentia, her proofs verified by a proctor of the third rank, and her name entered upon the matriculation list for the class of the vernal equinox.

At the bottom, inscribed in the dry, sharp hand of an academy clerk, was the fee schedule.

*Tuition and board for commoners not under territorial charter: twelve gold sovereigns per annum. Payable in full at the bursary gate prior to the commencement of lectures.*

Twelve sovereigns.

Lied looked up from the vellum. Barend was watching him with the desperate, motionless patience of an old hound waiting for a verdict at the kitchen door.

"Twelve gold sovereigns," Lied said softly. "A full company of heavy infantry costs nineteen sovereigns a month in rations, steel-repair, and oats."

"I have five," Barend said, his voice dropping so low Lied had to lean across the desk to catch the words over the wind in the chimney. "I have two sovereigns saved from the king’s muster five years ago, and three in silver crowns from the bounty on the ridge wolves. And my sister has two gold groats she earned copying accounts for the wool-stapler at Cross-Keys."

"That is five sovereigns and a fraction," Lied observed. "Griffin does not admit fractions."

"I know," Barend whispered. He pressed his palms flat against his leather knees. "My service contract with the March has four years left before I am due my discharge acre. Viscount Robert pays me eighteen silver crowns a year, plus my keep and horse-maintenance. I... I came to ask if the estate might advance the balance against my pay. Two years of my stipend. Three, if the interest requires it. I will waive the horse-allowance and patrol on foot."

Lied leaned back against the high spindle-back chair.

The room was very quiet. Outside, a crow called from the sodden thatch of the tithe barn, a flat, harsh croak that repeated twice and died away into the grey mist hanging over the river.

Lied looked at Barend. He knew the numbers better than the knight did. Barend was fifty-two. His right shoulder was permanently dropped from an old pike-thrust through the joint, and in a wet spring like this one, he could barely lift his broadsword above his ear. If Barend waived his horse-allowance, he would be useless on the border reaches within six months; a patrol captain who walked the dikes was merely a watchman who could be ridden down by three horse-thieves with rusty lances.

More than that: Viscount Robert did not advance pay against common service contracts. To Viscount Robert, a knight of the garrison was a calculated expenditure of meat, iron, and silver, depreciation included. If a soldier died with three years’ pay drawn ahead, the debt died with him, and Viscount Robert detested unrecoverable balances.

If Barend took this petition to the manor house at High Crag, the Viscount would not merely refuse it; he would see that Barend was growing soft, wonder if the man’s mind was still on the garrison, and likely replace him with a younger sergeant from the household guard before midsummer. Barend would lose his command, Lina would stay in the village, and by winter the girl would be married to an ale-brewer or scribing bills for the timber-wharf at two pence the week.

Lied glanced back down at his desk.

His left hand, resting on the margin of the open ledger, twitched slightly.

It was an odd sensation, one that had visited him three or four times since the winter thaw began. A faint tightness across the bridge of his nose, like the pressure of a summer thunderstorm gathering beyond the eastern hills. It was accompanied by an acute, almost painful clarity: he could see the frayed thread on the cuff of Barend’s tunic, the yellow stain of tobacco juice on the knight's thumbnail, the three tiny holes where a beetle had bored into the cedar inkstand.

He did not want Barend broken. The Lisle holding was quiet under Barend’s watch; the cattle stayed on their pastures, the tenants paid their tithes without rioting, and Lied was left alone to read his books and audit his accounts in peace. If his father sent a new captain from High Crag, the newcomer would be an ambitious bastard eager to impress the Viscount by uncovering shortfalls in Lied’s commissary.

Twelve sovereigns was a monstrous sum for a village girl.

Yet the thought of explaining all this to Barend—the bureaucratic cruelty of his father’s ledger, the impossibility of the loan, the certainty of refusal—exhausted him. It would require twenty minutes of argument, apologies, the old man’s bowed head, the awful sight of an armed knight swallowing his pride before a boy half his age.

Lied folded the vellum neatly along its original creases and slipped it back into its waxed cover.

"You won't pledge your pay, Barend," Lied said.

The knight’s shoulders sank by half an inch. His mouth set in a thin, pale line, and he began to reach out a scarred hand to reclaim the paper.

"No, my lord," Barend said quietly. "I understand. The Viscount—"

"You won't pledge it because I won't have my picket captain marching through the marsh on foot like an unarmoured serf," Lied interrupted, his tone brisk and dismissive, as though he were correcting an error in the oat totals. "The bursar at Griffin wants gold, not four years of an old man’s rheumatism."

Barend froze, his hand suspended an inch above the waxed linen.

"Master Lied?"

Lied picked up a narrow cedar splinter—a cooper’s offcut used for scraping dry wax from seals—and turned it between his fingers.

"The Lisle bailiwick holds a discretionary purse for local stipends," Lied lied smoothly, without a tremor in his voice or a blink of his grey eyes. "It comes out of the timber tolls from the upper wharf. My father rarely looks at the secondary schedule so long as the main river levy meets the quota. I will have the twelve sovereigns transferred to the merchant bank at Cross-Keys before the end of the month, drawn under a bursary warrant from the March."

The silence in the room became absolute.

Even the dripping of the eaves outside seemed to recede into a dull, distant murmur.

Sir Barend stared at the young man across the table. His jaw worked once, twice, but no sound came out. A deep, dark flush rose from beneath his leather collar, creeping up his neck into his weathered cheeks. To an old Marcher soldier, a promise given across a desk by the blood of Viscount Evans was not a matter of business; it was a feudal covenant, an act of lordly grace so sudden and overwhelming that it seemed almost religious.

"Master Lied..." Barend’s voice cracked completely. He pushed the stool back, the wood screeching against the floor, and dropped heavily to his right knee. The iron plates of his brigandine clattered against the floorboards. "I... the house of Evans has my life. My grandfather held the palisade at Oakhaven for your great-grandfather, and I have given thirty years to the line, but this... my sister..."

"Get up, Barend," Lied said, a flicker of genuine irritation passing through him. "You’ll crack the ceiling beams with that knee, and the bailiff will charge me for the plaster. Take the paper and go see to the smith. I don't want that horse going lame."

Barend rose slowly. His eyes were bright with a moisture that he furiously blinked away, his jaw clamped tight to master his trembling chin. He picked up the parcel as though it were made of spun glass, tucked it deep inside his brigandine against his ribs, and bowed—not the curt nod given to an employer, but the full, sweeping inclination of the head reserved for the Viscount himself in the great hall.

"Before the equinox," Barend whispered. "I will have her ready for the coach. May the Light preserve you, Master Lied."

"Yes, yes," Lied murmured, already reaching for his quill. "Go eat your bacon."

The knight backed toward the door, opened it with exaggerated care so as not to disturb the papers on the table, and stepped out onto the landing. The heavy oak slammed shut behind him.

Lied was alone again.

He sat motionless for several seconds, the goose feather balanced between his fingers.

The cold room seemed strangely altered. The faint smell of ozone and thunderstorm pressure had vanished, leaving only the familiar stench of peat smoke and damp sheepskin.

Lied looked down at the desk.

*Twelve gold sovereigns.*

Where on the face of the Graycrown continent was he going to find twelve gold sovereigns before the vernal equinox?

The timber toll at the upper wharf had been mortgaged to a moneylender from the capital three years before Lied was born; there was no discretionary purse, there had never been a bursary warrant, and if his father discovered that his seventeen-year-old second son had promised seventy-two pounds of fine silver or its equivalent in royal gold to educate a garrison captain's sister, the Viscount would likely strip him of the stewardship before nightfall and send him to the southern abbey to count sheepskins for the monks.

Lied let out a long, slow breath through his teeth.

He picked up the cedar shaving. Taking the quill in his left hand—the hand he used when he was scribbling draft tallies that no one else was meant to inspect—he wrote in small, cramped script:

*Lina. Griffin bursary. 12 sov. Due equinox.*

He stared at the wood for a moment, his brow furrowed.

He could always tell Barend next week that the bursary had fallen through. A letter from High Crag; a sudden tightening of the border purse; an imperial decree regarding non-noble quotas. Barend would be crushed, but he was an old soldier; he was accustomed to disappointment. Men of Barend’s station spent their entire lives having the world reach out a cup of clear water and snatch it away before they could drink.

Yes. That was the sensible path. He would invent an official refusal from the Viscount’s chancellery, deliver it with a grave face and five silver groats of his own money as an apology, and the matter would be settled.

Lied tossed the cedar shaving into the wooden tray beside his sandbox.

A sharp, hurried knock sounded on the door, followed immediately by the appearance of Giles, the red-haired bailiff's lad. The boy was breathing hard, his woolen stockings splattered with brown mire to the knees.

"Master Lied! You're wanted down at the Upper Weir."

Lied did not look up from his ledger. "The water is three inches below the sill. Barend just reported it."

"It was three inches, sir! But the timber-boom above the miller's race broke twenty minutes ago. A dead oak came down with the thaw-water from the high woods, jammed the middle sluice, and the back-water is pouring into the ditch-bank. The tenants are out with spades, but if the bank gives, the south pasture will be a pond before sundown."

Lied looked at the half-finished oat tally, then at the pile of unexamined tenant petitions waiting in the wicker basket.

"Did the gate-keeper have the iron lever?"

"Old Tom dropped it in the race when the boom cracked, sir. He says it's washed down into the mud."

Lied closed the ledger with a dry slap that sent a puff of chalk dust into the cold air.

He swept the loose papers into the leather portfolio, took his rabbit-lined cloak from the peg by the door, and kicked off his indoor slippers, jamming his feet into the stiff, greasy leather of his riding boots. As his forearm brushed across the desk, a corner of his cloak caught the edge of the wooden tray. The small cedar shaving, with its wet ink inscription, slid off the rim and vanished beneath a heavy sheaf of uncollected hay-tithe receipts from the previous autumn.

Lied pulled the buckle of his belt tight, picked up his riding crop, and blew out the tallow candle.

"Tell the stable-boy to saddle the roan," he said, stepping past the lad onto the wet, windy landing. "And bring two iron crowbars from the forge. If the timber is jammed, we'll split it with wedges before we drown the seed-corn."

He hurried down the timber stairs, his boots thumping against the wet treads, his mind already full of sluice gates, leverage, and the cold reality of river mud.

Behind him, in the darkened room, the cedar sliver lay buried in the paper, silent, unremembered, and waiting.
