# Book One: The Apprentice of Lies
## Part 3 Master Outline (Chapters 9–13): The Smugglers, the Demon, and the Ford

> **Arc Objective**: The escalation from academy intrigue to regional geopolitical conspiracy. Lied discovers an underground theft network, encounters an infant dragon, balances three irreconcilable institutional factions, uncovers a false-flag border war orchestrated by a possessed officer, and averts slaughter at the river ford through a daring verbal gamble made real by his allies.  
> **Estimated Word Count**: 25,000 – 32,000 words across 5 chapters.

---

### Chapter 9: Crystals in the Tunnels
- **Core Event**: Etheric storage crystals vanish from the labyrinthine Romanesque vaults beneath Griffin Academy—tunnels shared uneasily by the academy laboratories, the subterranean smuggling routes of the orc broker Gruk, and the local cathedral’s purification works.
- **The Investigation**: Lied conducts his own discrete accounting. He catches the respectable cleric Marcus skimming tithe donations and doctoring the Church cellar logs. In exchange for silence, Lied blackmails Marcus into handing over confidential Church heresy records.
- **The Discovery**: Tracking the missing crystals through the damp drainage conduits, Lied corners the thief. It is not an orc saboteur or an academy student, but a starving, stray dragon hatchling, sickly and disoriented from gnawing raw ether-matrix crystals. Lied conceals the creature in an abandoned subterranean lime kiln, feeds it dried salt beef, and names it **Tally**.

### Chapter 10: The Raids and the Possessed Officer
- **Core Event**: Armed caravans burning along the border trade highway. Human militia blame orc reavers from the eastern steppes, and the March prepares for punitive mobilization.
- **The Scholarly Clue**: During an advanced lecture on tribal thaumaturgy, Magister Aetherine demonstrates the distinctive burn marks of true orc war-magic—spiraling ash and jagged sulfur fractures. Lied inspects the wreckage of a burnt freight wagon and realizes the scorch marks are clean, imperial military fire-craft, deliberately forged.
- **The Dark Thread**: Combining Gruk’s underworld intelligence with Marcus’s internal Church reports, Lied identifies the architect of the attacks: Jem, a respected frontier security officer. Jem is carrying a Celestial Heart Demon beneath his ribs. Jem answers to Duke Victor Greven, who desires a full-scale border war to justify mobilizing a private ducal army and seizing the border mines.

### Chapter 11: Three Clients and the Contained Failure
- **Core Event**: Lied finds himself hired or consulted by three mutually antagonistic factions, each demanding a resolution to the border crisis:
  1. The Academy wants a quiet academic investigation that keeps royal inspectors away from their illegal tunnel excavations.
  2. Gruk’s smugglers want their subterranean freight arteries restored and their tribal kin cleared of false blame.
  3. The Cathedral (via Marcus) wants a clean, external culprit to protect Church integrity.
- **The Web of Partial Truths**: Lied feeds each client a tailor-made slice of the truth, manipulating their movements to corner Jem without exposing his own cards.
- **The Complication**: Isolde Gregory, an extraordinarily perceptive transfer student on the Assassin path, audits Lied’s logistics ledger and spots an unexplainable mathematical discrepancy.
- **The Sacrifice**: To throw Isolde off the scent and keep the larger operation intact, Lied stages a deliberate, contained failure: he leaks a minor route that allows city watchmen to seize one of Gruk’s illicit spirit-wine shipments. Gruk loses a profitable tunnel, and Lied incurs a severe orc blood-debt that he must promise to repay in full.

### Chapter 12: The Parley at the Ford
- **Core Event**: The climax of Book One. Duke Victor Greven’s conspirators stage a decisive border provocation at Raine Ford, positioning an Evans March militia regiment opposite an armed orc diplomatic delegation. Both sides have arrows notched and blades drawn; rain lashes the muddy shallows.
- **The Great Bluff**: Knowing that an arrow loosed now will ignite five years of regional war, Lied rides his roan directly into the deep current between the two battle-lines. Holding up an empty bone-scroll case, he proclaims with ringing, unflinching conviction that the orc chieftain has signed a solemn blood-oath of non-aggression, which he personally holds.
- **The Race Against Dawn**: The scroll case is empty. Both armies agree to hold their fire until first light to verify the chieftain's blood-seal. While the standoff holds in the freezing rain, Gruk rides through the mountain pass on a black courser, with Lina clearing a collapsed mudslide using an emergency etheric combustion matrix she calculated from her grammar books.
- **The Payoff**: The true blood-oath arrives at dawn’s first grey light. Simultaneously, Isolde Gregory springs Jem’s own hidden ambush on him, dragging the security officer into the river shallows where the heart demon inside him is forced to manifest in full view of both human lords and orc elders. The demon is slain, Duke Greven’s plot is shattered, and the war never happens.

### Chapter 13: Payoffs, Debts, and the Closing Hook
- **The Reaping**: 
  - Academy Dean Winters writes a glowing commendation recommending Lied for the prestigious Silver Tower in the capital.
  - Cleric Marcus provides an official Church certificate of merit and clean orthodoxy.
  - Magister Aetherine privately warns Lied of a secretive assembly of female scholars (the Witches' Circle) whom he must never, under any circumstances, attempt to contact.
  - Gruk’s nephew begins observing Lied’s business transactions, subconsciously mimicking his negotiating habits and pauses—the first seed of Lied's "School" taking root in a foreigner.
- **The Dark Revelation**: Going through Jem’s confiscated personal papers before they are burned, Lied discovers a ciphered list of gifted commoners whom Duke Greven’s demon cabal had marked for kidnapping as host vessels. Near the middle of the roll is the name *Lina of Lisle Tower*—struck out with a red line on the exact week she enrolled at Griffin. Her salvation was an accidental byproduct of a forgotten promise. Lied burns the list and tells no one.
- **Closing Hook**: Inquisitor Silas von Heide arrives in a black carriage to cleanse the ashes of Jem's demon. He inspects the parish registry, pauses at Lied’s double-handed signature, and narrows his pale eyes. That night, an anonymous package containing forbidden pre-Cataclysm treatises arrives at Lied's quarters without a seal. And high on the granite ridge above the Glass Hollow, an unseen figure who has watched the Evans boy for eight years turns away into the pines.
