# Book One: The Apprentice of Lies
## Part 2 Master Outline (Chapters 5–8): River, Seal, and Griffin

> **Arc Objective**: From rural crisis management to the institutional cauldron of Griffin Academy. Lied leverages his first major political bluff to avert flood disaster, secures his father’s grudging recognition, and enters the kingdom's elite academy as an impossible dual-practitioner (Mage-Knight), navigating aristocratic cliques and meeting a hostile, indebted Lina.  
> **Estimated Word Count**: 18,000 – 24,000 words across 4 chapters.

---

### Chapter 5: The Late Flood
- **Core Event**: Midsummer downpour. The River Lisle rises six feet in eighteen hours, threatening the lower villages and the Evans March harvest. Lied rushes to the archival vault and discovers a horrifying administrative catastrophe: the three-decade diversion compact with the Auden estate upstream had expired five years earlier during his grandfather's illness.
- **The Ride to Auden**: Accompanied by Barend, Lied rides through a midnight gale to the stronghold of Baron August Auden. Auden intends to let the water drown the Evans March rather than flood his own marginal meadows.
- **The Bluff**: Drenched and mud-splattered, Lied bluffs with the absolute authority of a man holding an army: he claims Viscount Robert has already dispatched an envoy with a newly ratified trade charter and border concessions, warning that closing the weir now will be treated as an overt act of war.
- **The Sluices Open**: Auden wavers, sees no hesitation in the boy’s eyes, and lifts the sluice gates. Working alongside the peasants on the dikes is a young novice nun named Eileen, whose pure, unshakeable faith reads Lied's timely arrival as an act of divine intervention.

### Chapter 6: Making It True
- **Core Event**: The water recedes, but Lied has exactly seven days before August Auden sends his riders to High Crag to collect on the promised terms.
- **The Bureaucratic Forgery**: Lied has seven days to turn a brazen lie into an irrevocable legal fact. 
- **The Play**: He intercepts the Auden envoy halfway, extracts the signature of an Auden clan elder by playing on a centuries-old inheritance grudge, and uses his brother Rodney’s carelessness to gain temporary access to Viscount Robert’s seal-ring while his father is inspecting the frontier garrisons.
- **The Cost**: The treaty is bound into the March rolls. Lied creates a permanent legal fiction that he will have to service, defend, and nurse for years to prevent discovery.

### Chapter 7: The Family Dinner
- **Core Event**: Viscount Robert summons Lied to the high keep at High Crag. The father knows his son pulled off something slippery with the Audens, even if he cannot prove the forgery.
- **The Confrontation**: The Viscount delivers a cold, calculating evaluation: he grants Lied a modest annual allowance for Griffin Academy, accompanied by a blunt reminder that the Lisle stewardship can be stripped away in a single morning.
- **Brotherly Friction**: Rodney, burly and honest, mocks Lied’s preposterous ambition to study both the steel of the knight and the etheric geometry of the mage. That evening, however, Rodney slips into Lied’s bedchamber and drops a heavy purse of gold sovereigns onto his blanket: *"If you're going to get yourself killed playing scholar, don't do it in boots that leak."*

### Chapter 8: Griffin Academy
- **Core Event**: Autumn. Lied arrives at the grey stone towers of Griffin Academy. He publicly declares his intention to enter the dual Mage-Knight curriculum—a feat not accomplished in four generations.
- **The Entrance Trials**: He lacks both the pure mana reserves of the highborn sorcerers and the raw mass of the frontier knights. Drawing upon the accumulated belief of Barend, the Lisle villagers, and his brother's gold, a strange luck cushions his sword-strokes and sharpens his arithmetic proofs. He scrapes through by half a point.
- **Faculty Reactions**: Magister Voss calls his pass a freak accident; weapons-master Brutus sees the cold, vicious calculation in his footwork and calls it a beginning.
- **The Social Arena**: Felix Ashworth, a highborn snob, tries to probe Lied’s frontier background; Lied uses Edwin Colin, a friendly and credulous noble, to corroborate an aristocratic pedigree Lied quietly improvises on the spot. Lied gains entry to the prestigious Silver Spoon Society, discovering that appearing not to care about money attracts more credit than gold itself.
- **The Collision**: Lina arrives at Griffin on the coach, thin, fierce, and armed with secondhand books. The moment she sees Lied in his fine student tunic, she realizes whose coin paid her bursary. She confronts him in the courtyard, furious at being made his dependent charity.
