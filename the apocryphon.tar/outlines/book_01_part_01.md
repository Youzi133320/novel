# Book One: The Apprentice of Lies
## Part 1 Master Outline (Chapters 1–4): The Weight of Words

> **Arc Objective**: From an unthinking verbal promise to the formal discovery and calibration of Prophetic Utterance (Witness / Illusion). Lied learns the mechanical boundary between a fraudulent falsehood and an unfulfilled claim, institutes his two-handed ledger, and experiences belief as a physical mass in a room.  
> **Estimated Word Count**: 14,000 – 18,000 words across 4 chapters.

---

### Chapter 1: The Careless Promise *(Completed)*
- **Core Event**: Early spring audit in the Lisle steward's room. Oat tally shortfall. Sir Barend petitions for a four-year pay advance to cover his sister Lina's 12-sovereign tuition at Griffin Academy. Lied casually grants the bursary under a non-existent estate fund to keep his captain operational, jots a left-handed note on a cedar shaving, and immediately forgets it when the Upper Weir sluice cracks under thaw-water.
- **State Change**: Barend's absolute feudal loyalty is pledged; Lied's memory of the debt is completely buried under spring chores.

### Chapter 2: The Scales That Won't Light
- **Core Event**: The Cross-Keys sheep fair. Morris, a sharp-eyed factor trading under the north-country name of Aldous Clark, attempts to register a forward delivery contract for twenty bales of virgin wool before the imperial notary, Master Alder. 
- **The Crucible**: The notary’s Office of Weights and Oaths operates with an etheric balance—a low-tier enchantment that glows pale silver when a commercial oath is sworn in good faith over tangible inventory. Morris swears he has the fleece stored in the high valley. The scales remain dead, cold iron.
- **The Downfall**: Alder’s cross-check with the parish tax roll reveals the shearing sheds in that valley were burned by blight two years past. Morris is stripped of his factor's badge, fined his entire bond, and run out of the bailiwick in an afternoon.
- **Lied's Observation**: Sitting in the notary's gallery with the parish tithe roll, Lied watches Morris's ruin with cold fascination. He deduces the foundational law: *Morris failed not because he lied, but because his claim was structurally impossible from its inception.* A lie with nowhere to land is dead iron; an unmade truth with an open road is something entirely different.

### Chapter 3: The Late Payment
- **Core Event**: Three weeks later. Barend captures a notorious horse-thief on the ridge and brings the five-crown bounty to the bailiff's desk. With shining, humble eyes, Barend asks if the Griffin bursary receipt has cleared the chancery yet.
- **The Shock & The Scramble**: Lied experiences a jolt of panic—he had forgotten every syllable. Barend interprets Lied’s frozen silence as a deliberate test of his patience and loyalty.
- **The Execution**: Rather than admit his casual negligence and break the knight, Lied uses the bounty money, skims from the uncommitted ditch-repair reserve, and writes a forged draft on his father's chancellery.
- **The Clustering of Chance**: Once the coin is pledged, a strange run of coincidences begins to gather: the Griffin courier arrives two days early; the exchange rate for border silver rises by half a groat; an old debt owed to Viscount Evans by a wool-merchant is unexpectedly settled at the crossroads, covering the chancellery shortfall to the exact penny before the audit arrives. Lied notices that reality itself seemed to bend to keep his word intact.

### Chapter 4: The Ledger and the Room's Weight
- **Core Event**: Late spring. Lied formally purchases a split-calf binding and institutes his method: writing unsettled, prospective claims with his left hand, and striking them into settled facts with his right when they come due.
- **Empirical Experiments**: 
  - He tests the law on the kitchen maid Ella, remarking casually before the household that she has an uncanny eye for ciphering; within three weeks, Ella has taught herself the alphabet and basic arithmetic from discarded horn-books and bill-heads.
  - He promises the village elders that Master Corin, Chief Factor of the Marcher Wool-Hall, will attend their midsummer eve-feast to inspect fleeces and negotiate a direct charter; when an unexpected border mobilization detains the guest at High Crag, the promise breaks, and the village never believes him on that subject again.
- **The Awakening (Witness)**: By midsummer, Lied can physically sense belief and expectation in an enclosed room as a distinct atmospheric mass, while learning the sobering lesson that an unfulfilled promise hardens that specific social domain against him forever.
