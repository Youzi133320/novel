# Book Two: The Capital's Deceiver
## Part 1 Master Detailed Outline (Chapters 1–8): The City of Ledgers and the Three Masks

> **Arc Objective**: From rural frontier prodigy to capital power-broker. Lied establishes his twin launchpads in Castellon: the elite, statecraft curriculum of the **Silver Tower** by day, and the shadowy, uncollateralized acceptance engine of the **Tallyhouse** (under the mask of *Edric Vale*) by night. He tames a growing dragon in the vaults, breaks the monopoly audit of the Gold Scales League through a cartel alliance with Isabella Vant, and rides the massive tidal wave of popular sanctification engineered by Saintess Eileen.  
> **Target Word Count**: ~33,000 – 36,000 words across 8 chapters (average 4,200 words/chapter).

---

### Chapter 1: The Gates of Castellon
- **Setting & Arrival**: The transition from northern limestone and bog-iron to the wet slate, tiered marble aqueducts, and sulfurous coal-smoke of Castellon. The Great River crossing where deep-draft sea ketches unload silks and spices under the cold gaze of royal toll-gagers.
- **The Initial Rumor**: Frontier gossip has preceded Lied down the Great Turnpike: whispers claim that the second son of Viscount Robert holds the secret patronage of an ancient, griffin-mounted royal bloodline.
- **The Execution with Ansel**: Rather than let the rumor die of scrutiny, Lied goes directly from the coaching station into the rain-soaked gutters of the chandlers' quarter. He tracks down **Ansel**, the disinherited, impoverished heir to the ancient Griffin barony, currently living in a squalid garret over a fish-gutter's shed, drowning in tavern debt.
- **The Bargain & The Truth Made**: Lied pays off Ansel’s three-sovereign bar-slate, buys him a decent woolen coat and boots, and hires him on the spot as his public "Master of the Horse and Senior Equerry" at five silver crowns monthly. When Lied rides down the High Street toward the Silver Gate with Ansel carrying his standard in broad daylight, the wild rumor of royal griffin backing is cemented into indisputable public fact before sunset.

### Chapter 2: The Silver Tower
- **Academic Arena**: Lied matriculates into the elite, marble-domed **Silver Tower**—the faculty of Imperial Statecraft, Foreign Treaty, and High Arbitration, open only to elder sons of earls and senior Crown scholars.
- **The Institutional Friction**: High Archon Vane lectures on territorial copyholds and river jurisdiction. Court-born students (scions of the Ashworth and Greven circles) sneer at the provincial marcher boy. 
- **The Chess-Like Duel**: Vane presents an unresolved, sixty-year-old territorial border dispute between two crown river-bailiwicks that has clogged the Court of Chancery. Lied steps to the slate; drawing upon his real-world experience forging the Auden water-covenant and calculating seed-corn margins, he demonstrates that the dispute was manufactured by local toll-collectors exploiting an unaligned grain-weight ratio.
- **The Prize**: Vane is stunned by the cold, surgical practicality of the provincial boy's mind; he grants Lied private access to the Ministry's central tax registers. In the back row, **Prince Karl Wagner**, imperial military envoy from the Western Empire, takes quiet note of the second son.

### Chapter 3: The Birth of Edric Vale
- **The Problem**: Viscount Robert’s quarterly educational allowance arrives: exactly twelve gold sovereigns and ten groats, accompanied by a cold paternal letter warning him against debt and reminding him that his expenses will be scrutinized to the penny. Lied cannot finance political operations on a schoolboy's leash.
- **The Crafting of the Second Life**: Lied rents a narrow, damp, three-story timber tenement in the lower Banking Quarter near the fish-wharves, where the fog from the river covers nocturnal traffic.
- **The Persona**: He uses walnut-husk wash to create convincing liver-spots on the backs of his hands, dons a faded, horsehair wig with an ill-fitting salt-stained broadcloth mantle, and adopts the dry, coughing maritime stammer of a southern port factor: **Edric Vale**.
- **The Charter**: He hangs a plain painted shingle above the door: **The Tallyhouse**. It is not a depository bank; it is an *acceptance house* that discounts promissory notes and guarantees contractual performance between distrustful merchants of different provinces and races.

### Chapter 4: Tally in the Under-Vault
- **Subterranean Smuggling**: Under the cover of an autumn coal-barge, Gruk’s trusted northern runners smuggle **Tally** into the city.
- **The Dragon's Evolution**: The slate-blue hatchling has doubled in mass; its scales have hardened into cold, lead-colored armor plate, its jaw powerful enough to shear through oak staves. Lied houses the beast in the ancient, iron-gated stone cistern thirty feet beneath the Tallyhouse floor.
- **The Vault Defense**: Tally is provisioned with four pounds of butcher's suet daily and the discarded, cloudy ether-crystals purchased at scrap prices from the jewelers' guild. The creature’s subtle, ambient apex-predator ether creates an unpickable psychic deterrent: mundane canal-thieves who attempt to jimmy the basement grates find themselves paralyzed by inexplicable nausea and terror, fleeing without ever seeing what breathes in the dark.
- **The Elven Reserve**: Lied receives an envelope from Griffin: Magister Aetherine has honored her subtle intellectual debt, providing an authenticated letter of credit from the High Moon banking syndicates—an untouchable paper reserve that Vale deposits in the safe to anchor the Tallyhouse’s legal standing.

### Chapter 5: The Ledger of Promises
- **The Commercial Engine Ignites**: The commercial markets of Castellon are gridlocked: southern grain-factors will not release flour to northern timber-merchants without coin on the table, and northern carters will not haul timber without advance food scrip.
- **Vale’s First Masterstroke**: Master Edric Vale enters the floor of the Merchant Exchange. He takes forty thousand bushels of disputed northern timber into his books at a six-percent discount, issues Tallyhouse *Guaranteed Acceptance Vouchers* to the timber-merchants, and uses his elven credit to underwrite the grain-factors' risk.
- **Ingenuity over Capital**: Vale holds less than eighty sovereigns in physical coin, but because both sides believe the Tallyhouse holds sovereign elven bullion, the grain moves, the ships are masted, and the trade clears in twelve days. Vale nets one hundred and forty gold sovereigns in pure commission fees without moving a single cart himself.

### Chapter 6: The Audit of the Gold Scales
- **The Monopolist Backlash**: The **Gold Scales League**—the hereditary patrician banking cartel holding the royal monopoly on bill-discounting—notices that a third of the river trade has bypassed their counters.
- **The Inquisitorial Auditor**: The League’s governing council dispatches their deadliest weapon: **Isabella Vant**, chief auditing factor. Cold, aristocratic, carrying three bone abacuses and accompanied by two liveried baliffs, Isabella enters the Tallyhouse with an order of inspection under royal charter.
- **The Four-Day Siege**: Isabella spends ninety-six hours tearing through Vale’s journals, ledgers, and day-books. Every sum matches; every fraction clears. But on the fourth midnight, by the dying light of a tallow taper, Isabella’s finger stops on the register:
- **The Unlit Void**: *Not a single one of Vale's commercial covenants bears the silver phosphor seal of the King's Scales of Oaths.*

### Chapter 7: The Cartel Pact
- **The Midnight Confrontation**: Isabella locks the parlor door, lays her three abacuses aside, and confronts the dry, stammering old factor across the desk.
- **The Indictment**: She deduces that Vale's reserves are mathematically impossible under standard banking liquidity; his enterprise is either a colossal fraudulent house of cards or an unprecedented mechanism of leveraged credence that threatens to collapse the city if exposed.
- **Lied’s Counter-Strike**: Lied does not grovel as Vale. He straightens his back, drops his stammer for three sharp sentences, and produces a dossier drawn from his private access to the Silver Tower tax rolls: he exposes that three of the League's own senior directors have embezzled eighty thousand sovereigns to speculate on ruined southern sugar-islands.
- **The Compact**: Recognizing that destroying Vale will trigger a mutual liquidity panic that destroys the League, Isabella’s icy mercantile pragmatism overrides her loyalty to the directors. She agrees to grant the Tallyhouse full clearing privileges under the League's royal umbrella, in exchange for a twenty-percent commission on northern trade and one inviolable rule: *"Lie to the world, Master Vale. But if you lie to me about the real balance on your sheets, I will have your throat under the guillotine before breakfast."*

### Chapter 8: The Broadsheet of the March
- **The Religious Ignition**: Cleric Marcus, established in the high almonry of the Cathedral of Saint Jude, maneuvers to win favor with the Archdeacon by magnifying his provincial role in defeating border apostasy.
- **Saintess Eileen’s Triumphal Entry**: Sister Eileen arrives in the capital in her white novice habit, her hands bearing the holy water of the Open Link. She refuses noble lodgings, taking up her post at the public quays where thousands of watermen and poor weavers gather.
- **The Pulpit Storm**: Eileen speaks with unshakeable, luminous conviction, proclaiming to the crowds that young Lord Lied Evans is the *Saint of the March*—the chosen vessel who rode into the demonic floodwaters and commanded the river to spare the poor.
- **The Media Explosion**: Print-shops across the university quarter churn out thirty thousand wood-block broadsheets bearing Lied's portrait and the legend of the Dike Miracle. 
- **The Awakening of Credence**: Standing on the high balcony of the Silver Tower, Lied feels the second stage of his path shudder into life: an immense, warm, intoxicating pressure of collective belief settling over his shoulders. He has not spoken a word, yet thirty thousand souls in the streets are currently paying into his account.
