# Book Two: The Capital's Deceiver
## Part 3 Master Detailed Outline (Chapters 17–24): The Masquerade, the Dual Flesh, and the Barony

> **Arc Objective**: The grand climax of Book Two. Duke Victor Greven stages a military-demonic coup during the Royal Midwinter Masquerade. Lied executes the forbidden art of **Somatic Division** using the celestial remnants in his marrow, manifesting simultaneously as the Saint in the high ballroom and the Veiled Prince in the palace catacombs. He turns the demon cabal upon itself, unleashes Tally, channels mass collective credence into Saintess Eileen's divine fire, crushes the rebellion, secures an independent hereditary Barony, and earns his father's salute while Inquisitor Silas locks his sights on the double script.  
> **Target Word Count**: ~33,000 – 36,000 words across 8 chapters (average 4,200 words/chapter).

---

### Chapter 17: The Web of Five Truths
- **The Crucible Approaching**: Ten days before the winter solstice. Five distinct power centers converge on Lied, demanding intelligence regarding Guildmaster Corvo's missing bullion and the troop movements around the capital:
  1. *Isabella Vant (Gold Scales League)* wants to foreclose on Corvo’s mortgaged warehouses before the banks crash.
  2. *Inquisitor Silas von Heide (The Holy See)* wants to identify the demonic cell before the King suspects Church complicity.
  3. *Prince Karl Wagner (The Empire)* wants to secure imperial legations and prevent a general civil war.
  4. *Corvo's Demon Cell* expects the "Veiled Prince" to secure their illegal munitions barges at the river mouth.
  5. *Duke Victor Greven* intends to use the solstice ball to poison the High Council and seize the royal treasury.
- **The Information Partition**: Operating as Lied, Edric Vale, and the Veiled Prince, Lied sells five mathematically calibrated slices of truth, ensuring each party's counter-actions will cross and neutralize one another at the exact hour of the coup without revealing his central position.

### Chapter 18: The Mathematics of Division
- **Occult Breakthrough**: In her secluded laurel cottage in Morne, "Lydia Quire" deciphers the forbidden treatise *On the Mechanics of Somatic Division*.
- **The Fatal Risk**: Standard etheric geometry states that a mortal consciousness attempting to occupy two physical shells simultaneously suffers cerebral liquefaction within three minutes from sensory feedback. Selena writes back with an urgent cipher, warning Lydia that only beings possessing celestial divine authority can bridge the somatic gulf.
- **The Secret Catalyst**: Lied realizes that the stillborn Celestial Demon essence fused into his chest in the Glass Hollow at nine years old provides the exact, impossible biological fulcrum required. He secretly procures alchemical reagents through the Tallyhouse to brew the double-binding elixir.

### Chapter 19: The Eve of the Solstice
- **The Shadow Gathering**: A brutal blizzard descends upon Castellon forty-eight hours before the ball. Armed mercenaries in plain gray livery infiltrate the palace drainage conduits; Corvo prepares poisoned wine-butts laced with demonic bile.
- **Tally’s Awakening**: In the deep vaults beneath the Tallyhouse, Tally the dragon senses the foul, sulfurous ether creeping through the river bedrock. The beast has grown to the size of a war-horse, its slate-blue scales impenetrable to steel. Lied fits the dragon with an iron-banded headstall and leather harness—preparing his heavy subterranean battering ram.

### Chapter 20: The Somatic Split
- **The Midnight Rite**: Two hours before the masquerade. In the secret stone chamber beneath the Tallyhouse safe, Lied drinks the silver-mercury draught and speaks the celestial bifurcation formula with his left hand.
- **The Agony of the Double**: His mind tears apart with the sound of snapping bone. In the mirror, two distinct living forms step forth:
  - Body One: *Lied Evans*, the radiant, dark-haired Saint of the March, dressed in pristine silver-laced court broadcloth and an Evans green velvet mantle.
  - Body Two: *The Veiled Prince*, shrouded in swirling, pitch-black illusions, his eyes burning with cold abyssal violet fire, smelling of sulfur and wet copper.
- **The Mental Ledger**: Suffering horrifying sensory overlap—seeing the coach lanterns with his right eye while seeing the pitch-black sewer with his left—Lied forces his double-handed accounting discipline to maintain mental balance.

### Chapter 21: The Palace of Mirrors
- **The Ballroom Above**: Three thousand masked aristocrats, ambassadors, and prelates dancing under forty crystal chandeliers in the Great Palace of Mirrors.
- **The Social Duel**: Masked in a silver falcon visor, Lied mingles with high nobility, engages Duke Victor Greven in polite, mocking conversation over chilled wine, and discreetly slips an encrypted tactical sketch into Prince Karl Wagner’s sleeve, instructing the imperial guards to barricade the ballroom's private service lifts.

### Chapter 22: The Clash in the Crypts
- **The Catacombs Below**: Simultaneously, forty feet below the ballroom floor, the Veiled Prince rides Tally through the subterranean Roman water-conduits, intercepting Corvo’s demon strike-team at the treasury vaults.
- **The Sovereignty of Blood**: Lied unleashes his innate Celestial command. When the lesser heart demons see the Veiled Prince mounted upon a living dragon, their parasitic instincts override Corvo’s orders; Lied commands the demons to butcher their mortal handlers, triggering a savage, blood-soaked mutiny in the dark.
- **The Breakout**: Wounded and foaming with rage, Guildmaster Corvo breaks through the mutiny, sprints to the private royal hoist, and activates the counter-weights to carry his demon directly into the glittering ballroom above.

### Chapter 23: The Flame of the Open Link
- **The Breach**: The center of the ballroom floor shatters in an eruption of marble dust and splintered joists. Corvo emerges, his body torn apart as his massive, multi-legged Celestial Heart Demon bursts through his ribcage, howling an ear-splitting insectoid shriek and lunging for the royal dais.
- **The Avatar's Collapse**: The physical shock shatters the somatic projection below; the Veiled Prince dissolves into shadow, and Lied in the ballroom staggers, coughing a mouthful of bright blood into his lace cuff as his twin consciousness violently slams back into a single body.
- **The Miracle**: As Duke Greven shouts for his private guard to "save the King" (his pretext to seize the throne), Saintess Eileen steps through the panic in her snow-white habit, bearing the silver censer of the Open Link.
- **The Channeling**: Lied draws upon the massive, dormant reservoir of collective belief he built among fifty thousand citizens, funneling the entire psychic torrent into Eileen’s censer. Blinding, roaring white fire detonates from the silver vessel, incinerating the demon down to its chitinous core in full view of the King and the High Council. Duke Greven is surrounded and arrested in chains by Karl's imperial halberdiers.

### Chapter 24: The Baron of Brindle and the Twin Scripts
- **The Sovereign Reward**: Before the assembled estates of the realm, the King proclaims Lied Evans as the savior of the Crown, formally partitioning the frontier territory into the independent, hereditary **Barony of Brindle**, uniting it forever with the Lisle lands.
- **The Paternal Toast**: Viscount Robert arrives from the northern march in full campaign armor. For the first time in his life, the stern father does not treat Lied as an administrative dependant on sufferance; across an uncarved table in the royal chancellery, the Viscount raises a cup of rich southern vintage, giving his second son a curt, deeply respectful salute: the boy has conquered his own soil without an army.
- **Institutional Harvest**:
  - *Lydia Quire* is unanimously elected a Senior Research Fellow of the Witches' Circle, gaining unrestricted access to their private libraries.
  - The *Tallyhouse* opens branches across three river provinces, its clerks universally adopting Lied's calm, deliberate negotiating pauses.
  - *Tally* sleeps peacefully in the deep vault, fat on confiscated demon quartz.
- **Closing Hook**: Inquisitor Silas von Heide stands in the rain outside the ruined guildhall, holding two singed documents: one signed by Edric Vale, one signed by Lied Evans. In his pale hand, the needle of his Name Seat astrolabe oscillates frantically between both signatures, before locking onto a single, terrifying divine-demonic coordinate. Silas snaps the brass lid shut: *"Two faces. One mark in the high ledger. The hunt has begun, my young saint."*
