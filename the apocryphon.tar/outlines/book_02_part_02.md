# Book Two: The Capital's Deceiver
## Part 2 Master Detailed Outline (Chapters 9–16): The Saint, the Scholar, and the Prince

> **Arc Objective**: The expansion into deep multi-identity espionage and occult statecraft. Lied navigates the intoxicating public adoration of the **Saint of the March**, undergoes a chilling interrogation by Pope Aurelian, invents the reclusive scholar **Lydia Quire** to infiltrate the forbidden Witches' Circle, crafts the terrifying persona of the **Veiled Prince** to command corrupted guild cells from within, and forms an alliance with Prince Karl while uncovering the identity of his mysterious patron, Madame Vera.  
> **Target Word Count**: ~33,000 – 36,000 words across 8 chapters (average 4,200 words/chapter).

---

### Chapter 9: The Mass in the Square
- **The Event & The Crowd**: A public pontifical mass in the Great Cathedral Plaza, attended by fifty thousand citizens, guildsmen, and common soldiers. Saintess Eileen invites Lied to stand upon the high wooden dais beside the Archdeacon.
- **The Laboratory of Credence**: Lied does not retreat from the spectacle; he uses the platform as an empirical testing ground for the *Heart Stage* of his path. He discovers that public veneration is not a metaphor; it is a dense, warm, malleable gravitational field of collective intent.
- **The Performance**: Rather than deliver a grandiose sermon, Lied speaks three brief, unadorned sentences praising the labor of the common ditchers who died on the northern dikes. The understatement electrifies the crowd; the collective belief snaps into place with such force that conservative court pamphleteers who had arrived to heckle him find their tongues paralyzed by the overwhelming social pressure in the square.

### Chapter 10: The Secret Chapel
- **The Summons**: Following the mass, Lied is escorted by two silent Swiss halberdiers through the subterranean passages of the Vatican Palace to the private Chapel of Saint Veronica.
- **The Ancient Pontiff**: Pope Aurelian XXXII sits in an uncarved walnut chair, ninety years old, his skin translucent as oiled paper, carrying the blinding, soul-exhausting weight of the *Light Seat*. The room is thick with ancient frankincense and cold candle-wax.
- **The Dreadful Question**: The Pope blesses Lied with trembling, gentle fingers, offers him a dried fig, and then leans forward, his watery eyes boring directly into Lied's marrow: *"Tell me, child... when you fell into the Glass Hollow at nine years old, and lay two nights upon the black stone before your brother found you... what was it that took breath inside your chest?"*
- **The Evasion**: Lied's pulse does not spike; he draws upon the cold discipline of the ledger, feigning the pious, traumatized innocence of a boy who remembered only cold water and prayers to the Light. Aurelian sighs, satisfied yet profoundly uneasy, warning him that the Seat of Light is waking, and that false saints burn hotter than heretics.

### Chapter 11: The Banned Folios
- **Marcus’s Delivery**: Brother Marcus, now safely entrenched as third clerk of the Cathedral almonry, brings a sealed cedar casket to the private back-parlor of the Tallyhouse under cover of the evening river fog.
- **The Contraband**: Inside are confiscated manuscripts seized from an itinerant book-merchant burned at the stakes two weeks prior. Among them is a fragile, leather-bound palimpsest titled *The Weft of the Abyss: On the Grammar of the Unspoken Seats*.
- **The Crucial Clue**: In the margins of the text are delicate, razor-sharp commentaries written in lilac ink, bearing the book-stamp of an obscure private library in the northern cloistered suburb of Morne—a contact point for the legendary, secretive **Witches' Circle**.

### Chapter 12: The Ink of Lydia Quire
- **The Structural Obstacle**: The Witches' Circle is an ancient, autonomous fellowship of female scholars who study the deeper matrices of creation, the unwritten names of the god, and the arts of somatic division. Men who attempt to enter their sanctuaries are either mentally unraveled or quietly drowned in the canal.
- **The Construction of Lydia**: Lied rents a secluded, stone-walled cottage behind high laurel hedges in the foggy lanes of Morne. He hires an elderly, stone-deaf widow to act as housekeeper, instructed to accept parcels and leave out ink-jars without ever seeing her employer.
- **The First Treatise**: Writing exclusively in his spidery, backward-slanted left hand, Lied drafts an extraordinary theoretical paper: *On the Syntactical Imperfections of the Seventh Seat and the Symmetries of Somatic Projection*. He submits it under the pseudonym **Lydia Quire**.
- **Selena’s Hook**: Within four days, a courier arrives bearing a letter sealed in black wax stamped with an owl: **Mistress Selena**, high weaver of the Circle, writes back, addressing "Lydia" as a peer of the first rank and proposing an ongoing correspondence on the mechanics of soul-binding.

### Chapter 13: The Silk Guildmaster's Heart
- **The Financial Anomaly**: While cross-referencing Tallyhouse clearance vouchers with the Gold Scales League registers, Edric Vale discovers a colossal leak: sixty thousand gold sovereigns in unbacked silk bills, laundered through the accounts of Master Corvo, Guildmaster of the Silk and Dye Weavers.
- **The Banquet Infiltration**: Lied attends Corvo’s lavish autumn banquet aboard a gilded river-barge, dressed as the young Marcher nobleman.
- **The Biological Discovery**: Sitting five paces from Corvo during the roast, Lied observes the guildmaster’s throat: the left carotid artery flutters with that unmistakable, obscene, insectoid cadence he last felt beneath the iron key at Raine Ford. Corvo is possessed by a Celestial Heart Demon; he is Duke Victor Greven’s chief financier, purchasing illegal armaments for an impending winter coup against the Crown.

### Chapter 14: The Cloak of the Veiled Prince
- **The Need for Terror**: Ordinary legal warrants cannot arrest a royal guildmaster protected by private ducal guards. To stop the arms shipments, Lied must infiltrate the demon network itself.
- **The Fourth Persona**: In the deep vaults of the Tallyhouse, using the ancient Gnostic texts provided by Selena, Lied constructs the disguise of the **Veiled Prince**: an exiled celestial demon lord from the southern wastes, wrapped in shifting illusions of smoke and black silk, smelling of brimstone and cold copper.
- **The Catacombs Parley**: Lied descends into the sunken Roman cisterns beneath the dye-wharves to confront Corvo’s demon lieutenants. To Lied's shock, the lesser heart demons do not attack him; when he approaches, the parasites inside the cultists’ chests convulse in instinctive, terrified deference. The Celestial blood he absorbed as a child in the Glass Hollow commands their ancient obedience before they can even think. The Veiled Prince demands a half-share in the ducal plot, and the terrified demons hand over their entire courier roster.

### Chapter 15: Prince Karl Wagner
- **The Court Salon**: Prince Karl Wagner, the sharp-eyed military envoy of the Western Empire, invites Lied to a private evening at the Imperial Legation.
- **The Chess Match**: The two play *Four-Colored War-Chess*, a game of logistics, troop supplies, and terrain. Karl deliberately plays a strategy that mirrors the deployment of Duke Greven’s private regiments around the capital.
- **The Intellectual Alliance**: Lied does not play blindly; he uses his pawns to mimic an ambush at an unfortified river-sluice, subtly showing Karl that he knows the exact weak points of the capital's defenses. Karl smiles, sets his king down, and offers a quiet, informal treaty: the Western Empire will back Lied's standing at court, if Lied ensures that any coming coup does not burn the foreign banks.

### Chapter 16: The Dinner with Madame Vera
- **The Legation Invitation**: Madame Vera, high parliamentary delegate from the Southern Federation, summons the "Saint of the March" to an intimate dinner at her private villa overlooking the river gardens.
- **The Revelations Unfold**: Over roast pheasant and fine southern wine, Vera speaks of ancient pre-Cataclysmic theology with terrifying ease. She quotes verbatim from *The Seven Foundations of the Unspoken Word*—the exact anonymous text left on Lied's bed at Griffin.
- **The Architect's Smile**: Lied realizes with ice in his blood that Vera is the figure from the Glass Hollow; she has been monitoring his development for nine years. She does not demand his allegiance; she watches him with the patient, terrifying amusement of a master weaver watching a thread take its place in the cloth.
- **Crossed Shadows**: In the villa's antechamber, **Isolde Gregory**, now an officer of the King’s Secret Inquest, catches sight of Lied departing into the mist, her dark eyes narrowing as she realizes that the "petty student thief" from Griffin is dining with the most dangerous diplomat on the continent.
