# The Apocryphon — Master Style Guide (Canonical & Immutable)

> **Status**: Frozen / Immutable. All subsequent chapters must adhere strictly to these principles.

---

## 1. Core Voice and Narrative Distance
- **Point of View**: Deep / Close Third-Person, anchored strictly to **Lied Evans**.
- **Narrative Stance**: Restrained, concrete, intelligent, and dryly observant with wry wit. The narrator never lectures, moralizes, or summarizes the emotional or thematic significance of an event.
- **The Gap (Three Records Principle)**:
  1. *World Truth*: What actually exists and transpires.
  2. *Character Knowledge*: What Lied or other characters strictly observe and deduce (no psychic leaks).
  3. *Reader Knowledge*: The reader sees Lied’s outward actions, sensory intake, and pragmatic calculations, staying half a step behind his deeper schemes and half a step ahead of his rivals.
- **Understatement over Melodrama**:
  - Avoid suffocating gloom and relentless misery. This is a story of an extraordinarily clever young man finding his footing in a complex feudal and magical world.
  - Characters do not weep, tremble, or kneel in religious awe at minor events. Maintain aristocratic composure, professional dignity, and pragmatic common sense.

---

## 2. Protagonist Character Alignment (Lied Evans)
- **Essential Nature**: Rational, self-interested, intellectually fearless, and endlessly curious. He enjoys human company, appreciates cleverness in others, and loves a puzzle nobody else can solve.
- **Moral Guardrail (Canonical)**:
  - *"He takes no pleasure in anyone's suffering and goes out of his way to avoid causing it."*
  - Lied is **not** a cold, sociopathic vivisector. He does not deliberately inflict emotional cruelty, starve peasants, or break dependents' hearts just to collect experimental data. When he tests his limits, he does so with natural, low-stakes opportunities or unavoidable social friction.
- **Ingenuity Over Luck (Canonical)**:
  - Prophetic Utterance grants coincidences, open doors, and bought time—it **never** solves the puzzle on its own.
  - Whenever fortune presents an opportunity (such as an unexpected debt repayment), Lied must actively do the heavy lifting: exploiting administrative loopholes, out-maneuvering inspectors, forging or legitimizing documents, and managing the political blowback. The reader's satisfaction comes from Lied’s wits, not unearned lottery winnings.

---

## 3. Prose Mechanics and Descriptive Density
- **Toning Down Sensory Saturation**:
  - Do **not** pile four sensory details (dung, peat smoke, freezing draught, mud) into every single transitional paragraph. Establish the physical setting crisply, then let the dialogue, pacing, and intellectual action carry the scene.
  - Alternate between textured descriptive sentences and crisp, dry narrative forward momentum.
- **Period & Idiomatic Authenticity**:
  - **Strict Ban on Modernisms & Metric Units**: Absolutely no modern machinery or scientific metaphors (*light switch, psychological, millimeter, train of thought, dynamic*).
  - Use period-accurate idioms and measurements: *a barleycorn, a knife-edge, a candle-snuff, leagues, paces, inches, groats, crowns, sovereigns*.
- **Punctuation Discipline**:
  - **Em-dashes (`—`)**: Maximum 1–2 per chapter, strictly reserved for genuine interruptions in speech or sharp violent breaks in thought.
  - **Ellipses (`...`)**: Reserved only for speech that physically trails off into silence or hesitates; never in narration.
  - **Exclamation Marks (`!`)**: Forbidden in narration, near-zero in dialogue.

---

## 4. Magic System Consistency (Scales, Words, and the Ledger)
- **The Scales of Oaths**:
  - Measures the *resonance between sworn identity and commercial intent* (e.g., whether an individual is using their true legal identity and swearing a binding contract in good faith).
  - It does **not** magically inspect warehouse inventories across distant mountains, detect crop blight, or audit stockrooms. Discrepancies in goods are discovered through human intelligence, archival records, and investigative deduction.
- **The Ledger**:
  - A tool of discipline and psychological anchoring for Lied’s own cognition. It does not possess autonomous physical superpowers (such as freezing a human wrist with invisible force).
  - A failed claim cannot be resolved on the right side of the ledger because the social domain and external credence have hardened against him; it remains an unfulfilled debt in his conscience and record.

---

## 5. Volume, Pacing & Epic Scale Principles
- **Series Scope & True Volume Standard**:
  - The series aims for a full-scale epic fantasy density: **strictly ≥700,000 Chinese Characters across 5 Books** (reference baseline: ~800,000 Chinese Characters total, ~140,000–180,000 per Book).
  - **No Coefficient Illusion**: Theoretical word conversion ratios (such as 1.63x) are planning guides only. Acceptance is judged by **actual narrative substance, scene depth, and final Chinese literary volume**, not typographic inflation.
  - **Status of Book One**: The initial 13 chapters (~39,900 English words) represent the **First-Pass Narrative Draft**—the essential structural spine and causal foundation. It is recognized as an open draft that will undergo future expansion (deepening rural management, dual-faculty academic research, dragon bonding, and ethnic trade) to reach its full ~140,000-word Chinese stature alongside the rest of the saga.
  - **Organic Chaptering**: Chapter counts (such as 24, 26, or 28) are functional roadmaps, not rigid quotas. A subplot expands whenever it yields genuine character growth, intellectual friction, and world exploration; it cuts clean whenever the beat is complete. Zero padding.
- **Narrative Breathing Room (Books Two to Five)**:
  - Deliver scenes with unhurried tactical depth: multi-party social maneuvers, legal mechanisms, academic research, and the rough friction of daily institutional life. Pacing must feel alive and expansive, giving intelligence room to breathe.

---

## 6. The Ledger Epigraphs
- Every chapter opens with a stylized ledger entry from Lied’s personal register:
  - **Left Hand (Unsettled / Debt / Claims in progress)**: Written in fluid, slightly hurried script; things that are not yet true.
  - **Right Hand (Settled / Credence / Redeemed)**: Written in firm, ink-blotted ledger hand; reconciled facts with exact dates and costs.
